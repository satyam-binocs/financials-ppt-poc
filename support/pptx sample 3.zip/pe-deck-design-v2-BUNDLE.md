# pe-deck-design v2 — single-file bundle

This one file contains every file of the upgraded `pe-deck-design` skill, verbatim, each fenced and labeled with its original path. Extract each block back to its labeled path to restore the working skill folder exactly. A checksum manifest and an extraction script are included at the end.

## Original folder layout

```
pe-deck-design/
  SKILL.md
  assets/design-tokens.json
  assets/example_spec.json
  assets/example_spec_v2.json
  scripts/layout_engine.py
  scripts/compose_engine.py
  scripts/pe_components.js
  scripts/build_from_plan.js
  scripts/audit_deck.py
  scripts/example_build.js
  references/layout-intelligence.md
  references/report-deck-patterns.md
  references/typography.md
  references/components.md
  references/tables.md
  references/citations.md
  references/density-and-pagination.md
  references/source-spec.md
```

## FILE: `SKILL.md`

````markdown
---
name: pe-deck-design
description: "Design system, layout intelligence engine and renderer for consulting-grade and private-equity PowerPoint decks — the MBB/expert-report register, not the sales-pitch register. Use this skill WHENEVER a .pptx deck is being created or edited for an investor, PE analyst, diligence, IC memo, market study, expert report, strategy review, or any audience that expects dense, cited, small-type consulting slides. Trigger on: 'investment deck', 'IC memo', 'diligence pack', 'market study', 'expert report', 'BCG/McKinsey/Bain/KPMG style', 'consulting slides', 'board deck', 'CIM', 'teaser', or any deck with tables, charts, sourced metrics, numbered citations, or a References appendix. This skill OVERRIDES the generic pptx skill's typography and design guidance, which is sized for presentation decks and will produce wrong output here. It provides design tokens, a content-aware composition engine that selects the slide layout, a deterministic density/typography engine, a pptxgenjs component library, and a post-build compliance auditor."
---

# PE / consulting deck design

This skill encodes one specification. Everything in it traces back to that spec, and
`assets/design-tokens.json` marks each value `DOC` (stated in the spec) or `DERIVED`
(computed from a spec rule, or a geometry constant the spec implies but does not number).
**Never silently change a `DOC` value.** Changing one is a spec change, not a styling choice.

The skill answers two different questions, and it answers them in this order:

```
What is the correct structural composition of this slide?     <- layout intelligence
Where exactly does each component go, and how does it look?   <- geometry + component law
```

Getting these the wrong way round is the single largest source of bad generated decks.
A builder that starts from "I have four cards, I will put them in a row" has already lost,
because whether four items belong in a row depends on how much text each one carries.

## Precedence — read this first

This skill composes with the built-in **pptx** skill. Split of responsibility:

| Concern | Owner |
|---|---|
| File mechanics: pptxgenjs gotchas, XML editing, `validate.py`, rendering to images | **pptx** skill |
| Type scale, grid, layout selection, components, tables, charts, citations, density, pagination | **this skill** |

Where they conflict, **this skill wins**, because the generic guidance is calibrated for
presentation decks and this register is different:

| Generic pptx skill says | Here |
|---|---|
| Slide title 36–44pt | **14–16pt.** A consulting title is a full sentence stating the so-what, not a headline. |
| Body 14–16pt | **9–10pt.** |
| Section header 20–24pt | **12–14pt.** |
| "Don't create text-only slides", "every slide needs a visual element" | A dense cited table *is* the visual. Do not add decorative imagery to a diligence page. |
| "Pick a bold, content-informed colour palette" | Restrained neutral + one primary + one accent. The data carries the interest. |
| Default canvas 10" × 5.625" | **13.333" × 7.5".** Non-negotiable — see below. |

Everything else from the pptx skill still applies, especially: hex colours without `#`,
never reuse an options object, `isTextBox: true` on every `addText`, `margin: 0` when
aligning to a shape, no accent rules under titles, no decorative stripes, and running
`scripts/office/validate.py` after every build.

**The canvas is load-bearing.** Every point size and every geometry constant in this spec
assumes 13.333" wide. On pptxgenjs's default 10" canvas the same 9pt body renders ~33%
larger relative to the slide and the entire scale collapses. `pe_components.js` sets this
before the first slide exists; if you hand-roll a deck, set it yourself.

**When rules collide**, resolve in this order — the spec's own priority, extended through
the composition layer:

```
Meaning → required data → readability → semantic grouping → hierarchy
        → structural correctness → source visual intent → exact geometry
```

Exact geometry is last. A layout that is beautifully aligned and unreadable has failed.

## The pipeline

Five stages, in order. Skipping stage 1 or stage 2 is the most common way to produce a bad
deck, because layout decisions then get made per-component instead of per-slide.

```
content spec (JSON)
   │
   ├─1─► layout_engine.py     density band → type scale, component verdicts, merge plan
   │
   ├─2─► compose_engine.py    roles → candidate layouts → validate → score → geometry
   │
   ├─3─► pe_components.js     measure → distribute → render  (writes the .pptx)
   │
   ├─4─► audit_deck.py        compliance audit against the emitted XML
   │
   └─5─► render + look        soffice → pdftoppm → view every slide
```

```bash
python3 scripts/layout_engine.py  spec.json                      # 1. density and verdicts
python3 scripts/compose_engine.py spec.json --json -o plan.json  # 2. layout + geometry
node    scripts/build_from_plan.js spec.json plan.json deck.pptx # 3. render
python3 scripts/audit_deck.py deck.pptx                          # 4. audit
python3 /mnt/skills/public/pptx/scripts/office/validate.py deck.pptx   # file integrity
```

Both engines carry `--selftest`; run them if you change a token.
`assets/example_spec_v2.json` is the worked reference spec and exercises seven layouts,
charts, a matrix, a timeline, a cover, dividers and the References appendix.

## Stage 1 — density decides typography

This is the core inversion, and the part most builders get backwards. **You do not pick a
font size. You count the content, and the count picks the size.**

Character budget = every piece of visible copy on the slide — title, subtitles, paragraphs,
bullets, card titles and bodies, callouts, table text, chart labels. **Citations are
excluded**: they are traceability metadata, not content.

| Characters | Band | Scale | Action |
|---|---|---|---|
| ≤ 550 | sparse | title 16 / header 14 / body 10 / table 9 / foot 8 | Scale up, widen whitespace, or pull related content forward |
| 551–900 | balanced | title 15 / header 13 / body 10 / table 9 / foot 8 | **Preferred. Ship it.** |
| 901–1000 | dense | title 14 / header 12 / body 9 / table 8 / foot 7 | Optimise: condense copy before changing layout |
| 1001–1200 | dense | same | Strong overflow check: reflow → consolidate → shorten → deprioritise |
| > 1200 | overflow | — | Recompose or split at a logical boundary |

Two invariants hold across every band:

- **Hierarchy never crosses.** Each role moves inside its own range; title is always above
  header, header always above body. Only the overall scale shifts.
- **8pt is the content floor, 16pt the ceiling.** 7pt exists only for source/footnote and
  citation metadata. This is the single reconciliation in the token set (the spec states a
  global 8pt minimum *and* a 7–8pt footnote range) and it is recorded as such in the tokens.

**Never solve a fit problem by shrinking type.** The escalation order is fixed, and stage 2
adds one step to it:

```
reflow → CHANGE LAYOUT → consolidate → shorten → deprioritise → split
```

PowerPoint's autofit shrink is literally horizontal/vertical font scaling, which the spec
forbids; `audit_deck.py` fails the build if it finds `normAutofit fontScale` anywhere.

Character count is one of two density axes. The second — component complexity — is stage 2's.

## Stage 2 — layout intelligence and composition

`compose_engine.py` decides the **structure** of the slide before anything is drawn. It is
the layer that turns a list of blocks into a composition rather than a stack.

```
semantic roles → candidate layouts → hard-constraint validation → scoring
              → resolved geometry → vertical packing → balance audit → diagnostics
```

**Semantic roles first.** Every block is classified `primary`, `secondary`, `supporting`,
`comparison`, `evidence`, `annotation`, `summary`, `context` or `metadata`. Every slide gets
exactly one primary anchor. An explicit `"role": "primary"` in the spec always wins — the
engine never overrules a stated intent.

**Then candidates, not a template.** Twenty canonical layouts (`L01_SINGLE` …
`L20_PAGINATED`) are filtered by shape, validated against hard constraints, scored, and the
best valid composition is selected — not the first one that fits.

**Component count alone never decides.** The same count resolves differently by text volume:

| Content | Layout |
|---|---|
| Four compact KPIs | `L06_FOUR_COLUMN` |
| Four detailed insight cards | `L07_GRID_2X2` — four columns violates minimum width |
| Six short cards | `L08_GRID_2X3` (2 rows × 3 cols) |
| Six detailed cards | `L09_GRID_3X2` (3 rows × 2 cols) — wider columns buy reading width |
| Chart + short commentary | `L13_CHART_COMMENTARY` |
| Chart + long commentary | stacked — a side panel cannot hold 420+ characters |
| Table + concise takeaway | `L14_TABLE_INSIGHT` |
| Two detailed tables | paginate — never side by side |

**Minimum dimensions are derived, not invented.** `min_w = min_chars_per_line × fontPt/72 ×
0.50 + padding`. At 10pt body, 32 characters a line needs 2.22in of text plus padding. Below
that a column stops being prose and becomes a word ladder. A layout is **rejected** when any
region falls below its floor. There is also a ceiling: past ~110 characters a line the eye
loses the line return, so prose is capped at its measure even inside a full-width region.

**Every rejection is reported.** The plan carries which layouts were considered, which were
rejected and on which constraint, the score breakdown of the winner, and the runners-up:

```json
{
  "selected_layout": "L07_GRID_2X2",
  "reason": ["4 component(s) detected: cards(primary), cards(secondary)... — detailed content",
             "Four detailed peers that each need reading width",
             "L06_FOUR_COLUMN rejected: column_text_too_long"],
  "rejected_layouts": [{"layout": "L06_FOUR_COLUMN", "reason": "column_text_too_long"}]
}
```

When no layout survives, the engine resolves to `L20_PAGINATED` and returns a **split point
at a sub-topic boundary** — a `header` block if there is one, otherwise the block boundary
nearest the midpoint of the character load. The renderer refuses to draw such a slide.

Full rules, the twenty-layout taxonomy, the compatibility matrix, the scoring function and
the invalidity codes: `references/layout-intelligence.md`.

## Stage 3 — rendering: a deterministic painter

`pe_components.js` never draws a component when it is declared. It measures everything
first, distributes the leftover space, then renders. Under `composeResolved()` it paints the
geometry stage 2 resolved and **takes no layout decision at all**.

```
Layout engine:  "What goes where?"
Renderer:       "Render exactly what was resolved."
```

Two-phase layout exists to kill one specific defect: the correct-looking top third and dead
bottom half that every naive slide builder produces. Surplus space flows back to the
growable components (capped per type — a card is a container, so stretching it just moves
dead space inside the border; a table genuinely reads better with taller rows) and then to
the gaps (capped), and what remains is reported as underfill.

```js
const { Deck } = require('./pe_components');
const deck = new Deck({ palette: 'graphite_navy' });

const s = deck.slide({ band: 'balanced', eyebrow: 'STRATEGY',
                       title: 'Sentence-case sentence stating the so-what' });
await s.compose([                     // free vertical flow — L10 by hand
  { type: 'body',     text: '...', cite: [1] },
  { type: 'callouts', items: [{ value: '46.74%', label: '...', cite: [194] }] },
  { type: 'header',   text: 'Why this matters' },
  { type: 'bullets',  items: [{ text: '...', cite: [1] }] },
  { type: 'table',    headers: [...], rows: [...], hasTags: true, zebra: false },
  { type: 'cards',    items: [{ title: '...', body: '...', cite: [51] }] },
  { type: 'rail',     items: [{ title: '...', body: '...', cite: [66, 67, 68] }] },
  { type: 'chart',    chartType: 'bar', labels: [...], series: [...], highlight: 0 },
]);
s.source().pageNumber(2);

deck.references(SOURCE_MAP);      // one global index, deck-wide
await deck.save('deck.pptx');     // warns on overrun and on genuine underfill
```

For anything beyond a single-column flow, use the plan instead of `compose()`:

```js
await s.composeResolved(plan.slides[i], blocks);   // regions come from compose_engine.py
```

`compose()` and `composeResolved()` **throw** rather than degrade: 7+ cards, 7+ rail items,
5+ callouts, zebra striping combined with tags, ragged table rows, a slide the engine
resolved to `L20_PAGINATED`, or content that cannot fit even at minimum sizes. Those are
spec violations, not layout problems, and the fix is editorial.

Read `scripts/build_from_plan.js` and `scripts/example_build.js` before writing a new deck.
The shape of those calls is the skill.

## Component law

Not configurable. These are the spec's definitions, and they are the only thing that
distinguishes the three containers from each other.

| Component | Border | Fill | Count rules |
|---|---|---|---|
| **Card** | 1pt neutral | **none** | 1–3 larger with more internal whitespace · 4–6 compact · 7+ switch to a rail or grouped structure |
| **Rail** | 1pt | gradient **of the border colour** | 2–4 generous · 5–6 compact · 7+ split or change component |
| **Callout** | **none** | gradient **of the primary colour** | 1 strong emphasis · 2 balanced by content length · 3+ only if each is a distinct insight |

- Cards in a row share a common height. Widths need **not** be equal — don't force
  symmetry when content lengths differ materially.
- Rail item width **follows content length**; a short item should not inflate to match a
  long one. Preserve order when the data is a sequence.
- Callout heights need **not** match. Each callout carries exactly one data point or message.
- Long content: reduce padding and spacing **before** reducing font size. If it still
  doesn't fit, restructure or move it — never shrink below the minimum.
- **A KPI is a callout.** There is no fourth container; `kpi` is an alias the layout
  taxonomy uses so it can name a KPI strip without inventing a component.

**Gradients:** pptxgenjs cannot emit an OOXML gradient fill. `pe_components.js` renders
them as alpha PNGs through `sharp` and places them behind the shape — the only route that
survives a round trip into PowerPoint. Do not substitute a solid fill; the gradient is what
separates a rail from a card.

Details and the full count-rule text: `references/components.md`.

### Exhibits: chart, matrix, timeline

All three are **native, editable PowerPoint objects with their data intact** — never images
of exhibits.

- **Chart.** A single series is **one colour**; cycling a palette across the bars of one
  series encodes a difference that does not exist. The accent is reserved for the one bar
  the title is about (`highlight: index`). Aspect ratio is held between 0.9 and 2.6 and the
  chart is letterboxed and centred inside its region rather than stretched: below 0.9 the
  legend becomes the subject, past 2.6 the series flatten and the trend disappears. Avoid
  two complex charts side by side — the engine rejects it.
- **Matrix.** Stays the primary visual. Quadrants carry short labels, never paragraphs;
  long explanation goes in the side annotation region `L17_MATRIX` allocates. Axis labels
  stay legible at chart-label size, and point labels flip side rather than escape the frame.
- **Timeline.** Orientation is a consequence of content, not a style choice: horizontal for
  ≤6 events with short labels, vertical once entries carry prose. Chronological order is
  always preserved; past 8 events, paginate.

One source line per slide by default — the footer carries it. A chart gets its own in-visual
source line (`sourceLine: true`) only when the slide holds more than one exhibit and they
come from different sources.

## Tables

The single sharpest rule, and the one most often broken:

> **Zebra striping and tags cannot coexist.** If rows carry labels, tags, pills or any
> visual indicator, keep the background uniform and let the tags create the
> differentiation. Zebra is permitted only on dense, data-only tables with no tags, no
> highlighted rows, and no coloured cells, where striping genuinely aids row scanning.

`compose()` throws on the combination; `audit_deck.py` detects it in the emitted XML too,
in case a table was built by hand.

Also: subtle horizontal dividers only (no boxed cells, no heavy gridlines); the primary
column visually dominant; descriptive columns wide, numeric and short-label columns narrow;
numbers right-aligned with consistent decimals and units; **1 line preferred, 2 lines
maximum** per cell — past that, restructure the table rather than shrink the font.

Table overflow escalation is its own ordered list: column widths → cell padding → wrapping
→ overall table size → and only then typography, within range.

Compositionally: prefer full width. A detailed table never goes in a sidebar, never sits
beside another table, and its narrowest column may not fall below 0.62in — the engine
rejects all three.

Full rules: `references/tables.md`.

## Citations

Numbered `[n]` throughout, placed immediately after the claim, metric, statement, chart or
data point they support. `[3]` · `[3, 7]` · `[3-7]` for consecutive runs — `layout_engine.py`,
`compose_engine.py` and `pe_components.js` collapse runs identically, so the three never
disagree.

Citations are **metadata, not content**: excluded from the character budget, visually
subordinate (same family, one step down, 8–9pt, regular weight, muted colour), and never
bold, uppercase, badged, pilled, bordered, or given their own card. They must never change
a component's layout — no shrinking main content and no growing a component to fit a source.
A chart's in-visual source line rides *inside* the allocated box for exactly this reason.

Never put full source names, publication titles or URLs inside a card, callout, chart or
table. One global source index across the deck: `[3]` means the same source on every slide.
Past 6–8 sources on a slide, keep the `[n]` markers and move the full list to References.

One pptxgenjs constraint worth knowing, since it shapes the bullet implementation: a
bulleted paragraph **cannot** hold two differently-styled runs. Any run without a bullet
option emits its own `<a:pPr>` with `<a:buNone/>` and silently kills the bullet for the
whole paragraph; giving every run the bullet option instead splits them into separate
bulleted paragraphs. So "bulleted claim + muted citation" is unreachable through `addText`
bullets, and `pe_components.js` draws the marker as its own text box at a fixed hanging
indent. That also buys exact indent control the built-in bullet doesn't give.

Full rules: `references/citations.md`.

## Pagination

> **Fit + Related + Readable → merge. Otherwise → new slide.**

One section = one slide by default. Before creating a new slide, check whether the next
content fits on the current one. If related content fits without crowding, merge it. If it
doesn't fit, split — but split at a **logical sub-topic boundary**, moving a meaningful
sub-topic rather than leftover content. Every slide, including a continuation, must feel
complete: never a slide carrying one orphaned card or bullet.

Never merge unrelated content just to fill space, and never shrink below minimum type to
avoid a new slide.

`layout_engine.py` emits this as an explicit per-slide plan (`keep` / `merge_next` /
`split`) with the reasoning attached; `compose_engine.py` independently escalates to
`L20_PAGINATED` only after every layout change in the fallback chain has been tried, and
returns the block index to split at. Pagination is the **last** step of the escalation
order, never the first.

Note that vertical emptiness and character load are different axes: a slide at 800
characters laid out horizontally is dense in the sense the spec measures, even if it doesn't
stack tall. The build only flags underfill when **both** the vertical space is empty and the
character load is below target.

Full rules: `references/density-and-pagination.md`.

## Typography rules

Sentence case for titles and headers. ALL CAPS only for short labels, tags, metadata and
eyebrows (≤18 chars). **Never Title Case.** `audit_deck.py` flags both violations. An
over-long eyebrow is warned about, never silently truncated — losing content is worse than
the violation.

Never distort a font — no horizontal or vertical scaling, no autofit shrink. Fix fit through
font size (within range), text box size, spacing, or layout.

Line spacing: body 1.10–1.25×, headers 0.95–1.10×, citations 1.10–1.20×. Paragraph spacing
3pt after, section spacing 8pt after.

Measure: prose sets to at most ~110 characters a line and at least 32. Both bounds are
enforced — the floor by minimum region width, the ceiling by capping the text column inside
a wide region.

**Fonts: Manrope for headers, Arial for body.** Manrope has no metric-compatible substitute
in the local renderer, so **header fit in PDF/image QA is approximate** — size header
containers with ~10% slack and don't trust a borderline header overflow read from the
preview. `estimateLines()` deliberately over-estimates header width for this reason. Body
text in Arial renders true-to-width, so body overflow reads from QA are trustworthy.

Full rules: `references/typography.md`.

## Report register — cover, dividers, tracker, exhibits

A diligence pack is a document, not a talk track, and it carries document furniture. The
`Deck` class provides it so structure is data rather than something a builder remembers:

| Element | Call | Convention |
|---|---|---|
| Cover | `deck.cover({...})` | Client, engagement, date, and the confidentiality line — which on a diligence pack is distribution control, not decoration |
| Section divider | `deck.divider({ number, title })` | One per section, numbered deck-wide, carrying the section assertion |
| Agenda / tracker | `deck.tracker(sections, active)` | Active section in ink, the rest muted — the reader always knows where they are |
| Exhibit tag | `s.exhibit('Exhibit 3')` | Once a deck numbers exhibits, every exhibit gets one |
| Note line | `s.note('...')` | `Note:` above `Source:` — the home for scope qualifiers, definitions and exclusions |
| References | `deck.references(map)` | One global index, one number per source, deck-wide |

Full conventions, including the differences between the MBB and Big Four registers:
`references/report-deck-patterns.md`.

## Stage 4 — audit, and what each failure means

`audit_deck.py` reads the emitted XML, so it catches what the plan can't: a stray run size,
an autofit shrink, Title Case that survived editing, a hand-built table with zebra and tags,
a shape outside the margins. Exit code 1 on any FAIL.

| Rule | Level | Meaning |
|---|---|---|
| `type.min` / `type.max` | FAIL | Run outside 7–16pt, or 7pt used for body content |
| `type.distortion` | FAIL | `normAutofit` is scaling the font — restructure, don't squeeze |
| `case.allcaps` | FAIL | Caps run longer than a label |
| `grid.margin` / `grid.vertical` | FAIL | Shape outside the content band — content running off-slide |
| `cite.url` / `cite.weight` | FAIL | Raw URL on a slide, or a bold citation |
| `density.hard` | FAIL | Past 1,200 characters |
| `table.zebra` | FAIL | Striping on a tagged table |
| `decoration.stripe` | WARN | Thin textless bar — the accent-stripe tell |
| `case.titlecase`, `table.wrap`, `cite.density`, `density.soft` | WARN | Editorial, not structural |

Geometry is read **as drawn, not as stored**: a text box rotated 90° or 270° (a matrix's
vertical axis label) keeps its unrotated box in the XML while PowerPoint draws it swapped
about its centre, so the auditor applies the rotation before checking bounds.

Structure is distinguished from decoration by an explicit mark, never inferred: the renderer
names load-bearing shapes `structure:*` (matrix axis, timeline rail, tracker rule), and only
that mark exempts a textless bar from the stripe rule. An accent stripe under a title has no
such mark and is still flagged.

The References/Appendix slide is auto-detected and exempted from the citation-density,
footnote-size and sentence-case checks — it is the one place full source strings, 7pt
metadata and Title Case publication names belong. Covers, dividers and trackers are
navigation, not content, and the character budget does not apply to them.

## Stage 5 — look at it

The audit cannot see overlap, collision or visual balance. Render and inspect every slide:

```bash
python3 /mnt/skills/public/pptx/scripts/office/soffice.py --headless --convert-to pdf deck.pptx
rm -f slide-*.jpg && pdftoppm -jpeg -r 130 deck.pdf slide
```

Look for: text colliding with a container edge, a card title running into its own body
(the classic Manrope-measurement failure), source lines colliding with content, columns
out of alignment, a chart whose legend out-sizes its plot, a point label escaping its
matrix, and any component that grew tall with its content stuck at the top.

## Editorial standard

The design system is necessary but not sufficient. For this audience:

- **Titles are assertions, not labels.** "Club-store placement concentrates presence in the
  West and Southeast", not "Regional footprint". The title carries the finding; the body
  carries the evidence.
- **Every number is cited.** An uncited metric in a diligence pack is a liability.
- **Distinguish absence of evidence from evidence of absence.** "No 2016 club placement"
  means uncovered, not lost — and that distinction changes how it is priced.
- **Two strong components beat six weak ones.** Prioritise information, not component count.
- **Highlight what the title claims.** If the title is about club placement, the club bar is
  the accent one. An exhibit that does not point at its own assertion is decoration.

## Files

| Path | Purpose |
|---|---|
| `assets/design-tokens.json` | Every value, with `DOC`/`DERIVED` provenance. Single source of truth, including the layout catalog. |
| `assets/example_spec.json` | Original worked spec, vertical flow |
| `assets/example_spec_v2.json` | Layout-aware worked spec: chart, matrix, timeline, grid, cover, dividers |
| `scripts/layout_engine.py` | Stage 1. Density, scale, verdicts, merge plan. `--selftest` included. |
| `scripts/compose_engine.py` | Stage 2. Roles, layout selection, geometry, diagnostics. `--selftest` included. |
| `scripts/pe_components.js` | Stage 3. Two-phase layout, region rendering, component library. |
| `scripts/build_from_plan.js` | Stage 3 CLI. Spec + plan → .pptx, with deck furniture. |
| `scripts/audit_deck.py` | Stage 4. Post-build compliance audit. |
| `scripts/example_build.js` | Worked five-slide reference deck, hand-composed. |
| `references/layout-intelligence.md` | **The composition engine in full: taxonomy, compatibility, scoring, constraints** |
| `references/report-deck-patterns.md` | Report-deck conventions and the MBB vs Big Four registers |
| `references/typography.md` | Full type rules and the scale-resolution logic |
| `references/components.md` | Card / rail / callout rules in full |
| `references/tables.md` | Full table rules |
| `references/citations.md` | Full citation rules |
| `references/density-and-pagination.md` | Character budget, merging, slide rules |
| `references/source-spec.md` | The original specification, preserved in full |

## Dependencies

`pptxgenjs`, `sharp` (npm, preinstalled) · Python 3 stdlib only for all three scripts ·
LibreOffice + `pdftoppm` for visual QA, via the pptx skill's `soffice.py` wrapper.

````

## FILE: `assets/design-tokens.json`

````json
{
  "$schema": "pe-deck-design/1.0",
  "provenance": {
    "DOC": "value stated verbatim in the source specification",
    "DERIVED": "computed from a DOC rule, or a geometry constant the DOC implies but does not number",
    "note": "Never edit a DOC value silently. Changing one is a spec change, not a styling choice."
  },

  "canvas": {
    "layout": "LAYOUT_WIDE",
    "width_in": 13.333,
    "height_in": 7.5,
    "provenance": "DERIVED",
    "why": "All DOC point sizes (8-16pt) assume a 13.33in canvas. On pptxgenjs's default 10in canvas the same pt values render ~33% larger relative to the slide and the whole scale breaks."
  },

  "grid": {
    "margin_top_in": 0.42,
    "margin_bottom_in": 0.40,
    "margin_left_in": 0.50,
    "margin_right_in": 0.50,
    "columns": 12,
    "gutter_in": 0.16,
    "column_width_in": 0.9777,
    "title_band_h_in": 0.55,
    "footer_band_h_in": 0.28,
    "content_top_in": 1.05,
    "content_bottom_in": 6.95,
    "content_width_in": 12.333,
    "content_height_in": 5.90,
    "provenance": "DERIVED",
    "why": "DOC requires 'align tables to the slide's main content grid' and 'consistent left/right margins across slides' but does not number the grid. These constants are that grid."
  },

  "type": {
    "fonts": {
      "header": "Manrope",
      "body": "Arial",
      "header_fallback": "Calibri",
      "provenance": "DOC",
      "qa_warning": "Manrope is not metric-compatible with anything LibreOffice substitutes. Header fit in local PDF/image QA is APPROXIMATE. Size header containers with ~10% horizontal slack and never trust a borderline header overflow read from the preview."
    },
    "min_pt": 8,
    "max_pt": 16,
    "footnote_floor_pt": 7,
    "footnote_floor_note": "DOC sets a global 8pt minimum AND separately sets source/footnote at 7-8pt. Resolution: 8pt is the floor for CONTENT; 7pt is permitted only for source/footnote/citation metadata. This is the single reconciliation in the token set.",

    "scales": {
      "sparse": {
        "title": 16, "header": 14, "body": 10, "key_insight": 10,
        "table_header": 10, "table_body": 9, "table_metric": 10, "table_title": 14,
        "chart_label": 9, "footnote": 8, "citation": 9
      },
      "balanced": {
        "title": 15, "header": 13, "body": 10, "key_insight": 10,
        "table_header": 10, "table_body": 9, "table_metric": 10, "table_title": 13,
        "chart_label": 9, "footnote": 8, "citation": 9
      },
      "dense": {
        "title": 14, "header": 12, "body": 9, "key_insight": 9,
        "table_header": 9, "table_body": 8, "table_metric": 9, "table_title": 12,
        "chart_label": 8, "footnote": 7, "citation": 8
      }
    },
    "scale_note": "DOC: 'The relative hierarchy between title, header, body, chart labels, and footnotes should remain consistent; only the overall scale changes.' Each role therefore moves within its own DOC-defined range; roles never cross.",

    "role_ranges_doc": {
      "title": [14, 16, "Bold"],
      "header": [12, 14, "Medium"],
      "body": [9, 10, "Regular"],
      "key_insight": [9, 10, "Regular"],
      "table_title": [12, 14, "Semibold"],
      "table_header": [9, 10, "Semibold"],
      "table_body": [8, 9, "Regular"],
      "table_metric": [9, 10, "Semibold"],
      "chart_label": [8, 9, "Regular"],
      "footnote": [7, 8, "Regular"],
      "citation": [8, 9, "Regular"],
      "provenance": "DOC"
    },

    "line_spacing_multiple": {
      "body_min": 1.10,
      "body_max": 1.25,
      "header_min": 0.95,
      "header_max": 1.10,
      "citation_min": 1.10,
      "citation_max": 1.20,
      "provenance": "DOC"
    },
    "paragraph_space_after_pt": 3,
    "section_space_after_pt": 8,
    "provenance_spacing": "DOC",

    "case": {
      "title": "sentence",
      "header": "sentence",
      "body": "sentence",
      "citation": "sentence",
      "allcaps_allowed_for": ["short label", "tag", "metadata", "eyebrow"],
      "allcaps_max_chars": 18,
      "title_case_banned": true,
      "provenance": "DOC"
    },

    "distortion": {
      "horizontal_scale_allowed": false,
      "vertical_scale_allowed": false,
      "autofit_font_scale_allowed": false,
      "provenance": "DOC",
      "why": "DOC: 'Do not stretch, compress, or scale the font.' PowerPoint's normAutofit fontScale is exactly this distortion applied automatically, so autofit shrink is banned; fix fit by layout, not by squeezing glyphs."
    }
  },

  "density": {
    "unit": "characters of visible copy, citations excluded",
    "target_min": 600,
    "target_max": 900,
    "soft_max": 1000,
    "hard_max": 1200,
    "provenance": "DOC",
    "bands": [
      { "name": "sparse",     "max": 550,  "action": "Scale up. Increase whitespace. Consider pulling related content forward from the next slide." },
      { "name": "balanced",   "max": 900,  "action": "Preferred. Ship it." },
      { "name": "dense",      "max": 1000, "action": "Optimize if possible: condense copy before changing layout." },
      { "name": "dense",      "max": 1200, "action": "Strong overflow check. Reflow, consolidate, shorten, deprioritise." },
      { "name": "overflow",   "max": null, "action": "Recompose or split at a logical content boundary. Never shrink type to fit." }
    ]
  },

  "components": {
    "card": {
      "border_pt": 1,
      "border_role": "neutral",
      "fill": "none",
      "provenance": "DOC",
      "counts": {
        "1-3": "Larger cards, stronger typography, more internal whitespace.",
        "4-6": "Reduce card width and spacing; keep content readable.",
        "7+": "Do not keep shrinking. Switch to a rail or grouped structure."
      },
      "radius_in": 0.06,
      "pad_x_in": 0.16,
      "pad_y_in": 0.12,
      "gap_in": 0.18,
      "equal_height_within_row": true,
      "equal_width_required": false,
      "one_message_per_card": true
    },
    "rail": {
      "border_pt": 1,
      "fill": "gradient of the border colour",
      "provenance": "DOC",
      "counts": {
        "2-4": "Larger item widths, generous spacing.",
        "5-6": "Compact spacing, smaller item widths.",
        "7+": "Split the rail or change the component. Never drop below min type."
      },
      "radius_in": 0.06,
      "pad_x_in": 0.16,
      "pad_y_in": 0.12,
      "gap_in": 0.14,
      "width_follows_content": true,
      "preserve_order": true
    },
    "callout": {
      "border_pt": 0,
      "fill": "gradient of the primary colour",
      "provenance": "DOC",
      "counts": {
        "1": "Stronger visual emphasis, more whitespace.",
        "2": "Balance by content length; identical heights not required.",
        "3+": "Only when each is a distinct insight; otherwise combine."
      },
      "radius_in": 0.06,
      "pad_x_in": 0.18,
      "pad_y_in": 0.14,
      "gap_in": 0.18,
      "equal_height_required": false
    },
    "gradient": {
      "tint_start_pct": 10,
      "tint_end_pct": 2,
      "angle_deg": 135,
      "provenance": "DERIVED",
      "why": "DOC specifies gradient fills. pptxgenjs cannot emit a gradient fill, so gradients ship as an alpha PNG generated at build time (scripts/pe_components.js). Tint percentages keep the fill subordinate to the text above it."
    }
  },

  "table": {
    "cell_pad_x_pt": [6, 8],
    "cell_pad_y_pt": [4, 6],
    "provenance": "DOC",
    "borders": "Subtle horizontal dividers only. No heavy gridlines. No box around every cell.",
    "row_height": "Minimum required for content; no excess whitespace.",
    "max_wrap_lines": 2,
    "preferred_wrap_lines": 1,
    "numeric_align": "right",
    "text_align": "left",
    "header_align": "match column",
    "zebra": {
      "allowed_when": "Dense data-only table with no tags, pills, labels or highlighted rows, where striping genuinely improves row scanning.",
      "banned_when": "Rows contain labels, tags, pills or other visual indicators; or the table already uses highlighted rows or coloured tags.",
      "provenance": "DOC"
    },
    "overflow_order": [
      "column widths",
      "cell padding",
      "wrapping",
      "overall table size",
      "typography (only within the allowed range, and last)"
    ],
    "provenance_overflow": "DOC",
    "column_width_policy": "Wider for descriptive text, narrower for numbers, percentages, dates and short labels. No unnecessarily wide empty columns. Primary column visually dominant.",
    "emphasis": "Bold only key values, totals or key rows. One consistent treatment for highlighted cells. One accent colour maximum."
  },

  "citation": {
    "style": "numbered",
    "single": "[3]",
    "multiple_non_consecutive": "[3, 7]",
    "consecutive_range": "[3-7]",
    "placement": "immediately after the claim, metric, statement, chart or data point it supports",
    "size_pt": [8, 9],
    "weight": "Regular",
    "colour_role": "muted",
    "line_spacing": [1.1, 1.2],
    "case": "sentence",
    "banned": ["bold", "uppercase", "coloured badges", "filled pills", "borders", "separate citation cards", "full source names inside components", "URLs inside components", "publication titles inside components"],
    "chart_form": "Source [3, 5]  — small line at the bottom of the visual",
    "table_form": "One table-level citation when the same sources support the table. Cell-level only when individual values come from different sources.",
    "grouping_threshold": 3,
    "appendix_threshold": 6,
    "global_index": true,
    "full_source_format": "[3] Gartner, Semiconductor Forecast, 2025",
    "layout_impact": "none — citations must never change component layout, shrink main content, or increase component height",
    "excluded_from_char_budget": true,
    "provenance": "DOC"
  },

  "palettes": {
    "provenance": "DERIVED",
    "why": "DOC names colour ROLES (neutral border, primary gradient, one accent, muted citation) but no hex values. These palettes bind the roles. Swap the hexes, keep the roles.",
    "default": "graphite_navy",
    "graphite_navy": {
      "primary": "1F3864",
      "accent": "C8102E",
      "ink": "1A1A1A",
      "body": "333333",
      "muted": "6E7278",
      "neutral_line": "D2D5DA",
      "neutral_fill": "F4F5F7",
      "surface": "FFFFFF",
      "positive": "1F7A54",
      "negative": "B3261E"
    },
    "slate_teal": {
      "primary": "12414A",
      "accent": "C2703B",
      "ink": "13191C",
      "body": "323A3D",
      "muted": "6B7578",
      "neutral_line": "D3D8D9",
      "neutral_fill": "F3F6F6",
      "surface": "FFFFFF",
      "positive": "1F7A54",
      "negative": "B3261E"
    },
    "ink_oxblood": {
      "primary": "23262B",
      "accent": "7A1F2B",
      "ink": "111316",
      "body": "31353B",
      "muted": "70757C",
      "neutral_line": "D6D8DC",
      "neutral_fill": "F5F5F7",
      "surface": "FFFFFF",
      "positive": "1F7A54",
      "negative": "B3261E"
    }
  },

  "layout": {
    "provenance": "DERIVED",
    "why": "DOC says 'use any layout/component combination, no fixed template' and 'content volume determines component size, spacing and structure', but numbers no geometry. This section is that geometry, plus the composition grammar the DOC implies. No DOC value is changed here.",

    "frame": {
      "region_gap_x_in": 0.24,
      "region_gap_y_in": 0.22,
      "region_gap_min_in": 0.16,
      "region_gap_max_in": 0.34,
      "band_gap_in": 0.20,
      "why": "Column gutters between REGIONS are wider than the gaps between stacked components inside one region (GAP_MIN 0.12 / GAP_NATURAL 0.20), because a vertical seam must read as a structural division, not a paragraph break."
    },

    "readability": {
      "advance_em_body": 0.50,
      "advance_em_header": 0.60,
      "min_chars_per_line": {
        "body": 32,
        "bullets": 30,
        "card_body": 24,
        "callout_label": 16,
        "rail_body": 20,
        "table_cell": 14,
        "annotation": 20,
        "chart_label": 8
      },
      "why": "Minimum component widths are DERIVED, not invented: min_w = min_chars_per_line x fontPt/72 x advance_em + 2 x padding. At 10pt body, advance is 0.0694in/char, so 32 characters needs 2.22in of text plus padding. Below that a column stops being prose and becomes a word ladder.",
      "max_chars_per_line": 110,
      "max_chars_per_line_note": "Past ~110 characters the eye loses the line return. A full-width 12.333in body paragraph at 9pt is ~197 chars/line, which is why running prose should be split into regions or bullets rather than set full-bleed."
    },

    "min_dims_in": {
      "body":        { "w": 2.40, "h": 0.42 },
      "bullets":     { "w": 2.60, "h": 0.46 },
      "header":      { "w": 1.60, "h": 0.22 },
      "cards_short": { "w": 2.20, "h": 0.78 },
      "cards":       { "w": 2.90, "h": 1.05 },
      "rail":        { "w": 1.60, "h": 0.70 },
      "callouts":    { "w": 1.90, "h": 0.78 },
      "kpi":         { "w": 1.90, "h": 0.78 },
      "table":       { "w": 4.20, "h": 0.90 },
      "chart":       { "w": 3.60, "h": 2.30 },
      "timeline":    { "w": 5.00, "h": 1.10 },
      "matrix":      { "w": 4.20, "h": 3.30 },
      "annotation":  { "w": 1.80, "h": 0.42 },
      "footnote":    { "w": 1.80, "h": 0.18 },
      "table_col_w": 0.62,
      "why": "A layout is INVALID if any region falls below these. The engine must change layout, not shrink type, when a region cannot hold its component."
    },

    "aspect": {
      "chart":  { "min": 0.90, "max": 2.60, "ideal": 1.55 },
      "matrix": { "min": 0.85, "max": 1.45, "ideal": 1.05 },
      "why": "w/h. A chart squeezed below 0.9 turns its legend into the subject; past 2.6 the series flatten and the trend disappears. A matrix must stay near square or its quadrants stop reading as quadrants."
    },

    "roles": {
      "enum": ["primary", "secondary", "supporting", "comparison", "evidence", "annotation", "summary", "context", "metadata"],
      "weight": {
        "primary": 1.00, "summary": 0.85, "comparison": 0.80, "secondary": 0.62,
        "evidence": 0.55, "supporting": 0.45, "context": 0.35, "annotation": 0.25, "metadata": 0.10
      },
      "slide_contract": [
        "exactly one dominant message (the title)",
        "exactly one primary content or visual anchor",
        "at most one secondary support layer",
        "optional annotation / metadata layer"
      ],
      "dominance_min_area_share": 0.40,
      "dominance_min_ratio_vs_secondary": 1.25,
      "why": "DOC: 'keep the primary message visually dominant' and 'prioritize information, not component count'. Two components at identical size with unequal importance is a hierarchy failure, not a symmetry win."
    },

    "density_model": {
      "unit": "complexity points, additive, evaluated ALONGSIDE the DOC character budget, never instead of it",
      "weights": {
        "per_component": 3,
        "per_text_heavy_component": 4,
        "per_region_column": 2,
        "per_table_row": 1.0,
        "per_table_column": 1.5,
        "per_chart_series": 1.5,
        "per_chart_category": 0.5,
        "per_nesting_level": 4,
        "per_distinct_source": 0.4
      },
      "bands": [
        { "name": "light",    "max": 22 },
        { "name": "workable", "max": 40 },
        { "name": "heavy",    "max": 56 },
        { "name": "overload", "max": null }
      ],
      "axes_note": "Vertical occupancy and content complexity are DIFFERENT axes and both must be evaluated. A 700-char slide of one chart is light; a 700-char slide of six cards, a 9-row table and two charts is overload. Character count alone never selects a layout.",
      "text_heavy_threshold_chars": 140
    },

    "scoring": {
      "weights": {
        "hierarchy_fit": 1.30,
        "readability": 1.50,
        "semantic_fit": 1.30,
        "compatibility": 1.00,
        "balance": 0.80,
        "alignment": 0.50,
        "source_fidelity": 1.00
      },
      "penalties": {
        "overflow": 30.0,
        "density": 1.00,
        "tiny_component": 18.0,
        "competition": 9.0,
        "whitespace": 0.90,
        "nesting": 5.0
      },
      "criteria_scale": [0, 10],
      "why": "The selected layout must be the best VALID composition, not the first valid one. Scores are comparable only within one slide."
    },

    "balance": {
      "target_fill_min": 0.62,
      "target_fill_max": 0.94,
      "max_side_imbalance": 0.28,
      "max_deadzone_share": 0.22,
      "max_area_variance_peer": 0.35,
      "why": "fill = occupied content-band area / total content-band area. Side imbalance is |left ink - right ink| / total ink and is only a defect when the two sides are PEER regions; an intentional 62/38 main+sidebar is not imbalance. A deadzone is a contiguous empty strip in the lower content band while the slide is at or above target characters."
    },

    "fallback_order": [
      "reflow within the same layout (re-wrap, redistribute, tighten gaps to region_gap_min)",
      "change layout to the next in the fallback chain",
      "consolidate related components into one region",
      "reduce non-essential spacing",
      "shorten redundant copy",
      "deprioritise optional content (move annotation/context out)",
      "split semantically at a sub-topic boundary"
    ],
    "fallback_note": "DOC escalation order, extended one step: reflow -> CHANGE LAYOUT -> consolidate -> shorten -> deprioritise -> split. Shrinking type is not in the list at any position.",

    "catalog": {
      "L01_SINGLE": {
        "use": "One dominant component owns the slide: a single chart, one wide table, one matrix, one full-width narrative.",
        "components": [1, 1],
        "accepts": ["chart", "table", "matrix", "timeline", "body", "bullets", "cards", "rail", "callouts"],
        "proportions": [[1.0]],
        "density": ["light", "workable", "heavy"],
        "avoid_when": "Two or more components of comparable importance exist; a single component would leave the lower half dead.",
        "fallbacks": ["L14_TABLE_INSIGHT", "L13_CHART_COMMENTARY", "L20_PAGINATED"],
        "validation": ["region >= min_dims for the component", "fill >= target_fill_min or the component is growable"]
      },
      "L02_SPLIT_EQUAL": {
        "use": "Two peer components of equal importance and comparable reading scale — two charts, two card sets, before/after.",
        "components": [2, 2],
        "accepts": ["chart", "cards", "callouts", "body", "bullets", "table", "rail"],
        "proportions": [[0.50, 0.50]],
        "density": ["light", "workable"],
        "avoid_when": "One side is materially more important (use L03/L04); either side is a detailed table; either side would fall below min width.",
        "fallbacks": ["L03_SPLIT_LEFT_DOMINANT", "L10_VERTICAL_STACK", "L20_PAGINATED"],
        "validation": ["both regions >= min_dims", "roles are peers", "no detailed table in a half-width region unless <= 4 columns"]
      },
      "L03_SPLIT_LEFT_DOMINANT": {
        "use": "Primary visual or argument on the left, subordinate support on the right. The default asymmetric split.",
        "components": [2, 2],
        "accepts": ["chart", "table", "matrix", "cards", "body", "bullets", "callouts", "timeline"],
        "proportions": [[0.62, 0.38]],
        "density": ["light", "workable", "heavy"],
        "avoid_when": "Both components are equally important; the right-hand content is longer than the left.",
        "fallbacks": ["L11_MAIN_SIDEBAR", "L02_SPLIT_EQUAL", "L10_VERTICAL_STACK"],
        "validation": ["right region >= min_dims of its component", "primary holds dominance_min_ratio_vs_secondary"]
      },
      "L04_SPLIT_RIGHT_DOMINANT": {
        "use": "Mirror of L03 when reading order should hit the setup first and the evidence second, or when the source exhibit sits right.",
        "components": [2, 2],
        "accepts": ["chart", "table", "matrix", "cards", "body", "bullets", "callouts"],
        "proportions": [[0.38, 0.62]],
        "density": ["light", "workable", "heavy"],
        "avoid_when": "No reason to invert normal left-to-right primacy; source fidelity does not call for it.",
        "fallbacks": ["L03_SPLIT_LEFT_DOMINANT", "L10_VERTICAL_STACK"],
        "validation": ["left region >= min_dims", "primary holds dominance"]
      },
      "L05_THREE_COLUMN": {
        "use": "Three compact peers: three metrics, three short cards, a three-way comparison with short cells.",
        "components": [3, 3],
        "accepts": ["cards", "callouts", "body", "chart", "rail"],
        "proportions": [[0.3333, 0.3333, 0.3333]],
        "density": ["light", "workable"],
        "avoid_when": "Any column carries more than ~220 characters, or content is detailed enough to need reading width.",
        "fallbacks": ["L12_MAIN_TWO_SUPPORT", "L07_GRID_2X2", "L10_VERTICAL_STACK"],
        "validation": ["every column >= min_dims", "longest column text <= 220 chars"]
      },
      "L06_FOUR_COLUMN": {
        "use": "Four compact KPIs or four one-line cards across the band.",
        "components": [4, 4],
        "accepts": ["callouts", "kpi", "cards", "rail"],
        "proportions": [[0.25, 0.25, 0.25, 0.25]],
        "density": ["light"],
        "avoid_when": "Any item exceeds ~120 characters, or items carry titles AND bodies AND citations.",
        "fallbacks": ["L07_GRID_2X2", "L05_THREE_COLUMN", "L10_VERTICAL_STACK"],
        "validation": ["every column >= min_dims", "longest item <= 120 chars"]
      },
      "L07_GRID_2X2": {
        "use": "Four detailed peers that each need reading width — four insight cards, four workstreams.",
        "components": [4, 4],
        "grid": { "rows": 2, "cols": 2 },
        "accepts": ["cards", "callouts", "chart", "body"],
        "proportions": [[0.50, 0.50], [0.50, 0.50]],
        "density": ["workable", "heavy"],
        "avoid_when": "Items are one-liners (wastes the width — use L06); items are unequal in importance.",
        "fallbacks": ["L10_VERTICAL_STACK", "L20_PAGINATED"],
        "validation": ["every cell >= cards min_dims", "row heights equalise within the row"]
      },
      "L08_GRID_2X3": {
        "use": "Six SHORT cards: 2 rows x 3 columns. Labels and one-line bodies only.",
        "components": [6, 6],
        "grid": { "rows": 2, "cols": 3 },
        "accepts": ["cards", "callouts", "rail"],
        "proportions": [[0.3333, 0.3333, 0.3333], [0.3333, 0.3333, 0.3333]],
        "density": ["workable"],
        "avoid_when": "Any card exceeds ~110 characters; the six items are a sequence (use a rail or timeline).",
        "fallbacks": ["L09_GRID_3X2", "L10_VERTICAL_STACK", "L20_PAGINATED"],
        "validation": ["every cell >= cards_short min_dims", "longest card <= 110 chars"]
      },
      "L09_GRID_3X2": {
        "use": "Six DETAILED cards: 3 rows x 2 columns. Wider columns buy reading width at the cost of vertical room.",
        "components": [6, 6],
        "grid": { "rows": 3, "cols": 2 },
        "accepts": ["cards", "callouts"],
        "proportions": [[0.50, 0.50], [0.50, 0.50], [0.50, 0.50]],
        "density": ["heavy"],
        "avoid_when": "Total character load is above the DOC soft maximum — six detailed cards usually means two slides.",
        "fallbacks": ["L20_PAGINATED", "L10_VERTICAL_STACK"],
        "validation": ["every cell >= cards min_dims", "three rows fit the content band at natural height"]
      },
      "L10_VERTICAL_STACK": {
        "use": "The default full-width flow: header, body, table, rail. The existing two-phase stack.",
        "components": [1, 6],
        "accepts": ["header", "body", "bullets", "cards", "rail", "callouts", "table", "chart", "timeline", "footnote"],
        "proportions": [[1.0]],
        "density": ["light", "workable", "heavy"],
        "avoid_when": "Two components are peers that invite comparison — side-by-side reads the comparison, stacking hides it.",
        "fallbacks": ["L20_PAGINATED"],
        "validation": ["sum of natural heights + gaps <= content height at minimum gap"]
      },
      "L11_MAIN_SIDEBAR": {
        "use": "A dominant exhibit with a persistent narrow commentary rail — the classic so-what rail.",
        "components": [2, 2],
        "accepts": ["chart", "table", "matrix", "timeline", "cards", "body", "bullets", "callouts"],
        "proportions": [[0.70, 0.30]],
        "density": ["workable", "heavy"],
        "avoid_when": "The sidebar would carry a detailed table, a chart, or more than ~320 characters.",
        "fallbacks": ["L03_SPLIT_LEFT_DOMINANT", "L10_VERTICAL_STACK"],
        "validation": ["sidebar >= annotation min_dims", "sidebar carries no table and no chart", "sidebar <= 320 chars"]
      },
      "L12_MAIN_TWO_SUPPORT": {
        "use": "One main visual plus two short supporting blocks stacked beside it.",
        "components": [3, 3],
        "accepts": ["chart", "table", "matrix", "timeline", "callouts", "body", "cards"],
        "proportions": [[0.62, 0.38]],
        "sub_stack": { "column": 1, "rows": 2 },
        "density": ["workable", "heavy"],
        "avoid_when": "The two supports are longer than the main component; the supports are peers of the main.",
        "fallbacks": ["L03_SPLIT_LEFT_DOMINANT", "L10_VERTICAL_STACK", "L20_PAGINATED"],
        "validation": ["each support >= min_dims", "each support <= 200 chars", "main holds dominance"]
      },
      "L13_CHART_COMMENTARY": {
        "use": "A chart with its reading — the single most common consulting exhibit page.",
        "components": [2, 2],
        "accepts": ["chart", "body", "bullets", "callouts", "cards"],
        "proportions": [[0.60, 0.40]],
        "density": ["light", "workable", "heavy"],
        "avoid_when": "Commentary exceeds ~420 characters (stack it instead); the chart has more than 6 series or a legend wider than the plot.",
        "fallbacks": ["L11_MAIN_SIDEBAR", "L10_VERTICAL_STACK", "L20_PAGINATED"],
        "validation": ["chart region within aspect band", "chart >= chart min_dims", "commentary >= body min_dims"]
      },
      "L14_TABLE_INSIGHT": {
        "use": "A full-width table with a concise takeaway above or below it.",
        "components": [2, 2],
        "accepts": ["table", "callouts", "body", "bullets"],
        "proportions": [[1.0], [1.0]],
        "band_split": [0.72, 0.28],
        "density": ["workable", "heavy"],
        "avoid_when": "The takeaway is longer than three lines — it is then a body block in a stack, not an insight strip.",
        "fallbacks": ["L10_VERTICAL_STACK", "L20_PAGINATED"],
        "validation": ["table full width", "insight <= 260 chars", "every table column >= table_col_w"]
      },
      "L15_KPI_CHART": {
        "use": "A KPI strip across the top, the chart that explains it beneath.",
        "components": [2, 2],
        "accepts": ["callouts", "kpi", "chart", "table"],
        "proportions": [[1.0], [1.0]],
        "band_split": [0.26, 0.74],
        "density": ["light", "workable"],
        "avoid_when": "More than 4 KPIs (they become a list, not a set of insights — DOC callout rule); the chart would drop below its min height.",
        "fallbacks": ["L13_CHART_COMMENTARY", "L10_VERTICAL_STACK"],
        "validation": ["kpi count <= 4", "chart region >= chart min_dims and within aspect band"]
      },
      "L16_TIMELINE": {
        "use": "A sequence with dates or stages. Horizontal when events are few and labels short; vertical when entries carry prose.",
        "components": [1, 2],
        "accepts": ["timeline", "body", "callouts", "cards"],
        "proportions": [[1.0]],
        "orientation_rule": "horizontal if events <= 6 AND max event text <= 90 chars; else vertical; else paginate",
        "density": ["light", "workable"],
        "avoid_when": "Chronology is not the point of the slide; more than 8 events.",
        "fallbacks": ["L10_VERTICAL_STACK", "L20_PAGINATED"],
        "validation": ["per-event width >= timeline min item width", "chronological order preserved"]
      },
      "L17_MATRIX": {
        "use": "A 2x2 or positioning matrix as the primary visual, with short side annotations.",
        "components": [1, 2],
        "accepts": ["matrix", "body", "bullets", "callouts"],
        "proportions": [[0.66, 0.34]],
        "density": ["light", "workable"],
        "avoid_when": "Quadrants would carry paragraphs; a detailed table accompanies it (separate the two).",
        "fallbacks": ["L01_SINGLE", "L10_VERTICAL_STACK"],
        "validation": ["matrix within aspect band", "axis labels legible at chart_label size", "quadrant text <= 90 chars each"]
      },
      "L18_COMPARISON": {
        "use": "Structured N-way comparison across a consistent set of dimensions.",
        "components": [2, 4],
        "accepts": ["table", "cards", "callouts", "chart"],
        "proportions": [[0.50, 0.50], [0.3333, 0.3333, 0.3333], [0.25, 0.25, 0.25, 0.25]],
        "density": ["workable", "heavy"],
        "avoid_when": "Cells carry more than ~150 characters with 3+ options — use a table instead of columns.",
        "fallbacks": ["L14_TABLE_INSIGHT", "L10_VERTICAL_STACK", "L20_PAGINATED"],
        "validation": ["identical dimension set across every option", "column >= min_dims", "consistent internal ordering"]
      },
      "L19_HIERARCHICAL": {
        "use": "A thesis stated once across the top, with the evidence that supports it beneath.",
        "components": [2, 5],
        "accepts": ["callouts", "body", "cards", "chart", "table", "rail"],
        "proportions": [[1.0]],
        "band_split": [0.30, 0.70],
        "density": ["workable", "heavy"],
        "avoid_when": "The top block is not actually a thesis — a header is not a thesis.",
        "fallbacks": ["L10_VERTICAL_STACK", "L20_PAGINATED"],
        "validation": ["thesis <= 260 chars", "support row items >= min_dims", "thesis carries the strongest visual weight"]
      },
      "L20_PAGINATED": {
        "use": "Terminal fallback: the content is a coherent whole that does not fit one slide at minimum readable geometry.",
        "components": [1, 99],
        "accepts": ["*"],
        "proportions": [[1.0]],
        "density": ["overload"],
        "avoid_when": "A layout change would have solved it — pagination is the last step of the escalation order, never the first.",
        "fallbacks": [],
        "validation": ["split at a sub-topic boundary", "no continuation slide holds a single orphaned component", "continuation title carries '(cont.)' or restates the sub-topic"]
      }
    }
  }
}

````

## FILE: `assets/example_spec.json`

````json
{
  "deck": "Project Ardent — Del Real Foods",
  "palette": "graphite_navy",
  "slides": [
    {
      "id": "s1", "section": "company", "eyebrow": "COMPANY",
      "title": "Del Real Foods is a refrigerated Hispanic heat-and-eat manufacturer with concentrated customer exposure",
      "blocks": [
        { "type": "body", "body": "The company sells branded meal components and full meal solutions through retail, club, grocery, foodservice, institutional and online channels, with revenue recognised when products ship or are delivered.", "cite": [1] },
        { "type": "callout", "items": [
          { "value": "46.74%", "label": "Value-added meats revenue share", "cite": [194] },
          { "value": ">60%", "label": "Top 10 customer concentration", "cite": [1] },
          { "value": "500+", "label": "Mira Loma plant workers", "cite": [184] }
        ] }
      ]
    },
    {
      "id": "s2", "section": "company", "eyebrow": "COMPANY",
      "title": "Why the concentration matters",
      "blocks": [
        { "type": "bullets", "bullets": [
          "Concentration above 60% in the top ten accounts makes customer retention the single largest downside driver in the base case."
        ] }
      ]
    },
    {
      "id": "s3", "section": "footprint", "eyebrow": "FOOTPRINT",
      "title": "Club-store placement concentrates presence in the West and Southeast",
      "blocks": [
        { "type": "table",
          "headers": ["Region", "Presence", "Key markets and strategic role"],
          "rows": [
            ["Northwest", "Major", "Portland, Salem, Central Point — club placement extended reach for ready-in-minutes meals."],
            ["Los Angeles", "Major", "Inglewood, Marina del Rey, Norwalk — club placement opened a prepared-foods outlet."],
            ["Southeast", "Major", "Atlanta, Charlotte, Myrtle Beach — club placement gave Southeast distribution."],
            ["Midwest", "Moderate", "Chicago, Plainfield, Middleton — no 2016 club placement left the region uncovered."],
            ["Texas", "Moderate", "Frisco, Fort Worth — no 2016 club placement left the region uncovered."]
          ],
          "zebra": false, "has_tags": true, "cite": [1, 184] }
      ]
    },
    {
      "id": "s4", "section": "mna", "eyebrow": "M&A",
      "title": "Acquiring a frozen adjacency broadens format mix and hedges bid exposure",
      "blocks": [
        { "type": "body", "body": "A frozen-adjacent asset improves the weaker position in price-sensitive institutional bids and ultra-low-cost channels.", "cite": [52, 53] },
        { "type": "rail", "items": [
          { "title": "Padrino Foods", "body": "Adjacent frozen and authentic Mexican depth.", "cite": [66, 67, 68, 69] },
          { "title": "Texas Tamale Company", "body": "Frozen tamale platform with regional appeal.", "cite": [70, 71, 72, 73, 74] },
          { "title": "Tucson Foods", "body": "Frozen shelf-life and tamale adjacency.", "cite": [55, 56, 57, 58, 59, 60] }
        ] }
      ]
    }
  ]
}

````

## FILE: `assets/example_spec_v2.json`

````json
{
  "deck": "Project Ardent — Del Real Foods",
  "palette": "graphite_navy",
  "cover": {
    "eyebrow": "COMMERCIAL DD",
    "title": "Project Ardent — refrigerated Hispanic foods",
    "subtitle": "Channel position, customer concentration and the frozen adjacency case",
    "client": "Prepared for the Investment Committee",
    "date": "September 2026"
  },
  "sections": [
    {
      "key": "company",
      "title": "Company and channel position"
    },
    {
      "key": "footprint",
      "title": "Regional footprint"
    },
    {
      "key": "mna",
      "title": "M&A adjacency"
    }
  ],
  "slides": [
    {
      "id": "s1",
      "section": "company",
      "eyebrow": "CHANNEL",
      "exhibit": "Exhibit 1",
      "title": "Club placement drives half of gross sales but concentrates the customer base",
      "note": "Gross sales before trade spend; 2016E reflects management estimates.",
      "blocks": [
        {
          "type": "chart",
          "title": "Gross sales by channel, 2016E ($m)",
          "chartType": "bar",
          "role": "primary",
          "labels": [
            "Club",
            "Retail",
            "Foodservice",
            "Institutional",
            "Online"
          ],
          "series": [
            {
              "name": "2016E",
              "values": [
                42.1,
                31.4,
                18.2,
                7.6,
                2.1
              ]
            }
          ],
          "cite": [
            194
          ],
          "highlight": 0
        },
        {
          "type": "bullets",
          "role": "supporting",
          "items": [
            {
              "text": "Club is the single largest channel and the one with the fewest decision makers.",
              "cite": [
                1
              ]
            },
            {
              "text": "Traditional grocery remains the largest branded whitespace.",
              "cite": [
                51
              ]
            },
            {
              "text": "Foodservice scales only after operator pull-through is proven.",
              "cite": [
                199
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "s2",
      "section": "company",
      "eyebrow": "SCALE",
      "exhibit": "Exhibit 2",
      "title": "Volume growth has outpaced price across every format since 2014",
      "blocks": [
        {
          "type": "callouts",
          "role": "summary",
          "items": [
            {
              "value": "46.7%",
              "label": "Value-added meats revenue share",
              "cite": [
                194
              ]
            },
            {
              "value": ">60%",
              "label": "Top 10 customer concentration",
              "cite": [
                1
              ]
            },
            {
              "value": "500+",
              "label": "Mira Loma plant workers",
              "cite": [
                184
              ]
            }
          ]
        },
        {
          "type": "chart",
          "title": "Net revenue by year ($m)",
          "chartType": "line",
          "labels": [
            "2014",
            "2015",
            "2016E",
            "2017P",
            "2018P"
          ],
          "series": [
            {
              "name": "Retail",
              "values": [
                18.2,
                22.6,
                31.4,
                35.1,
                38.4
              ]
            },
            {
              "name": "Club",
              "values": [
                21.4,
                33.8,
                42.1,
                44.0,
                45.2
              ]
            }
          ],
          "cite": [
            194
          ],
          "sourceLine": true
        }
      ]
    },
    {
      "id": "s3",
      "section": "footprint",
      "eyebrow": "FOOTPRINT",
      "exhibit": "Exhibit 3",
      "title": "Club-store placement concentrates presence in the West and Southeast",
      "blocks": [
        {
          "type": "table",
          "role": "primary",
          "headers": [
            "Region",
            "Presence",
            "Key markets and strategic role"
          ],
          "rows": [
            [
              "Northwest",
              "Major",
              "Portland, Salem, Central Point — club placement extended reach."
            ],
            [
              "Los Angeles",
              "Major",
              "Inglewood, Marina del Rey, Norwalk — prepared-foods outlet."
            ],
            [
              "Southeast",
              "Major",
              "Atlanta, Charlotte, Myrtle Beach — club gave distribution."
            ],
            [
              "Midwest",
              "Moderate",
              "Chicago, Plainfield, Middleton — no 2016 club placement."
            ],
            [
              "Texas",
              "Moderate",
              "Frisco, Fort Worth — no 2016 club placement."
            ]
          ],
          "zebra": false,
          "has_tags": true,
          "cite": [
            1,
            184
          ]
        },
        {
          "type": "callouts",
          "role": "evidence",
          "items": [
            {
              "value": "2 of 5",
              "label": "Regions uncovered rather than lost — absence of placement, not loss of it",
              "cite": [
                1
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "s4",
      "section": "mna",
      "eyebrow": "M&A",
      "exhibit": "Exhibit 4",
      "title": "Four adjacency criteria separate a format hedge from a distraction",
      "blocks": [
        {
          "type": "cards",
          "items": [
            {
              "title": "Format hedge",
              "body": "Frozen improves the weaker position in price-sensitive institutional bids and ultra-low-cost channels.",
              "cite": [
                52
              ]
            }
          ]
        },
        {
          "type": "cards",
          "items": [
            {
              "title": "Shelf-life arbitrage",
              "body": "Frozen shelf life removes the distribution ceiling that refrigerated formats impose on national club rollouts.",
              "cite": [
                55
              ]
            }
          ]
        },
        {
          "type": "cards",
          "items": [
            {
              "title": "Authenticity depth",
              "body": "Regional Mexican depth is the defensible half of the brand and is hard to replicate through private label.",
              "cite": [
                66
              ]
            }
          ]
        },
        {
          "type": "cards",
          "items": [
            {
              "title": "Capacity headroom",
              "body": "Any target must bring usable capacity, not just revenue, or the deal simply relocates the constraint.",
              "cite": [
                70
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "s5",
      "section": "mna",
      "eyebrow": "M&A",
      "exhibit": "Exhibit 5",
      "title": "Padrino leads on adjacency depth; Tucson leads on capacity headroom",
      "blocks": [
        {
          "type": "matrix",
          "role": "primary",
          "x_label": "Capacity headroom",
          "y_label": "Adjacency depth",
          "quadrants": [
            "Depth, no room",
            "Priority targets",
            "Capacity plays",
            "Deprioritise"
          ],
          "items": [
            {
              "label": "Padrino Foods",
              "x": 0.34,
              "y": 0.82,
              "cite": [
                66
              ]
            },
            {
              "label": "Texas Tamale",
              "x": 0.52,
              "y": 0.58,
              "cite": [
                70
              ]
            },
            {
              "label": "Tucson Foods",
              "x": 0.81,
              "y": 0.44,
              "accent": true,
              "cite": [
                55
              ]
            }
          ]
        },
        {
          "type": "bullets",
          "role": "annotation",
          "items": [
            {
              "text": "Only Tucson clears the capacity test outright.",
              "cite": [
                55
              ]
            },
            {
              "text": "Padrino needs a co-pack solution to be viable.",
              "cite": [
                66
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "s6",
      "section": "mna",
      "eyebrow": "SEQUENCING",
      "exhibit": "Exhibit 6",
      "title": "Sequencing the adjacency after the club renewal protects the base case",
      "blocks": [
        {
          "type": "timeline",
          "role": "primary",
          "items": [
            {
              "label": "Q1 FY27",
              "body": "Club renewal closed",
              "cite": [
                1
              ]
            },
            {
              "label": "Q2 FY27",
              "body": "Co-pack trial live",
              "cite": [
                52
              ]
            },
            {
              "label": "Q4 FY27",
              "body": "Target LOI signed",
              "cite": [
                66
              ]
            },
            {
              "label": "Q2 FY28",
              "body": "Integration complete",
              "cite": [
                70
              ]
            }
          ]
        },
        {
          "type": "body",
          "role": "supporting",
          "body": "Closing the club renewal before any letter of intent keeps the base case independent of integration risk; a target signed earlier would put two execution programmes on the same management team in the same year.",
          "cite": [
            1,
            52
          ]
        }
      ]
    }
  ],
  "sources": {
    "1": "Company management presentation, 2016",
    "51": "Nielsen, Refrigerated Prepared Foods Scan Data, 2016",
    "52": "Company management interview, foodservice, 2016",
    "53": "IBISWorld, Frozen Food Production in the US, 2016",
    "55": "Tucson Foods company filings, 2016",
    "56": "Tucson Foods plant capacity schedule, 2016",
    "66": "Padrino Foods company website and product catalogue, 2016",
    "67": "Padrino Foods distributor interviews, 2016",
    "70": "Texas Tamale Company website, 2016",
    "71": "Texas Tamale Company capacity estimate, management, 2016",
    "184": "Mira Loma facility tour notes, 2016",
    "194": "Company financial data book, gross sales by channel, 2016E",
    "199": "Broadline distributor interviews, 2016"
  }
}
````

## FILE: `scripts/layout_engine.py`

````python
#!/usr/bin/env python3
"""
layout_engine.py — the deterministic half of the pe-deck-design skill.

Runs BEFORE any .pptx is written. Takes a content spec (JSON), and for each
slide returns: character load, density band, the resolved typography scale,
per-component verdicts, and pagination/merge instructions.

Nothing here is a matter of taste. Every threshold traces to a token in
assets/design-tokens.json, which in turn traces to the source specification.

Usage
-----
    python3 scripts/layout_engine.py spec.json                 # human report
    python3 scripts/layout_engine.py spec.json --json          # machine plan
    python3 scripts/layout_engine.py spec.json --json -o plan.json
    python3 scripts/layout_engine.py --selftest

Spec format
-----------
{
  "deck": "Project Ardent — Del Real Foods",
  "palette": "graphite_navy",
  "slides": [
    {
      "id": "s2",
      "section": "channel",
      "title": "Traditional grocery is the largest branded whitespace",
      "eyebrow": "CHANNEL STRATEGY",
      "blocks": [
        {"type": "callout", "items": [
            {"value": "46.74%", "label": "Value-added meats rev share", "cite": [1]}]},
        {"type": "cards", "title": "Priority strategies", "items": [
            {"title": "Win traditional grocery first", "body": "...", "cite": [194, 184, 51]}]},
        {"type": "table", "title": "Regional presence",
         "headers": ["Region", "Presence", "Key markets & strategic role"],
         "rows": [["Northwest", "Major", "Portland, Salem, Central Point — ..."]],
         "has_tags": true, "zebra": false, "cite": [12]},
        {"type": "rail", "items": [{"title": "Format hedge", "body": "..."}]},
        {"type": "text", "body": "..."},
        {"type": "chart", "title": "Gross sales by channel",
         "labels": ["Club", "Retail", "Foodservice"], "cite": [194]},
        {"type": "footnote", "body": "Management estimates, 2016E."}
      ]
    }
  ]
}

Every block type is optional. `cite` is always a list of ints and is always
excluded from the character budget — citations are metadata, not content.
"""

import argparse
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOKENS_PATH = os.path.join(HERE, "..", "assets", "design-tokens.json")

# Blocks whose text is metadata, not content, and is excluded from the budget.
METADATA_BLOCKS = {"footnote", "source", "citation", "pagenum"}


# --------------------------------------------------------------------------
# tokens
# --------------------------------------------------------------------------

def load_tokens(path=TOKENS_PATH):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


# --------------------------------------------------------------------------
# character budget
# --------------------------------------------------------------------------

_CITE_RE = re.compile(r"\[\s*\d+(?:\s*[,\u2013-]\s*\d+)*\s*\]")


def visible_chars(text):
    """Character count of one string, with inline [n] citations stripped."""
    if not text:
        return 0
    return len(_CITE_RE.sub("", str(text)).strip())


def _block_chars(block):
    """Visible characters contributed by a single content block."""
    btype = block.get("type", "text")
    if btype in METADATA_BLOCKS:
        return 0

    total = visible_chars(block.get("title", ""))
    total += visible_chars(block.get("subtitle", ""))
    total += visible_chars(block.get("body", ""))

    for item in block.get("items", []):
        if isinstance(item, str):
            total += visible_chars(item)
            continue
        for key in ("title", "label", "value", "body", "sublabel"):
            total += visible_chars(item.get(key, ""))

    for bullet in block.get("bullets", []):
        total += visible_chars(bullet)

    if btype == "table":
        for header in block.get("headers", []):
            total += visible_chars(header)
        for row in block.get("rows", []):
            for cell in row:
                total += visible_chars(cell)

    if btype == "chart":
        for label in block.get("labels", []):
            total += visible_chars(label)
        for label in block.get("series_names", []):
            total += visible_chars(label)

    return total


def slide_chars(slide):
    """Total visible character load for a slide, per the DOC engineering formula."""
    total = visible_chars(slide.get("title", ""))
    total += visible_chars(slide.get("subtitle", ""))
    total += visible_chars(slide.get("eyebrow", ""))
    for block in slide.get("blocks", []):
        total += _block_chars(block)
    return total


# --------------------------------------------------------------------------
# density band -> typography scale
# --------------------------------------------------------------------------

def classify(chars, tokens):
    """Map a character load onto a density band and its prescribed action."""
    for band in tokens["density"]["bands"]:
        if band["max"] is None or chars <= band["max"]:
            return band["name"], band["action"]
    return "overflow", "Recompose."


def resolve_scale(band, tokens):
    """
    Density band -> concrete point size per role.

    'sparse' and 'balanced' and 'dense' are real scales. 'overflow' is not a
    scale: it is a recomposition order. It clamps to dense so the caller still
    gets usable numbers, but the verdict must stay FAIL.
    """
    key = band if band in tokens["type"]["scales"] else "dense"
    return dict(tokens["type"]["scales"][key])


def validate_scale(scale, tokens):
    """Assert every resolved size sits inside its DOC-defined range."""
    problems = []
    ranges = tokens["type"]["role_ranges_doc"]
    for role, size in scale.items():
        spec = ranges.get(role)
        if not spec:
            continue
        lo, hi = spec[0], spec[1]
        if not (lo <= size <= hi):
            problems.append(f"{role} resolved to {size}pt, outside DOC range {lo}-{hi}pt")
    return problems


# --------------------------------------------------------------------------
# component verdicts
# --------------------------------------------------------------------------

def _count_verdict(kind, n, tokens):
    """Apply the DOC count thresholds for cards / rail / callout."""
    if kind == "cards":
        if n <= 3:
            return "OK", "Larger cards, stronger typography, more internal whitespace."
        if n <= 6:
            return "OK", "Reduce card width and spacing; keep content readable."
        return "FAIL", (f"{n} cards. Do not shrink further — switch to a rail or a "
                        f"grouped structure.")
    if kind == "rail":
        if n < 2:
            return "WARN", "A rail of one item is a callout. Use a callout."
        if n <= 4:
            return "OK", "Larger item widths, generous spacing."
        if n <= 6:
            return "OK", "Compact spacing, smaller item widths."
        return "FAIL", f"{n} rail items. Split the rail or change the component."
    if kind == "callout":
        if n == 1:
            return "OK", "Strong emphasis, generous whitespace."
        if n == 2:
            return "OK", "Balance by content length; equal heights not required."
        if n <= 4:
            return "WARN", (f"{n} callouts. Justify that each is a distinct insight, "
                            f"otherwise combine.")
        return "FAIL", f"{n} callouts. Combine — this is a list, not a set of insights."
    return "OK", ""


def _table_verdict(block, tokens):
    """DOC table rules that are checkable from the spec alone."""
    findings = []
    rows = block.get("rows", [])
    headers = block.get("headers", [])

    if not headers:
        findings.append(("WARN", "Table has no header row; column hierarchy is unclear."))

    # Wrap pressure. ~62 chars per descriptive column line at 8-9pt in a
    # typical 3-4 column consulting table. Two lines is the DOC ceiling.
    long_cells = 0
    for row in rows:
        for cell in row:
            if visible_chars(cell) > 124:
                long_cells += 1
    if long_cells:
        findings.append((
            "FAIL",
            f"{long_cells} cell(s) will exceed 2 wrapped lines. DOC: restructure the "
            f"table — do not reduce the font."))

    # Zebra vs tags — the DOC's sharpest table rule.
    if block.get("zebra") and block.get("has_tags"):
        findings.append((
            "FAIL",
            "Zebra striping is on and the rows carry tags/pills/labels. DOC bans this "
            "combination. Keep the background uniform and let the tags differentiate."))
    if block.get("zebra") and block.get("highlight_rows"):
        findings.append((
            "FAIL",
            "Zebra striping combined with highlighted rows creates visual noise. Pick one."))
    if not block.get("zebra") and not block.get("has_tags") and len(rows) >= 8:
        findings.append((
            "INFO",
            f"{len(rows)} data-only rows and no tags — subtle zebra striping is "
            f"permitted here and will aid row scanning."))

    if len(rows) > 12:
        findings.append((
            "WARN",
            f"{len(rows)} rows. Consider splitting at a logical grouping boundary."))

    if headers and rows:
        widths = {len(r) for r in rows}
        if widths != {len(headers)}:
            findings.append((
                "FAIL",
                f"Ragged table: header has {len(headers)} columns, rows have {sorted(widths)}."))

    return findings


def component_report(slide, tokens):
    """Per-block verdicts for one slide."""
    out = []
    for block in slide.get("blocks", []):
        btype = block.get("type", "text")
        n = len(block.get("items", []))
        if btype in ("cards", "rail", "callout"):
            status, msg = _count_verdict(btype, n, tokens)
            out.append({"block": btype, "count": n, "status": status, "message": msg})
        elif btype == "table":
            for status, msg in _table_verdict(block, tokens):
                out.append({"block": "table", "count": len(block.get("rows", [])),
                            "status": status, "message": msg})
        elif btype == "text":
            chars = _block_chars(block)
            if chars > 480:
                out.append({"block": "text", "count": chars, "status": "WARN",
                            "message": (f"{chars} characters of running prose. Convert to "
                                        f"cards, a rail, or bullets — this is a deck, not a memo.")})
    return out


# --------------------------------------------------------------------------
# citation integrity
# --------------------------------------------------------------------------

_URLISH = re.compile(r"(https?://|www\.)", re.I)


def citation_report(slide):
    """
    DOC: numbered citations only, no URLs or source names inside components,
    grouped references past 3 sources, appendix past 6-8 per slide.
    """
    findings = []
    slide_sources = set()

    def scan(text, where):
        if not text:
            return
        text = str(text)
        if _URLISH.search(text):
            findings.append({"status": "FAIL",
                             "message": f"Raw URL inside {where}. Use a numbered citation and "
                                        f"put the full source in the appendix."})
        for match in _CITE_RE.finditer(text):
            for num in re.findall(r"\d+", match.group()):
                slide_sources.add(int(num))

    scan(slide.get("title"), "slide title")
    for block in slide.get("blocks", []):
        where = block.get("type", "block")
        scan(block.get("title"), where + " title")
        scan(block.get("body"), where + " body")
        for item in block.get("items", []):
            if isinstance(item, dict):
                for key in ("title", "body", "value", "label"):
                    scan(item.get(key), where + " item")
                for num in item.get("cite", []):
                    slide_sources.add(int(num))
            else:
                scan(item, where + " item")
        for row in block.get("rows", []):
            for cell in row:
                scan(cell, "table cell")
        for num in block.get("cite", []):
            slide_sources.add(int(num))
        if len(block.get("cite", [])) > 3:
            findings.append({
                "status": "INFO",
                "message": f"{where} cites {len(block['cite'])} sources — emit a grouped "
                           f"reference such as [55-60], not a list of names."})

    if len(slide_sources) > 8:
        findings.append({
            "status": "WARN",
            "message": f"{len(slide_sources)} distinct sources on this slide. Keep [n] markers "
                       f"on the slide and move the full list to the References appendix."})
    return findings, sorted(slide_sources)


def format_citation(nums):
    """
    [3] · [3, 7] · [3-7]. Collapses runs of 3 or more consecutive numbers.
    """
    nums = sorted({int(n) for n in nums})
    if not nums:
        return ""
    parts, start, prev = [], nums[0], nums[0]
    for num in nums[1:] + [None]:
        if num is not None and num == prev + 1:
            prev = num
            continue
        if prev - start >= 2:
            parts.append(f"{start}-{prev}")
        elif prev != start:
            parts.extend([str(start), str(prev)])
        else:
            parts.append(str(start))
        if num is not None:
            start = prev = num
    return "[" + ", ".join(parts) + "]"


# --------------------------------------------------------------------------
# pagination / merge
# --------------------------------------------------------------------------

def pagination_plan(slides, tokens):
    """
    DOC decision rule: Fit + Related + Readable -> merge.
    Otherwise -> new slide. Never merge unrelated content to fill space.
    """
    target_max = tokens["density"]["target_max"]
    sparse_ceiling = tokens["density"]["bands"][0]["max"]
    plan = []

    for i, slide in enumerate(slides):
        chars = slide_chars(slide)
        nxt = slides[i + 1] if i + 1 < len(slides) else None
        action = {"id": slide.get("id", f"slide{i+1}"), "action": "keep", "reason": ""}

        if chars > tokens["density"]["hard_max"]:
            action["action"] = "split"
            action["reason"] = (
                f"{chars} chars exceeds the {tokens['density']['hard_max']} hard maximum. "
                f"Split at a logical sub-topic boundary — move a meaningful sub-topic, not "
                f"leftover content. The continuation slide must feel complete on its own.")
        elif nxt is not None and chars <= sparse_ceiling:
            related = slide.get("section") and slide.get("section") == nxt.get("section")
            combined = chars + slide_chars(nxt)
            if related and combined <= target_max:
                action["action"] = "merge_next"
                action["reason"] = (
                    f"{chars} chars, same section as '{nxt.get('id')}', combined {combined} "
                    f"chars is within the {target_max} target. Fit + Related + Readable -> merge.")
            elif not related:
                action["reason"] = (
                    f"{chars} chars is sparse, but the next slide is a different section. "
                    f"DOC: never merge unrelated content only to fill empty space. "
                    f"Scale typography up and increase whitespace instead.")
            else:
                action["reason"] = (
                    f"Sparse ({chars} chars) but merging would reach {combined} chars, past "
                    f"the {target_max} target. Keep separate and scale up.")
        plan.append(action)
    return plan


# --------------------------------------------------------------------------
# top level
# --------------------------------------------------------------------------

def analyse(spec, tokens):
    slides = spec.get("slides", [])
    merge = pagination_plan(slides, tokens)
    results = []

    for i, slide in enumerate(slides):
        chars = slide_chars(slide)
        band, action = classify(chars, tokens)
        scale = resolve_scale(band, tokens)
        cites, sources = citation_report(slide)

        components = component_report(slide, tokens)
        statuses = [c["status"] for c in components] + [c["status"] for c in cites]
        verdict = "FAIL" if ("FAIL" in statuses or band == "overflow") else \
                  ("WARN" if "WARN" in statuses else "PASS")

        results.append({
            "id": slide.get("id", f"slide{i+1}"),
            "section": slide.get("section"),
            "title": slide.get("title", ""),
            "chars": chars,
            "band": band,
            "band_action": action,
            "scale": scale,
            "scale_problems": validate_scale(scale, tokens),
            "components": components,
            "citations": cites,
            "sources": sources,
            "source_marker": format_citation(sources),
            "pagination": merge[i],
            "verdict": verdict,
        })

    all_sources = sorted({s for r in results for s in r["sources"]})
    return {
        "deck": spec.get("deck", "Untitled"),
        "palette": spec.get("palette", tokens["palettes"]["default"]),
        "canvas": tokens["canvas"],
        "grid": tokens["grid"],
        "fonts": tokens["type"]["fonts"],
        "slides": results,
        "source_index": all_sources,
        "deck_verdict": "FAIL" if any(r["verdict"] == "FAIL" for r in results) else
                        ("WARN" if any(r["verdict"] == "WARN" for r in results) else "PASS"),
    }


ICON = {"OK": "OK", "PASS": "PASS", "WARN": "WARN", "FAIL": "FAIL", "INFO": "INFO"}


def render(report):
    lines = []
    add = lines.append
    add("=" * 78)
    add(f"  {report['deck']}")
    add(f"  palette {report['palette']}   "
        f"canvas {report['canvas']['width_in']}x{report['canvas']['height_in']}in   "
        f"{report['fonts']['header']}/{report['fonts']['body']}")
    add("=" * 78)

    for s in report["slides"]:
        add("")
        add(f"[{s['verdict']}] {s['id']}  ({s['section'] or 'no section'})")
        add(f"  {s['title'][:72]}")
        add(f"  {s['chars']} chars -> {s['band'].upper()} scale")
        add(f"  {s['band_action']}")
        add(f"  type: title {s['scale']['title']}pt / header {s['scale']['header']}pt / "
            f"body {s['scale']['body']}pt / table {s['scale']['table_body']}pt / "
            f"footnote {s['scale']['footnote']}pt")
        for problem in s["scale_problems"]:
            add(f"  !! {problem}")
        for c in s["components"]:
            add(f"  [{ICON[c['status']]}] {c['block']} x{c['count']}: {c['message']}")
        for c in s["citations"]:
            add(f"  [{ICON[c['status']]}] citation: {c['message']}")
        if s["sources"]:
            add(f"  sources on slide: {s['source_marker']}")
        if s["pagination"]["action"] != "keep":
            add(f"  >> {s['pagination']['action'].upper()}: {s['pagination']['reason']}")
        elif s["pagination"]["reason"]:
            add(f"  -- {s['pagination']['reason']}")

    add("")
    add("-" * 78)
    add(f"deck verdict: {report['deck_verdict']}")
    add(f"global source index: {len(report['source_index'])} sources "
        f"-> one References slide, one number per source, deck-wide.")
    return "\n".join(lines)


# --------------------------------------------------------------------------
# selftest
# --------------------------------------------------------------------------

def selftest():
    tokens = load_tokens()
    failures = []

    def check(name, got, want):
        if got != want:
            failures.append(f"{name}: got {got!r}, want {want!r}")

    check("cite strip", visible_chars("Grow foodservice [199, 200, 201]."), len("Grow foodservice ."))
    check("cite range", format_citation([3, 4, 5, 6, 7]), "[3-7]")
    check("cite pair", format_citation([3, 7]), "[3, 7]")
    check("cite single", format_citation([3]), "[3]")
    check("cite mixed", format_citation([1, 2, 3, 9]), "[1-3, 9]")
    check("band sparse", classify(400, tokens)[0], "sparse")
    check("band balanced", classify(800, tokens)[0], "balanced")
    check("band dense", classify(1100, tokens)[0], "dense")
    check("band overflow", classify(1500, tokens)[0], "overflow")

    for band in ("sparse", "balanced", "dense"):
        problems = validate_scale(resolve_scale(band, tokens), tokens)
        if problems:
            failures.append(f"scale {band} outside DOC ranges: {problems}")
        scale = resolve_scale(band, tokens)
        if not (scale["title"] > scale["header"] > scale["body"] >= scale["table_body"]
                >= scale["footnote"]):
            failures.append(f"scale {band} breaks hierarchy: {scale}")

    zebra_fail = _table_verdict({"rows": [["a", "b"]], "headers": ["a", "b"],
                                 "zebra": True, "has_tags": True}, tokens)
    if not any(s == "FAIL" for s, _ in zebra_fail):
        failures.append("zebra+tags must FAIL")

    if failures:
        print("SELFTEST FAILED")
        for f in failures:
            print("  -", f)
        return 1
    print(f"SELFTEST PASSED  ({8 + 3 * 2 + 1} assertions)")
    return 0


def main():
    ap = argparse.ArgumentParser(description="pe-deck-design layout engine")
    ap.add_argument("spec", nargs="?", help="path to the content spec JSON")
    ap.add_argument("--json", action="store_true", help="emit the machine plan")
    ap.add_argument("-o", "--out", help="write output to a file")
    ap.add_argument("--tokens", default=TOKENS_PATH)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    if args.selftest:
        return selftest()
    if not args.spec:
        ap.error("spec is required unless --selftest")

    tokens = load_tokens(args.tokens)
    with open(args.spec, "r", encoding="utf-8") as fh:
        spec = json.load(fh)

    report = analyse(spec, tokens)
    text = json.dumps(report, indent=2) if args.json else render(report)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(text)
        print(f"wrote {args.out}  (deck verdict: {report['deck_verdict']})")
    else:
        print(text)

    return 1 if report["deck_verdict"] == "FAIL" else 0


if __name__ == "__main__":
    sys.exit(main())

````

## FILE: `scripts/compose_engine.py`

````python
#!/usr/bin/env python3
"""
compose_engine.py — the Layout Intelligence and Composition Engine.

Stage 2 of pe-deck-design. It runs AFTER layout_engine.py has resolved the
density band and typography scale, and BEFORE pe_components.js draws anything.

It answers, in this order:

    1. What is on this slide, and what does each piece MEAN?      (semantic roles)
    2. What is the correct STRUCTURAL COMPOSITION of the slide?   (layout selection)
    3. Where exactly does each component go?                      (geometry)
    4. Does that survive real text measurement?                   (validation)
    5. If not, what is the next best composition?                 (fallback chain)

The renderer never makes any of these decisions. It receives resolved geometry
and paints it.

Nothing here overrides the source specification. Character budgets, type scale,
component counts, citation rules and the escalation order all still come from
layout_engine.py and assets/design-tokens.json. This engine adds the axis the
spec implies but never numbers: horizontal composition.

Usage
-----
    python3 scripts/compose_engine.py spec.json               # human report
    python3 scripts/compose_engine.py spec.json --json        # resolved plan
    python3 scripts/compose_engine.py spec.json --json -o plan.json
    python3 scripts/compose_engine.py --selftest

The emitted plan is the contract with pe_components.js:

    {
      "slides": [{
        "id": "s3",
        "band": "balanced",
        "selected_layout": "L13_CHART_COMMENTARY",
        "frame": {"x":0.5,"y":1.84,"w":12.333,"h":5.11},
        "regions": [{"slot":0,"block":0,"type":"chart","role":"primary",
                     "x":0.5,"y":1.84,"w":7.34,"h":5.11,...}],
        "diagnostics": {...},
        "pagination": {...}
      }]
    }
"""

import argparse
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOKENS_PATH = os.path.join(HERE, "..", "assets", "design-tokens.json")

sys.path.insert(0, HERE)
from layout_engine import (  # noqa: E402  — one source of truth for density
    load_tokens,
    slide_chars,
    classify,
    resolve_scale,
    visible_chars,
    format_citation,
)

# --------------------------------------------------------------------------
# text measurement — mirrors pe_components.js estimateLines() EXACTLY.
# If these two ever disagree, the plan and the render disagree, and the
# renderer wins silently. That is the failure mode this mirroring prevents.
# --------------------------------------------------------------------------

ADV_BODY = 0.50
ADV_HEADER = 0.60


def estimate_lines(text, width_in, font_pt, header=False):
    """Wrapped line count. Deliberately pessimistic for Manrope headers."""
    if not text:
        return 0
    em = font_pt / 72.0
    advance = em * (ADV_HEADER if header else ADV_BODY)
    per_line = max(6, int(width_in / advance))
    return sum(max(1, math.ceil(len(p) / per_line))
               for p in str(text).split("\n"))


def text_height_in(text, width_in, font_pt, line_mult, header=False):
    return estimate_lines(text, width_in, font_pt, header) * font_pt * line_mult / 72.0


def chars_per_line(width_in, font_pt, header=False):
    em = font_pt / 72.0
    return int(width_in / (em * (ADV_HEADER if header else ADV_BODY)))


def cite_tail(cite):
    return (" " + format_citation(cite)) if cite else ""


# --------------------------------------------------------------------------
# component model
# --------------------------------------------------------------------------

VISUAL_TYPES = {"chart", "table", "matrix", "timeline"}
CONTAINER_TYPES = {"cards", "rail", "callouts", "kpi"}
TEXT_TYPES = {"body", "bullets", "header", "footnote"}

# `kpi` is not a fourth container. It is the DOC callout component used for a
# metric, and it renders as a callout. The alias exists so layout IDs can speak
# about KPI strips without inventing a component the spec does not define.
TYPE_ALIAS = {"kpi": "callouts", "text": "body", "callout": "callouts",
              "card": "cards", "bullet": "bullets"}


class Component:
    """One content block, measured and classified."""

    def __init__(self, idx, block, tokens, scale):
        self.idx = idx
        self.block = block
        raw = block.get("type", "body")
        self.type = TYPE_ALIAS.get(raw, raw)
        self.declared_type = raw
        self.tokens = tokens
        self.scale = scale
        self.role = block.get("role")
        self.items = block.get("items", []) or []
        self.rows = block.get("rows", []) or []
        self.headers = block.get("headers", []) or []
        self.chars = _block_chars(block)
        self.longest_unit = _longest_text_unit(block)
        self.count = self._count()
        self.cite = block.get("cite", []) or []
        self.text_heavy = (
            self.longest_unit >= tokens["layout"]["density_model"]["text_heavy_threshold_chars"]
        )
        self.growable = self.type in ("cards", "rail", "callouts", "table",
                                      "chart", "matrix", "timeline")
        self.max_h = None   # set from the slide frame before geometry runs

    def _count(self):
        if self.type == "table":
            return len(self.rows)
        if self.type == "chart":
            return len(self.block.get("series", []) or [1])
        return len(self.items) or 1

    # -- geometry ---------------------------------------------------------

    def min_width(self):
        """
        DERIVED, never invented: the width at which this component stops being
        readable. Two floors apply and the larger wins — the token floor for the
        component type, and the width needed to fit min_chars_per_line at the
        resolved point size.
        """
        L = self.tokens["layout"]
        dims = L["min_dims_in"]
        key = self.type
        if key == "cards" and not self.text_heavy:
            key = "cards_short"
        floor = dims.get(key, dims["body"])["w"]

        cpl = L["readability"]["min_chars_per_line"]
        pt = self.scale["body"]
        pad = 0.0
        if self.type == "cards":
            cpl_key, pt = "card_body", self.scale["body"]
            pad = self.tokens["components"]["card"]["pad_x_in"] * 2
        elif self.type == "callouts":
            cpl_key, pt = "callout_label", self.scale["body"]
            pad = self.tokens["components"]["callout"]["pad_x_in"] * 2
        elif self.type == "rail":
            cpl_key = "rail_body"
            pad = self.tokens["components"]["rail"]["pad_x_in"] * 2
        elif self.type == "bullets":
            cpl_key = "bullets"
            pad = 0.20
        elif self.type == "table":
            cpl_key, pt = "table_cell", self.scale["table_body"]
        elif self.type in ("chart", "matrix", "timeline"):
            return floor
        elif self.type == "header":
            return floor
        else:
            cpl_key = "body"

        need = cpl[cpl_key] * (pt / 72.0) * ADV_BODY + pad
        if self.type in ("cards", "callouts", "rail") and self.count > 1:
            # A multi-item container in one region must fit every item side by
            # side unless the layout explicitly wraps it into rows.
            per_row = min(self.count, 3 if self.count > 3 else self.count)
            gapkey = {"cards": "card", "callouts": "callout", "rail": "rail"}[self.type]
            gap = self.tokens["components"][gapkey]["gap_in"]
            need = need * per_row + gap * (per_row - 1)
            floor = floor * per_row + gap * (per_row - 1)
        if self.type == "table" and self.headers:
            need = max(need, len(self.headers) * self.tokens["layout"]["min_dims_in"]["table_col_w"])
        return max(floor, need)

    def measure_width(self, region_w):
        """
        The width the TEXT actually sets to. Prose is capped at the maximum
        readable line length — a 12.33in paragraph at 10pt is ~177 characters a
        line and the eye loses the return. The region stays as allocated; the
        text column inside it does not exceed its measure.
        """
        if self.type not in ("body", "bullets"):
            return region_w
        maxcpl = self.tokens["layout"]["readability"]["max_chars_per_line"]
        cap = maxcpl * (self.scale["body"] / 72.0) * ADV_BODY
        return min(region_w, cap)

    def chars_per_line(self, region_w):
        """
        Effective line length inside this component at a given region width.
        None for components whose readability is not governed by line length
        (charts, matrices, timelines, and tables, which have a column rule).
        """
        t = self.type
        if t in ("chart", "matrix", "timeline", "table", "header", "footnote"):
            return None
        pt = self.scale["body"]
        if t == "cards":
            spec = self.tokens["components"]["card"]
            cols = self.block.get("columns") or min(self.count,
                                                    self.count if self.count <= 3 else 3)
            w = (region_w - spec["gap_in"] * (cols - 1)) / cols - spec["pad_x_in"] * 2
        elif t in ("callouts", "rail"):
            key = "callout" if t == "callouts" else "rail"
            spec = self.tokens["components"][key]
            w = (region_w - spec["gap_in"] * (self.count - 1)) / self.count \
                - spec["pad_x_in"] * 2
        elif t == "bullets":
            w = self.measure_width(region_w) - 0.20
        else:
            w = self.measure_width(region_w)
        return chars_per_line(max(0.2, w), pt)

    def min_height(self):
        L = self.tokens["layout"]["min_dims_in"]
        key = self.type
        if key == "cards" and not self.text_heavy:
            key = "cards_short"
        return L.get(key, L["body"])["h"]

    def natural_height(self, width_in):
        """Measured height at a given width — the feedback half of the loop."""
        t, s = self.type, self.scale
        b = self.block
        if t == "header":
            return text_height_in(b.get("text") or b.get("body", ""), width_in,
                                  s["header"], 1.05, header=True) + 0.04
        if t == "body":
            txt = (b.get("text") or b.get("body", "")) + cite_tail(self.cite)
            return text_height_in(txt, self.measure_width(width_in), s["body"], 1.18) + 0.06
        if t == "bullets":
            w = self.measure_width(width_in) - 0.20
            sp = self.tokens["type"]["paragraph_space_after_pt"] / 72.0
            total = 0.04
            for it in (b.get("items") or b.get("bullets") or []):
                txt = it if isinstance(it, str) else it.get("text", "")
                c = None if isinstance(it, str) else it.get("cite")
                total += text_height_in(txt + cite_tail(c), w, s["body"], 1.18) + sp
            return total
        if t == "cards":
            return self._cards_height(width_in)
        if t == "rail":
            return self._rail_height(width_in)
        if t == "callouts":
            return self._callouts_height(width_in)
        if t == "table":
            return self._table_height(width_in)
        if t in ("chart", "matrix"):
            # A chart is elastic: it takes the height available, bounded by its
            # aspect band and its readable floor. It never DEMANDS w/ideal, or a
            # full-width chart would claim 8in on a 5in band.
            L = self.tokens["layout"]
            ideal = L["aspect"][t]["ideal"]
            floor = L["min_dims_in"][t]["h"]
            ceiling = self.max_h or (width_in / ideal)
            return max(floor, min(width_in / ideal, ceiling))
        if t == "timeline":
            return self._timeline_height(width_in)
        if t == "footnote":
            return text_height_in(b.get("text") or b.get("body", ""), width_in,
                                  s["footnote"], 1.15) + 0.04
        if t == "spacer":
            return b.get("h", 0.20)
        raise ValueError(f"compose_engine: unknown component type {self.declared_type!r}")

    # DOC card rule: cards in a row share a height; widths need not be equal.
    def _cards_height(self, width_in, cols=None):
        spec = self.tokens["components"]["card"]
        n = self.count
        cols = cols or self.block.get("columns") or min(n, n if n <= 3 else 3)
        rows = math.ceil(n / cols)
        gap = spec["gap_in"]
        cw = (width_in - gap * (cols - 1)) / cols
        inner = cw - spec["pad_x_in"] * 2
        pad_y = spec["pad_y_in"] * (1.3 if n <= 3 else 1.0)
        heights = []
        for it in self.items:
            h = text_height_in(it.get("title", ""), inner, self.scale["header"], 1.08, header=True)
            if it.get("title") and it.get("body"):
                h += 0.10
            h += text_height_in(it.get("body", "") + cite_tail(it.get("cite")), inner,
                                self.scale["body"], 1.18)
            heights.append(h + pad_y * 2)
        row_h = [max(heights[r * cols:(r + 1) * cols] or [0]) for r in range(rows)]
        return sum(row_h) + gap * (rows - 1)

    def _rail_height(self, width_in):
        spec = self.tokens["components"]["rail"]
        n = self.count
        gap = spec["gap_in"]
        loads = [max(18, len(it.get("title", "")) + len(it.get("body", ""))) for it in self.items]
        mean = sum(loads) / n
        weights = [0.6 + 0.4 * (l / mean) for l in loads]
        wsum = sum(weights)
        avail = width_in - gap * (n - 1)
        widths = [(w / wsum) * avail for w in weights]
        heights = []
        for it, w in zip(self.items, widths):
            inner = w - spec["pad_x_in"] * 2
            h = text_height_in(it.get("title", ""), inner, self.scale["body"], 1.08, header=True)
            if it.get("title") and it.get("body"):
                h += 0.08
            h += text_height_in(it.get("body", "") + cite_tail(it.get("cite")), inner,
                                self.scale["body"], 1.18)
            heights.append(h + spec["pad_y_in"] * 2)
        return max(heights)

    def _callouts_height(self, width_in):
        spec = self.tokens["components"]["callout"]
        n = self.count
        gap = spec["gap_in"]
        w = (width_in - gap * (n - 1)) / n
        inner = w - spec["pad_x_in"] * 2
        value_pt = min(self.tokens["type"]["max_pt"], self.scale["title"] + 1) if n == 1 \
            else self.scale["title"]
        pad_y = spec["pad_y_in"] * (1.5 if n == 1 else 1.0)
        heights = []
        for it in self.items:
            h = text_height_in(it.get("value", ""), inner, value_pt, 1.04, header=True) + 0.06
            h += text_height_in(it.get("label", "") + cite_tail(it.get("cite")), inner,
                                self.scale["body"], 1.15)
            heights.append(h + pad_y * 2)
        return max(heights)

    def column_widths(self, width_in):
        """Mirrors pe_components.js _autoColumnWidths()."""
        headers, rows = self.headers, self.rows
        if not headers:
            return []
        loads = []
        for c, h in enumerate(headers):
            cells = [len(str(r[c]) if c < len(r) else "") for r in rows]
            avg = sum(cells) / len(cells) if cells else 0
            loads.append(max(len(str(h)) * 0.9, avg))
        total = sum(loads) or 1
        widths = [max(0.85, (l / total) * width_in) for l in loads]
        scale = width_in / sum(widths)
        return [w * scale for w in widths]

    def _table_height(self, width_in):
        t = self.tokens["table"]
        head_pt = self.scale["table_header"]
        body_pt = self.scale["table_body"]
        widths = self.block.get("colW") or self.column_widths(width_in)
        title_h = 0.0
        if self.block.get("title"):
            title_h = text_height_in(self.block["title"], width_in,
                                     self.scale["table_title"], 1.06, header=True) + 0.10
        pad = t["cell_pad_y_pt"][0]

        def cell_h(pt, lines):
            return (lines * pt * 1.2 + pad * 2) / 72.0

        head_h = cell_h(head_pt, 1)
        body_h = 0.0
        for r in self.rows:
            lines = 1
            for c, cell in enumerate(r):
                w = (widths[c] if c < len(widths) else 1.0) - 0.18
                lines = max(lines, estimate_lines(str(cell), w, body_pt))
            body_h += cell_h(body_pt, lines)
        return title_h + head_h + body_h

    def _timeline_height(self, width_in):
        n = self.count
        longest = self.longest_unit
        if self.orientation(width_in) == "horizontal":
            per = width_in / max(1, n)
            label_h = text_height_in("x" * min(longest, 90), per - 0.18, self.scale["body"], 1.15)
            return max(self.tokens["layout"]["min_dims_in"]["timeline"]["h"], 0.62 + label_h)
        total = 0.0
        for it in self.items:
            total += max(0.34, text_height_in(it.get("body", ""), width_in - 1.5,
                                              self.scale["body"], 1.18) + 0.14)
        return total

    def orientation(self, width_in):
        if self.block.get("orientation"):
            return self.block["orientation"]
        if self.count <= 6 and self.longest_unit <= 90 and width_in >= 5.0:
            return "horizontal"
        return "vertical"

    def __repr__(self):
        return f"<{self.type} role={self.role} chars={self.chars} n={self.count}>"


def _block_chars(b):
    """Visible characters of one block. Citations excluded — DOC."""
    total = visible_chars(b.get("title", "")) + visible_chars(b.get("subtitle", ""))
    total += visible_chars(b.get("body", "")) + visible_chars(b.get("text", ""))
    for it in b.get("items", []) or []:
        if isinstance(it, str):
            total += visible_chars(it)
        else:
            for k in ("title", "label", "value", "body", "text", "sublabel"):
                total += visible_chars(it.get(k, ""))
    for bl in b.get("bullets", []) or []:
        total += visible_chars(bl if isinstance(bl, str) else bl.get("text", ""))
    for h in b.get("headers", []) or []:
        total += visible_chars(h)
    for r in b.get("rows", []) or []:
        for c in r:
            total += visible_chars(c)
    for lb in b.get("labels", []) or []:
        total += visible_chars(lb)
    return total


def _longest_text_unit(b):
    """Longest single readable unit — the thing that actually needs line width."""
    units = [visible_chars(b.get("body", "")), visible_chars(b.get("text", ""))]
    for it in b.get("items", []) or []:
        if isinstance(it, str):
            units.append(visible_chars(it))
        else:
            units.append(visible_chars(it.get("body", "")) + visible_chars(it.get("label", "")))
    for bl in b.get("bullets", []) or []:
        units.append(visible_chars(bl if isinstance(bl, str) else bl.get("text", "")))
    for r in b.get("rows", []) or []:
        for c in r:
            units.append(visible_chars(c))
    return max(units) if units else 0


# --------------------------------------------------------------------------
# semantic roles
# --------------------------------------------------------------------------

ROLE_BY_TYPE = {
    "chart": "primary", "matrix": "primary", "table": "primary", "timeline": "primary",
    "callouts": "summary", "cards": "secondary", "rail": "secondary",
    "body": "context", "bullets": "supporting", "header": "annotation",
    "footnote": "metadata", "spacer": "metadata",
}


def assign_roles(comps, tokens):
    """
    Every component gets a semantic role, and the slide gets exactly one
    primary anchor. Explicit `role` in the spec always wins — that is source
    fidelity, and the engine must not overrule a stated intent.
    """
    weights = tokens["layout"]["roles"]["weight"]
    for c in comps:
        if not c.role:
            c.role = ROLE_BY_TYPE.get(c.type, "supporting")

    explicit = [c for c in comps if c.block.get("role") == "primary"]
    primaries = [c for c in comps if c.role == "primary"]

    if explicit:
        anchor = explicit[0]
    elif primaries:
        # Largest visual wins the anchor; ties break on spec order.
        anchor = max(primaries, key=lambda c: (c.chars + c.count * 20))
    elif comps:
        anchor = max(comps, key=lambda c: (weights.get(c.role, 0.3), c.chars))
    else:
        return comps

    for c in comps:
        if c is anchor:
            c.role = "primary"
        elif c.role == "primary":
            c.role = "comparison" if c.type == anchor.type else "evidence"
    return comps


# --------------------------------------------------------------------------
# multidimensional density
# --------------------------------------------------------------------------

def complexity(comps, tokens, sources=0):
    """
    Complexity points — the second density axis. Characters measure vertical
    occupancy; this measures how many things the eye must separately parse.
    Both are evaluated; neither substitutes for the other.
    """
    w = tokens["layout"]["density_model"]["weights"]
    pts = 0.0
    detail = []
    pts += w["per_component"] * len(comps)
    detail.append(f"{len(comps)} components")
    heavy = [c for c in comps if c.text_heavy]
    pts += w["per_text_heavy_component"] * len(heavy)
    if heavy:
        detail.append(f"{len(heavy)} text-heavy")
    for c in comps:
        if c.type == "table":
            pts += w["per_table_row"] * len(c.rows) + w["per_table_column"] * len(c.headers)
            detail.append(f"table {len(c.rows)}x{len(c.headers)}")
        elif c.type == "chart":
            series = len(c.block.get("series", []) or [1])
            cats = len(c.block.get("labels", []) or [])
            pts += w["per_chart_series"] * series + w["per_chart_category"] * cats
            detail.append(f"chart {series} series")
        elif c.type in CONTAINER_TYPES:
            pts += w["per_region_column"] * min(c.count, 4)
    pts += w["per_distinct_source"] * sources
    band = "overload"
    for b in tokens["layout"]["density_model"]["bands"]:
        if b["max"] is None or pts <= b["max"]:
            band = b["name"]
            break
    return round(pts, 1), band, detail


# --------------------------------------------------------------------------
# compatibility matrix
# --------------------------------------------------------------------------

def compatibility(a, b, tokens):
    """
    Can these two components share a horizontal band? Returns
    (score 0-10, reason). This is about reading scale and visual competition,
    not about whether the geometry happens to fit.
    """
    ta, tb = a.type, b.type
    pair = {ta, tb}

    if ta == "table" and tb == "table":
        return 1, "two tables side by side — paginate or stack, never split the band"
    if pair == {"table", "chart"}:
        if a.chars + b.chars > 700:
            return 3, "detailed table beside a chart competes for the same reading attention"
        return 6, "table and chart can share a band only when both are compact"
    if ta == "chart" and tb == "chart":
        sa = len(a.block.get("series", []) or [1])
        sb = len(b.block.get("series", []) or [1])
        if sa > 2 or sb > 2:
            return 3, "two multi-series charts side by side — stack them"
        return 8, "two simple charts compare well side by side"
    if pair == {"matrix", "table"}:
        return 2, "a matrix and a detailed table are two separate exhibits"
    if "matrix" in pair and ({"body", "bullets", "callouts"} & pair):
        return 9, "matrix with short annotation is the intended pairing"
    if "chart" in pair and ({"body", "bullets"} & pair):
        text = a if a.type in TEXT_TYPES else b
        if text.chars > 420:
            return 3, "commentary too long for a side panel — stack it"
        return 10, "chart plus concise commentary is the canonical exhibit"
    if "table" in pair and ({"callouts", "body"} & pair):
        text = a if a.type in ("callouts", "body") else b
        if text.chars > 260:
            return 3, "takeaway is too long to ride beside a table"
        return 9, "table plus concise takeaway"
    if ta in TEXT_TYPES and tb in TEXT_TYPES:
        if a.chars > 240 and b.chars > 240:
            return 2, "two long prose blocks side by side — stack them"
        return 6, "short text blocks can share a band"
    if ta in CONTAINER_TYPES and tb in CONTAINER_TYPES:
        if a.text_heavy and b.text_heavy:
            return 6, "two detailed container sets — allowed, but a grid reads better"
        return 8, "compatible containers"
    if "timeline" in pair:
        other = a if a.type != "timeline" else b
        if other.type in ("body", "bullets", "callouts"):
            return 8, "timeline with a short reading"
        return 3, "a timeline wants the full band"
    return 7, "no specific incompatibility"


# --------------------------------------------------------------------------
# geometry
# --------------------------------------------------------------------------

def slide_frame(slide, tokens, scale):
    """
    The shared frame every region derives from. Mirrors the renderer's own
    title advance exactly, so the plan and the .pptx agree on where content
    starts. No component may invent its own x/y outside this frame.
    """
    g = tokens["grid"]
    x = g["margin_left_in"]
    w = g["content_width_in"]
    y = g["content_top_in"]
    title = slide.get("title", "")
    if title:
        th = text_height_in(title, w, scale["title"], 1.08, header=True) + 0.08
        y += th + 0.24
    bottom = g["content_bottom_in"]
    return {"x": round(x, 3), "y": round(y, 3), "w": round(w, 3),
            "h": round(bottom - y, 3), "bottom": round(bottom, 3)}


def fitted_box(region, band):
    """
    The largest box inside a region that respects an aspect band. A chart or
    matrix is letterboxed inside its region rather than stretched to fill it —
    DOC: maintain aspect ratio, and a legend must never out-size its plot.
    """
    w, h = region["w"], region["h"]
    ar = w / max(0.01, h)
    target = min(max(ar, band["min"]), band["max"])
    if ar > target:                     # region too wide: pin height, trim width
        dw, dh = h * target, h
    else:                               # region too tall: pin width, trim height
        dw, dh = w, w / target
    # Centred horizontally: a letterboxed exhibit pinned left reads as a
    # mistake, centred it reads as a decision.
    return {"x": round(region["x"] + (w - dw) / 2, 3), "y": round(region["y"], 3),
            "w": round(dw, 3), "h": round(dh, 3), "aspect": round(target, 3)}


def _row(frame, props, gap):
    """Split a frame horizontally by proportions, absorbing the gutters."""
    n = len(props)
    avail = frame["w"] - gap * (n - 1)
    out, x = [], frame["x"]
    for p in props:
        w = avail * p
        out.append({"x": round(x, 3), "y": frame["y"], "w": round(w, 3), "h": frame["h"]})
        x += w + gap
    return out


def _bands(frame, splits, gap):
    """Split a frame vertically by proportions."""
    n = len(splits)
    avail = frame["h"] - gap * (n - 1)
    out, y = [], frame["y"]
    for p in splits:
        h = avail * p
        out.append({"x": frame["x"], "y": round(y, 3), "w": frame["w"], "h": round(h, 3)})
        y += h + gap
    return out


def pack_rows(regions, comps, frame, tokens):
    """
    Second pass over resolved geometry: pack row bands from the top at the
    height their content actually measures, then hand surplus back to the
    growable bands (capped, per component type) exactly as the renderer's
    two-phase distributor does.

    Without this, a proportional band split leaves a hole between a short table
    and the insight strip pinned beneath it — the horizontal version of the
    dead-bottom-half defect the vertical engine was built to kill. Any surplus
    that remains after the caps stays as whitespace at the foot of the slide and
    is reported by the balance audit, never absorbed by silently inflating a
    component past what its content justifies.
    """
    if len(regions) < 2:
        return regions
    by_block = {c.idx: c for c in comps}
    gy = tokens["layout"]["frame"]["region_gap_y_in"]
    bands = {}
    for r in regions:
        bands.setdefault(round(r["y"], 2), []).append(r)
    keys = sorted(bands)
    if len(keys) < 2:
        return regions

    need = []
    for k in keys:
        band = bands[k]
        need.append(max(max(r["natural_h"], by_block[r["block"]].min_height())
                        for r in band))
    avail = frame["h"] - gy * (len(keys) - 1)
    total = sum(need)

    if total > avail:
        # Elastic exhibits (chart, matrix) give up height before anything else,
        # down to their readable floor. Text is never compressed to make room.
        elastic = [i for i, k in enumerate(keys)
                   if all(by_block[r["block"]].type in ("chart", "matrix") for r in bands[k])]
        excess = total - avail
        for i in elastic:
            floor = max(tokens["layout"]["min_dims_in"][by_block[r["block"]].type]["h"]
                        for r in bands[keys[i]])
            give = min(excess, max(0.0, need[i] - floor))
            need[i] -= give
            excess -= give
            if excess <= 0:
                break
        total = sum(need)
    elif total < avail:
        surplus = avail - total
        growable = [i for i, k in enumerate(keys)
                    if any(by_block[r["block"]].growable for r in bands[k])]
        base = sum(need[i] for i in growable)
        if base > 0:
            for i in growable:
                types = {by_block[r["block"]].type for r in bands[keys[i]]}
                cap = min(GROW_CAP.get(t, 0.50) for t in types) if types else 0.30
                if types & {"chart", "matrix"}:
                    cap = 4.0           # an exhibit may take the room it is given
                take = min(surplus * (need[i] / base), need[i] * cap)
                need[i] += take
                surplus -= take

    y = frame["y"]
    for k, h in zip(keys, need):
        for r in bands[k]:
            r["y"] = round(y, 3)
            r["h"] = round(h, 3)
            c = by_block[r["block"]]
            if c.type in ("chart", "matrix"):
                r["draw"] = fitted_box(r, tokens["layout"]["aspect"][c.type])
                r["natural_h"] = r["draw"]["h"]
            else:
                r["natural_h"] = round(c.natural_height(
                    (r.get("draw") or r)["w"]), 3)
        y += h + gy
    return regions


def resolve_geometry(layout_id, comps, frame, tokens, scale):
    """
    Produce resolved regions for one layout. Returns [] when the layout cannot
    accept this component set at all (a shape mismatch, not a fit failure).
    """
    L = tokens["layout"]
    cat = L["catalog"][layout_id]
    gx = L["frame"]["region_gap_x_in"]
    gy = L["frame"]["region_gap_y_in"]
    n = len(comps)
    lo, hi = cat["components"]
    if not (lo <= n <= hi):
        return []

    def stamp(rects, order=None):
        # (regions are packed vertically by pack_rows() before they are returned)
        order = order or list(range(n))
        regions = []
        for slot, (r, ci) in enumerate(zip(rects, order)):
            c = comps[ci]
            reg = dict(r)
            reg.update({"slot": slot, "block": c.idx, "type": c.type,
                        "declared_type": c.declared_type, "role": c.role})
            if c.type in ("chart", "matrix"):
                reg["draw"] = fitted_box(reg, L["aspect"][c.type])
                reg["natural_h"] = reg["draw"]["h"]
            else:
                reg["natural_h"] = round(c.natural_height(reg["w"]), 3)
            regions.append(reg)
        return regions

    if layout_id == "L01_SINGLE":
        return stamp([dict(frame)])

    if layout_id == "L10_VERTICAL_STACK":
        # Vertical flow with the existing two-phase distribution. Heights are
        # natural first; surplus is handed back by the renderer, exactly as the
        # existing compose() already does.
        gaps = max(0, n - 1)
        # Fixed content is measured first; elastic components (chart, matrix)
        # then absorb what is left, floored at their minimum. Geometry is
        # allocated from a shared budget — components never each claim the frame.
        elastic = [i for i, c in enumerate(comps) if c.type in ("chart", "matrix")]
        nat = [None] * n
        for i, c in enumerate(comps):
            if i not in elastic:
                nat[i] = c.natural_height(frame["w"])
        if elastic:
            spare = frame["h"] - sum(h for h in nat if h) - gy * gaps
            each = spare / len(elastic)
            for i in elastic:
                floor = L["min_dims_in"][comps[i].type]["h"]
                ideal = frame["w"] / L["aspect"][comps[i].type]["ideal"]
                nat[i] = max(floor, min(ideal, each)) if each > 0 else floor
        rects, y = [], frame["y"]
        for c, h in zip(comps, nat):
            h = max(h, c.min_height())
            rects.append({"x": frame["x"], "y": round(y, 3), "w": frame["w"], "h": round(h, 3)})
            y += h + gy
        return stamp(rects)

    if layout_id in ("L02_SPLIT_EQUAL", "L03_SPLIT_LEFT_DOMINANT",
                     "L04_SPLIT_RIGHT_DOMINANT", "L11_MAIN_SIDEBAR",
                     "L13_CHART_COMMENTARY", "L17_MATRIX"):
        props = cat["proportions"][0]
        if len(props) != n:
            return []
        order = list(range(n))
        if layout_id in ("L03_SPLIT_LEFT_DOMINANT", "L11_MAIN_SIDEBAR",
                         "L13_CHART_COMMENTARY", "L17_MATRIX"):
            order = sorted(order, key=lambda i: 0 if comps[i].role == "primary" else 1)
        elif layout_id == "L04_SPLIT_RIGHT_DOMINANT":
            order = sorted(order, key=lambda i: 1 if comps[i].role == "primary" else 0)
        return stamp(_row(frame, props, gx), order)

    if layout_id in ("L05_THREE_COLUMN", "L06_FOUR_COLUMN"):
        props = cat["proportions"][0]
        if len(props) != n:
            return []
        return stamp(_row(frame, props, gx))

    if layout_id == "L18_COMPARISON":
        props = next((p for p in cat["proportions"] if len(p) == n), None)
        if not props:
            return []
        return stamp(_row(frame, props, gx))

    if layout_id in ("L07_GRID_2X2", "L08_GRID_2X3", "L09_GRID_3X2"):
        rows, cols = cat["grid"]["rows"], cat["grid"]["cols"]
        if n != rows * cols:
            return []
        rects = []
        band_h = (frame["h"] - gy * (rows - 1)) / rows
        for r in range(rows):
            rowframe = {"x": frame["x"], "y": frame["y"] + r * (band_h + gy),
                        "w": frame["w"], "h": band_h}
            rects.extend(_row(rowframe, [1.0 / cols] * cols, gx))
        return stamp(rects)

    if layout_id == "L12_MAIN_TWO_SUPPORT":
        if n != 3:
            return []
        order = sorted(range(n), key=lambda i: 0 if comps[i].role == "primary" else 1)
        left, right = _row(frame, cat["proportions"][0], gx)
        sub = _bands(right, [0.5, 0.5], gy)
        return stamp([left, sub[0], sub[1]], order)

    if layout_id in ("L14_TABLE_INSIGHT", "L15_KPI_CHART", "L19_HIERARCHICAL"):
        split = cat["band_split"]
        if layout_id == "L14_TABLE_INSIGHT":
            order = sorted(range(n), key=lambda i: 0 if comps[i].type == "table" else 1)
        elif layout_id == "L15_KPI_CHART":
            order = sorted(range(n), key=lambda i: 0 if comps[i].type == "callouts" else 1)
        else:
            order = list(range(n))
        if n == 2:
            rects = _bands(frame, split, gy)
            return stamp(rects, order)
        if layout_id == "L19_HIERARCHICAL" and n >= 3:
            top, bottom = _bands(frame, split, gy)
            rest = n - 1
            rects = [top] + _row(bottom, [1.0 / rest] * rest, gx)
            return stamp(rects, order)
        return []

    if layout_id == "L16_TIMELINE":
        if n == 1:
            return stamp([dict(frame)])
        if n == 2:
            tl = next((i for i, c in enumerate(comps) if c.type == "timeline"), None)
            if tl is None:
                return []
            other = 1 - tl
            th = comps[tl].natural_height(frame["w"])
            bands = _bands(frame, [th / frame["h"], 1 - th / frame["h"]], gy)
            return stamp(bands, [tl, other])
        return []

    if layout_id == "L20_PAGINATED":
        return stamp([dict(frame)] * n if n == 1 else [dict(frame)])

    return []


# --------------------------------------------------------------------------
# validation — hard constraints. A failing layout is REJECTED, not patched.
# --------------------------------------------------------------------------

def validate(layout_id, regions, comps, frame, tokens, scale):
    """Returns a list of violation dicts. Empty list means the layout is legal."""
    L = tokens["layout"]
    cat = L["catalog"][layout_id]
    v = []
    by_block = {c.idx: c for c in comps}

    for r in regions:
        c = by_block[r["block"]]
        if r["w"] < c.min_width() - 1e-6:
            v.append({"code": "minimum_width_violation",
                      "detail": f"{c.type} needs {c.min_width():.2f}in, region is {r['w']:.2f}in"})
        if r["h"] < c.min_height() - 1e-6:
            v.append({"code": "minimum_height_violation",
                      "detail": f"{c.type} needs {c.min_height():.2f}in, region is {r['h']:.2f}in"})
        # Measured overflow: real text at the real width, not a character guess.
        if r["natural_h"] > r["h"] + 0.02 and not c.growable:
            v.append({"code": "measured_overflow",
                      "detail": f"{c.type} measures {r['natural_h']:.2f}in in a "
                                f"{r['h']:.2f}in region"})
        if c.growable and r["natural_h"] > r["h"] + 0.02 and c.type in ("table", "cards", "rail"):
            v.append({"code": "measured_overflow",
                      "detail": f"{c.type} measures {r['natural_h']:.2f}in in a "
                                f"{r['h']:.2f}in region — content is clipped, not shrunk"})
        if c.type in ("chart", "matrix"):
            box = r.get("draw") or fitted_box(r, L["aspect"][c.type])
            floor = L["min_dims_in"][c.type]
            if box["w"] < floor["w"] - 1e-6 or box["h"] < floor["h"] - 1e-6:
                v.append({"code": "aspect_violation",
                          "detail": f"{c.type} letterboxed to "
                                    f"{box['w']:.2f}x{box['h']:.2f}in inside a "
                                    f"{r['w']:.2f}x{r['h']:.2f}in region — below the "
                                    f"{floor['w']}x{floor['h']}in floor at a legal aspect"})
        if c.type == "table":
            widths = c.column_widths(r["w"])
            if widths and min(widths) < L["min_dims_in"]["table_col_w"] - 1e-6:
                v.append({"code": "table_column_unreadable",
                          "detail": f"narrowest column {min(widths):.2f}in < "
                                    f"{L['min_dims_in']['table_col_w']}in"})
        # Child-in-parent bounds. Every region must stay inside the frame.
        if layout_id != "L10_VERTICAL_STACK" and (r["x"] < frame["x"] - 1e-6 or
                r["x"] + r["w"] > frame["x"] + frame["w"] + 1e-6 or
                r["y"] < frame["y"] - 1e-6 or
                r["y"] + r["h"] > frame["bottom"] + 1e-6):
            v.append({"code": "child_exceeds_parent",
                      "detail": f"region {r['slot']} ({c.type}) escapes the content frame"})

    # Compatibility is a hard constraint for components sharing a band, not a
    # preference. "Generally incompatible side-by-side" means rejected.
    for i, r in enumerate(regions):
        for s2 in regions[i + 1:]:
            if abs(r["y"] - s2["y"]) < 0.05 and abs(r["x"] - s2["x"]) > 0.05:
                cs, why = compatibility(by_block[r["block"]], by_block[s2["block"]], tokens)
                if cs < 5:
                    v.append({"code": "component_incompatible", "detail": why})

    # Layout-declared rules that need component knowledge.
    if layout_id == "L11_MAIN_SIDEBAR":
        side = regions[-1]
        c = by_block[side["block"]]
        if c.type in ("table", "chart", "matrix"):
            v.append({"code": "sidebar_component_banned",
                      "detail": f"a {c.type} cannot live in a sidebar"})
        if c.chars > 320:
            v.append({"code": "sidebar_overloaded",
                      "detail": f"{c.chars} chars in a sidebar (max 320)"})
    if layout_id == "L05_THREE_COLUMN":
        worst = max(c.chars for c in comps)
        if worst > 220:
            v.append({"code": "column_text_too_long",
                      "detail": f"longest column carries {worst} chars (max 220)"})
    if layout_id == "L06_FOUR_COLUMN":
        worst = max(c.chars for c in comps)
        if worst > 120:
            v.append({"code": "column_text_too_long",
                      "detail": f"longest item carries {worst} chars (max 120)"})
    if layout_id == "L08_GRID_2X3":
        worst = max(c.chars for c in comps)
        if worst > 110:
            v.append({"code": "cell_text_too_long",
                      "detail": f"longest card carries {worst} chars (max 110) — use 3x2"})
    if layout_id == "L13_CHART_COMMENTARY":
        text = [c for c in comps if c.type in TEXT_TYPES or c.type == "callouts"]
        if text and text[0].chars > 420:
            v.append({"code": "commentary_too_long",
                      "detail": f"{text[0].chars} chars of commentary (max 420) — stack instead"})
        if not any(c.type == "chart" for c in comps):
            v.append({"code": "shape_mismatch", "detail": "no chart on the slide"})
    if layout_id == "L14_TABLE_INSIGHT":
        ins = [c for c in comps if c.type != "table"]
        if ins and ins[0].chars > 260:
            v.append({"code": "insight_too_long",
                      "detail": f"{ins[0].chars} chars (max 260) — this is a body block, "
                                f"not an insight strip"})
        if not any(c.type == "table" for c in comps):
            v.append({"code": "shape_mismatch", "detail": "no table on the slide"})
    if layout_id == "L15_KPI_CHART":
        kpi = [c for c in comps if c.type == "callouts"]
        if not kpi or kpi[0].count > 4:
            v.append({"code": "kpi_count_violation",
                      "detail": "L15 needs a callout strip of 4 or fewer"})
        if not any(c.type in ("chart", "table") for c in comps):
            v.append({"code": "shape_mismatch", "detail": "no chart beneath the KPI strip"})
    if layout_id == "L17_MATRIX":
        if not any(c.type == "matrix" for c in comps):
            v.append({"code": "shape_mismatch", "detail": "no matrix on the slide"})
    if layout_id == "L16_TIMELINE":
        if not any(c.type == "timeline" for c in comps):
            v.append({"code": "shape_mismatch", "detail": "no timeline on the slide"})
    if layout_id == "L19_HIERARCHICAL":
        if comps[0].chars > 260:
            v.append({"code": "thesis_too_long",
                      "detail": f"thesis block is {comps[0].chars} chars (max 260)"})

    # Total vertical fit for stacks.
    if layout_id == "L10_VERTICAL_STACK":
        gy = L["frame"]["region_gap_min_in"]
        need = sum(r["natural_h"] for r in regions) + gy * (len(regions) - 1)
        if need > frame["h"] + 0.02:
            v.append({"code": "measured_overflow",
                      "detail": f"stack needs {need:.2f}in, frame is {frame['h']:.2f}in "
                                f"even at minimum gaps"})

    # Hierarchy: the primary must actually dominate.
    prim = [r for r in regions if r["role"] == "primary"]
    others = [r for r in regions if r["role"] != "primary"]
    if prim and others and len(regions) > 1:
        pa = prim[0]["w"] * prim[0]["h"]
        biggest = max(r["w"] * r["h"] for r in others)
        ratio = pa / max(0.01, biggest)
        floor = L["roles"]["dominance_min_ratio_vs_secondary"]
        peers = {"comparison", "secondary"}
        if ratio < 1.0 and regions[0]["role"] == "primary" and \
                not any(r["role"] in peers for r in others):
            v.append({"code": "primary_dominance_lost",
                      "detail": f"primary/secondary area ratio {ratio:.2f} < {floor}"})

    # Gap consistency — one gutter value per axis, no drift.
    rows = {}
    for r in regions:
        rows.setdefault(round(r["y"], 2), []).append(r)
    gutters = []
    for _, band in rows.items():
        band = sorted(band, key=lambda r: r["x"])
        for a, b2 in zip(band, band[1:]):
            gutters.append(round(b2["x"] - (a["x"] + a["w"]), 2))
    if gutters and (max(gutters) - min(gutters)) > 0.03:
        v.append({"code": "inconsistent_gutters",
                  "detail": f"adjacent gutters vary {min(gutters):.2f}-{max(gutters):.2f}in"})
    return v


# --------------------------------------------------------------------------
# scoring
# --------------------------------------------------------------------------

SEMANTIC_PREF = {
    ("chart", "body"): {"L13_CHART_COMMENTARY": 10, "L11_MAIN_SIDEBAR": 8,
                        "L03_SPLIT_LEFT_DOMINANT": 7, "L10_VERTICAL_STACK": 5},
    ("chart", "bullets"): {"L13_CHART_COMMENTARY": 10, "L11_MAIN_SIDEBAR": 8,
                           "L10_VERTICAL_STACK": 5},
    ("chart", "callouts"): {"L15_KPI_CHART": 10, "L13_CHART_COMMENTARY": 8,
                            "L03_SPLIT_LEFT_DOMINANT": 6},
    ("table", "callouts"): {"L14_TABLE_INSIGHT": 10, "L10_VERTICAL_STACK": 7},
    ("table", "body"): {"L14_TABLE_INSIGHT": 10, "L10_VERTICAL_STACK": 7},
    ("matrix", "body"): {"L17_MATRIX": 10, "L03_SPLIT_LEFT_DOMINANT": 7},
    ("matrix", "bullets"): {"L17_MATRIX": 10, "L03_SPLIT_LEFT_DOMINANT": 7},
    ("chart", "chart"): {"L02_SPLIT_EQUAL": 10, "L10_VERTICAL_STACK": 6},
    ("table", "table"): {"L10_VERTICAL_STACK": 6, "L20_PAGINATED": 9},
    # A timeline owns its band: the reading goes under it, not beside it, or the
    # chronology loses the width that makes it read as a sequence.
    ("body", "timeline"): {"L16_TIMELINE": 10, "L10_VERTICAL_STACK": 7,
                           "L03_SPLIT_LEFT_DOMINANT": 5},
    ("bullets", "timeline"): {"L16_TIMELINE": 10, "L10_VERTICAL_STACK": 7,
                              "L03_SPLIT_LEFT_DOMINANT": 5},
    ("callouts", "timeline"): {"L16_TIMELINE": 10, "L10_VERTICAL_STACK": 7},
    ("cards", "timeline"): {"L16_TIMELINE": 9, "L10_VERTICAL_STACK": 7},
}


SOLO_LAYOUT = {"timeline": "L16_TIMELINE", "matrix": "L17_MATRIX"}


def semantic_fit(layout_id, comps):
    """
    Content-to-layout selection, stated explicitly so the engine never falls
    back to "whatever fits". Component COUNT alone never decides — the same
    count resolves differently depending on how much text each item carries.
    """
    n = len(comps)

    if n == 1:
        c = comps[0]
        special = SOLO_LAYOUT.get(c.type)
        if special:
            return 10.0 if layout_id == special else (7.0 if layout_id == "L01_SINGLE" else 4.0)
        return 10.0 if layout_id == "L01_SINGLE" else 5.0

    if n == 2:
        key = tuple(sorted(c.type for c in comps))
        pref = SEMANTIC_PREF.get(key) or SEMANTIC_PREF.get((key[1], key[0]))
        if pref:
            return float(pref.get(layout_id, 4))
        # unlisted pair: peers split, unequal importance goes asymmetric
        roles = {c.role for c in comps}
        if len(roles) == 1 or comps[0].type == comps[1].type:
            return {"L02_SPLIT_EQUAL": 9, "L03_SPLIT_LEFT_DOMINANT": 6,
                    "L10_VERTICAL_STACK": 5}.get(layout_id, 5.0)
        return {"L03_SPLIT_LEFT_DOMINANT": 9, "L11_MAIN_SIDEBAR": 8,
                "L02_SPLIT_EQUAL": 5, "L10_VERTICAL_STACK": 6}.get(layout_id, 5.0)

    detailed = sum(1 for c in comps if c.text_heavy or c.chars > 150)
    peers = len({c.type for c in comps}) == 1

    if n == 3:
        if detailed == 0 and peers:
            return {"L05_THREE_COLUMN": 10, "L12_MAIN_TWO_SUPPORT": 6,
                    "L19_HIERARCHICAL": 5, "L10_VERTICAL_STACK": 3}.get(layout_id, 5.0)
        if detailed >= 2:
            return {"L10_VERTICAL_STACK": 9, "L19_HIERARCHICAL": 7,
                    "L05_THREE_COLUMN": 2}.get(layout_id, 5.0)
        return {"L12_MAIN_TWO_SUPPORT": 9, "L19_HIERARCHICAL": 8,
                "L05_THREE_COLUMN": 6, "L10_VERTICAL_STACK": 6}.get(layout_id, 5.0)

    if n == 4:
        if detailed == 0 and peers:
            return {"L06_FOUR_COLUMN": 10, "L07_GRID_2X2": 7,
                    "L10_VERTICAL_STACK": 3}.get(layout_id, 5.0)
        return {"L07_GRID_2X2": 10, "L06_FOUR_COLUMN": 3,
                "L19_HIERARCHICAL": 6, "L10_VERTICAL_STACK": 5}.get(layout_id, 5.0)

    if n == 6:
        if detailed == 0:
            return {"L08_GRID_2X3": 10, "L09_GRID_3X2": 6,
                    "L10_VERTICAL_STACK": 3}.get(layout_id, 5.0)
        return {"L09_GRID_3X2": 10, "L08_GRID_2X3": 4,
                "L10_VERTICAL_STACK": 5}.get(layout_id, 5.0)

    return {"L10_VERTICAL_STACK": 8, "L19_HIERARCHICAL": 7}.get(layout_id, 5.0)


def score(layout_id, regions, comps, frame, tokens, requested=None, band="balanced"):
    """
    Score a VALID layout. Higher wins. Scores are comparable only within one
    slide — they rank candidates, they do not measure absolute quality.
    """
    L = tokens["layout"]
    W = L["scoring"]["weights"]
    P = L["scoring"]["penalties"]
    by_block = {c.idx: c for c in comps}
    parts = {}

    # readability: a PLATEAU, not a ramp. A region earns full marks once it is
    # comfortably above the minimum readable width and stays below the maximum
    # readable line length. Extra width past that buys nothing and eventually
    # costs — a 12.3in body line at 9pt is ~197 characters, and the eye loses
    # the line return. This is what stops every layout collapsing to full width.
    maxcpl = L["readability"]["max_chars_per_line"]
    scores = []
    for r in regions:
        c = by_block[r["block"]]
        mw = c.min_width()
        if r["w"] < mw:
            scores.append(0.0)
            continue
        ratio = r["w"] / mw
        val = 6.0 + 4.0 * min(1.0, (ratio - 1.0) / 0.5)
        cpl = c.chars_per_line(r["w"])
        if cpl and cpl > maxcpl:
            val -= min(6.0, (cpl - maxcpl) / 18.0)
        scores.append(max(0.0, min(10.0, val)))
    parts["readability"] = sum(scores) / len(scores) if scores else 5.0

    # hierarchy_fit: does the primary hold its area share
    total_area = sum(r["w"] * r["h"] for r in regions) or 1
    prim = [r for r in regions if r["role"] == "primary"]
    share = (prim[0]["w"] * prim[0]["h"] / total_area) if prim else 0
    want = L["roles"]["dominance_min_area_share"]
    parts["hierarchy_fit"] = 10.0 if len(regions) == 1 else \
        max(0.0, min(10.0, 10 * min(1.0, share / want)))

    parts["semantic_fit"] = semantic_fit(layout_id, comps)

    # compatibility: worst pair sharing a horizontal band
    pair_scores = []
    for i, r in enumerate(regions):
        for s in regions[i + 1:]:
            same_band = abs(r["y"] - s["y"]) < 0.05
            if same_band:
                cs, _ = compatibility(by_block[r["block"]], by_block[s["block"]], tokens)
                pair_scores.append(cs)
    parts["compatibility"] = float(min(pair_scores)) if pair_scores else 9.0

    # balance: fill ratio inside the target band. Growable components are
    # credited with the growth the renderer will actually hand them (GROW_CAP),
    # so a table is not scored as if it stays at natural height.
    grow = {"cards": 0.30, "rail": 0.30, "callouts": 0.55, "table": 0.35}
    used = 0.0
    for r in regions:
        c = by_block[r["block"]]
        eff = max(r["natural_h"], c.min_height())
        if c.growable:
            eff = min(r["h"], eff * (1 + grow.get(c.type, 0.50)))
        used += min(r["h"], eff) * r["w"]
    fill = used / max(0.01, frame["w"] * frame["h"])
    lo, hi = L["balance"]["target_fill_min"], L["balance"]["target_fill_max"]
    if fill < lo:
        parts["balance"] = max(0.0, 10 * (fill / lo))
    elif fill > hi:
        parts["balance"] = max(0.0, 10 - (fill - hi) * 40)
    else:
        parts["balance"] = 10.0

    # alignment: fewer distinct edges is a cleaner composition
    edges = len({round(r["x"], 2) for r in regions}) + len({round(r["y"], 2) for r in regions})
    parts["alignment"] = max(0.0, 10.0 - max(0, edges - 3) * 1.2)

    # source_fidelity: honour an explicitly requested layout
    parts["source_fidelity"] = 10.0 if requested == layout_id else (
        3.0 if requested else 6.0)

    total = sum(parts[k] * W[k] for k in W)

    pen = {}
    over = sum(max(0.0, r["natural_h"] - r["h"]) for r in regions)
    pen["overflow"] = P["overflow"] * min(1.0, over / 2.0)
    _cx, cband, _ = complexity(comps, tokens)   # NB: not `band` — that is the
    pen["density"] = P["density"] * {"light": 0, "workable": 1.5,   # density band
                                     "heavy": 4.0, "overload": 9.0}[cband]
    tiny = sum(1 for r in regions
               if r["w"] < by_block[r["block"]].min_width() * 1.12)
    pen["tiny_component"] = P["tiny_component"] * (tiny / max(1, len(regions)))
    # Visual competition means two things fighting to be THE exhibit — a second
    # chart, table or matrix. A row of peer KPIs is a set, not a set of rivals.
    anchors = sum(1 for r in regions if by_block[r["block"]].type in VISUAL_TYPES)
    heavy_peers = sum(1 for r in regions
                      if r["role"] in ("primary", "comparison")
                      and by_block[r["block"]].text_heavy)
    pen["competition"] = P["competition"] * (max(0, anchors - 1) * 0.5
                                             + max(0, heavy_peers - 1) * 0.25)
    pen["whitespace"] = P["whitespace"] * (10 * max(0.0, lo - fill) / lo)
    if band == "sparse":
        # A sparse slide is a DENSITY problem with a DOC answer (scale up, or
        # pull the next section forward). It must not drive layout choice, or
        # every thin slide collapses into a full-width stack.
        parts["balance"] = 7.0
        pen["whitespace"] = 0.0
        total = sum(parts[k] * W[k] for k in W)
    pen["nesting"] = P["nesting"] * (1 if layout_id == "L12_MAIN_TWO_SUPPORT" else 0) * 0.2

    total -= sum(pen.values())
    return round(total, 2), {k: round(v, 2) for k, v in parts.items()}, \
        {k: round(v, 2) for k, v in pen.items()}, round(fill, 3)


# --------------------------------------------------------------------------
# candidate generation and selection
# --------------------------------------------------------------------------

def candidates(comps, tokens):
    """
    Every layout whose SHAPE could hold this component set. Cheap filter only —
    fit is decided by validation, not here. Component count alone never selects
    a layout; it only narrows the candidate list.
    """
    L = tokens["layout"]["catalog"]
    n = len(comps)
    types = {c.type for c in comps}
    out = []
    for lid, cat in L.items():
        lo, hi = cat["components"]
        if not (lo <= n <= hi):
            continue
        accepts = set(cat["accepts"])
        if "*" not in accepts and not types <= accepts:
            continue
        if "grid" in cat and n != cat["grid"]["rows"] * cat["grid"]["cols"]:
            continue
        if lid == "L20_PAGINATED":
            continue  # terminal fallback only, never a candidate
        out.append(lid)
    return out


def select_layout(slide, comps, frame, tokens, scale):
    """
    Generate → validate → score → pick. Then, if nothing is valid, walk the
    fallback chains in the token catalog before considering pagination.
    """
    requested = slide.get("layout")
    considered, rejected, valid = [], [], []

    def evaluate(lid):
        regions = resolve_geometry(lid, comps, frame, tokens, scale)
        if regions and lid != "L10_VERTICAL_STACK":
            regions = pack_rows(regions, comps, frame, tokens)
        if not regions:
            rejected.append({"layout": lid, "reason": "shape_mismatch"})
            return None
        viol = validate(lid, regions, comps, frame, tokens, scale)
        if viol:
            rejected.append({"layout": lid, "reason": viol[0]["code"],
                             "detail": viol[0]["detail"],
                             "all_violations": [x["code"] for x in viol]})
            return None
        sc, parts, pen, fill = score(lid, regions, comps, frame, tokens, requested,
                                     slide.get("_band", "balanced"))
        entry = {"layout": lid, "score": sc, "criteria": parts, "penalties": pen,
                 "fill": fill, "regions": regions}
        valid.append(entry)
        return entry

    for lid in candidates(comps, tokens):
        considered.append(lid)
        evaluate(lid)

    if not valid:
        # Fallback chains: walk them in declared order from the closest-fitting
        # rejected layout. Reflow first (tighter gutters), then chain.
        chain = []
        seed = requested or (rejected[0]["layout"] if rejected else "L10_VERTICAL_STACK")
        queue = list(tokens["layout"]["catalog"].get(seed, {}).get("fallbacks", []))
        seen = set()
        while queue:
            lid = queue.pop(0)
            if lid in seen or lid == "L20_PAGINATED":
                continue
            seen.add(lid)
            chain.append(lid)
            if lid not in considered:
                considered.append(lid)
            if evaluate(lid):
                break
            queue.extend(tokens["layout"]["catalog"].get(lid, {}).get("fallbacks", []))
        if not valid:
            return {"selected_layout": "L20_PAGINATED", "regions": [],
                    "score": None, "considered": considered, "rejected": rejected,
                    "fallback_chain": chain, "fill": 0.0,
                    "reason": ["No layout satisfies the hard constraints at minimum "
                               "readable geometry.",
                               "Escalation order exhausted through layout change — "
                               "the slide must split at a sub-topic boundary.",
                               "Shrinking type is not an available move."]}

    best = max(valid, key=lambda e: e["score"])
    reason = _explain(best, comps, rejected, tokens)
    return {"selected_layout": best["layout"], "regions": best["regions"],
            "score": best["score"], "criteria": best["criteria"],
            "penalties": best["penalties"], "fill": best["fill"],
            "considered": considered, "rejected": rejected,
            "runners_up": sorted([{"layout": e["layout"], "score": e["score"]}
                                  for e in valid if e is not best],
                                 key=lambda e: -e["score"])[:3],
            "fallback_chain": [], "reason": reason}


def _explain(best, comps, rejected, tokens):
    """Human-readable justification — the diagnostics contract."""
    out = []
    kinds = ", ".join(f"{c.type}({c.role})" for c in comps)
    detail = "detailed" if any(c.text_heavy for c in comps) else "compact"
    out.append(f"{len(comps)} component(s) detected: {kinds} — {detail} content")
    cat = tokens["layout"]["catalog"][best["layout"]]
    out.append(cat["use"])
    worst = min(best["criteria"], key=best["criteria"].get)
    out.append(f"weakest criterion {worst} at {best['criteria'][worst]}/10; "
               f"fill {best['fill']:.0%}")
    for r in rejected[:3]:
        out.append(f"{r['layout']} rejected: {r['reason']}")
    out.append("All components satisfy minimum dimensions.")
    return out


# --------------------------------------------------------------------------
# balance audit (post-geometry)
# --------------------------------------------------------------------------

GROW_CAP = {"cards": 0.30, "rail": 0.30, "callouts": 0.55, "table": 0.35}


def effective_h(region, comp=None):
    """Height the renderer will actually occupy: natural, plus the capped growth
    the two-phase distributor hands back, bounded by the region."""
    h = region["natural_h"] or region["h"]
    cap = GROW_CAP.get(region["type"], 0.50 if region["type"] in
                       ("chart", "matrix", "timeline") else 0.0)
    return min(region["h"], h * (1 + cap))


def balance_report(regions, frame, tokens):
    B = tokens["layout"]["balance"]
    if not regions:
        return {}
    area = frame["w"] * frame["h"]
    used = sum(effective_h(r) * r["w"] for r in regions)
    mid = frame["x"] + frame["w"] / 2
    left = sum(r["w"] * r["h"] for r in regions if r["x"] + r["w"] / 2 < mid)
    right = sum(r["w"] * r["h"] for r in regions if r["x"] + r["w"] / 2 >= mid)
    ink = left + right or 1
    bottom_used = max((r["y"] + effective_h(r) for r in regions), default=frame["y"])
    deadzone = max(0.0, (frame["y"] + frame["h"] - bottom_used) / frame["h"])
    findings = []
    fill = used / area
    if fill < B["target_fill_min"]:
        findings.append(f"fill {fill:.0%} below target {B['target_fill_min']:.0%} — "
                        f"pull related content forward or scale up")
    if fill > B["target_fill_max"]:
        findings.append(f"fill {fill:.0%} above {B['target_fill_max']:.0%} — crowded")
    peers = [r for r in regions if r["role"] in ("comparison", "secondary")]
    if len(peers) >= 2 and abs(left - right) / ink > B["max_side_imbalance"]:
        findings.append(f"peer regions unbalanced left/right by "
                        f"{abs(left - right) / ink:.0%}")
    if deadzone > B["max_deadzone_share"]:
        findings.append(f"{deadzone:.0%} of the lower content band is empty")
    return {"fill": round(fill, 3), "left_share": round(left / ink, 3),
            "deadzone_share": round(deadzone, 3), "findings": findings}


# --------------------------------------------------------------------------
# pagination — the terminal fallback, with a semantic split point
# --------------------------------------------------------------------------

def split_point(comps):
    """
    Split at a sub-topic boundary, not at a character count. A `header` block
    starts a sub-topic, so it is the preferred seam; failing that, the block
    boundary nearest the halfway point of the character load.
    """
    for i, c in enumerate(comps):
        if c.type == "header" and 0 < i < len(comps):
            return i, "header block starts a new sub-topic"
    total = sum(c.chars for c in comps) or 1
    run, best, gap = 0, 1, 1e9
    for i, c in enumerate(comps[:-1]):
        run += c.chars
        d = abs(run / total - 0.5)
        if d < gap:
            gap, best = d, i + 1
    return best, "nearest block boundary to the midpoint of the character load"


def pagination_for(comps, decision):
    if decision["selected_layout"] != "L20_PAGINATED":
        return {"action": "keep"}
    if len(comps) < 2:
        return {"action": "split_component",
                "reason": "a single component exceeds one slide at minimum readable "
                          "geometry — split the component itself (table rows, rail items), "
                          "never the type size"}
    idx, why = split_point(comps)
    if idx == 0 or idx >= len(comps):
        idx = max(1, len(comps) // 2)
    return {"action": "split", "at_block": idx, "reason": why,
            "continuation_rule": "the continuation slide must carry a complete sub-topic "
                                 "and its own assertion title; never one orphaned card"}


# --------------------------------------------------------------------------
# top level
# --------------------------------------------------------------------------

def plan_slide(slide, tokens):
    chars = slide_chars(slide)
    band, band_action = classify(chars, tokens)
    scale = resolve_scale(band, tokens)
    frame = slide_frame(slide, tokens, scale)

    blocks = [b for b in slide.get("blocks", []) if b.get("type") not in
              ("footnote", "source", "citation", "pagenum")]
    comps = [Component(i, b, tokens, scale) for i, b in enumerate(blocks)]
    for c in comps:
        c.max_h = frame["h"]
    assign_roles(comps, tokens)

    sources = set()
    for b in blocks:
        for nplus in b.get("cite", []) or []:
            sources.add(int(nplus))
        for it in b.get("items", []) or []:
            if isinstance(it, dict):
                for nplus in it.get("cite", []) or []:
                    sources.add(int(nplus))
    cx, cband, cdetail = complexity(comps, tokens, len(sources))

    if not comps:
        return {"id": slide.get("id"), "band": band, "chars": chars,
                "selected_layout": None, "regions": [], "frame": frame,
                "diagnostics": {"reason": ["no content blocks"]}}

    slide = dict(slide, _band=band)
    decision = select_layout(slide, comps, frame, tokens, scale)
    bal = balance_report(decision["regions"], frame, tokens)
    page = pagination_for(comps, decision)

    return {
        "id": slide.get("id"),
        "title": slide.get("title", ""),
        "band": band,
        "band_action": band_action,
        "scale": scale,
        "chars": chars,
        "complexity": {"points": cx, "band": cband, "detail": cdetail},
        "frame": frame,
        "selected_layout": decision["selected_layout"],
        "regions": decision["regions"],
        "roles": [{"block": c.idx, "type": c.type, "role": c.role,
                   "chars": c.chars, "text_heavy": c.text_heavy} for c in comps],
        "balance": bal,
        "pagination": page,
        "diagnostics": {
            "selected_layout": decision["selected_layout"],
            "score": decision.get("score"),
            "criteria": decision.get("criteria"),
            "penalties": decision.get("penalties"),
            "reason": decision.get("reason", []),
            "considered_layouts": decision.get("considered", []),
            "rejected_layouts": decision.get("rejected", []),
            "runners_up": decision.get("runners_up", []),
            "fallback_chain": decision.get("fallback_chain", []),
        },
    }


def plan_deck(spec, tokens):
    slides = [plan_slide(s, tokens) for s in spec.get("slides", [])]
    return {"deck": spec.get("deck", "Untitled"),
            "palette": spec.get("palette", tokens["palettes"]["default"]),
            "canvas": tokens["canvas"], "grid": tokens["grid"],
            "slides": slides,
            "verdict": "SPLIT" if any(s.get("selected_layout") == "L20_PAGINATED"
                                      for s in slides) else "OK"}


def render_report(plan):
    out = []
    add = out.append
    add("=" * 78)
    add(f"  {plan['deck']}   —   layout intelligence plan")
    add("=" * 78)
    for s in plan["slides"]:
        add("")
        add(f"{s['id']}  {s['title'][:66]}")
        add(f"  {s['chars']} chars / {s['band']} band   |   complexity "
            f"{s['complexity']['points']} pts / {s['complexity']['band']}")
        add(f"  frame  x{s['frame']['x']} y{s['frame']['y']} "
            f"{s['frame']['w']}x{s['frame']['h']}in")
        add(f"  LAYOUT {s['selected_layout']}"
            + (f"   score {s['diagnostics']['score']}"
               if s["diagnostics"].get("score") is not None else ""))
        for r in s["diagnostics"]["reason"]:
            add(f"     - {r}")
        for reg in s["regions"]:
            add(f"     [{reg['slot']}] {reg['type']:<9} {reg['role']:<10} "
                f"x{reg['x']:.2f} y{reg['y']:.2f} {reg['w']:.2f}x{reg['h']:.2f}in "
                f"(needs {reg['natural_h']:.2f}in)")
        if s["diagnostics"]["rejected_layouts"]:
            worst = s["diagnostics"]["rejected_layouts"][:4]
            add("     rejected: " + ", ".join(f"{r['layout']}={r['reason']}" for r in worst))
        if s["balance"].get("findings"):
            for f in s["balance"]["findings"]:
                add(f"     !! balance: {f}")
        if s["pagination"]["action"] != "keep":
            add(f"     >> {s['pagination']['action'].upper()}: {s['pagination']['reason']}")
    add("")
    add("-" * 78)
    add(f"verdict: {plan['verdict']}")
    return "\n".join(out)


# --------------------------------------------------------------------------
# selftest — every worked example in the specification, asserted
# --------------------------------------------------------------------------

def _slide(blocks, title="A sentence-case assertion stating the so-what", **kw):
    s = {"id": "t", "title": title, "blocks": blocks}
    s.update(kw)
    return s


def selftest():
    tokens = load_tokens()
    fails = []

    def want(name, blocks, expect, **kw):
        got = plan_slide(_slide(blocks, **kw), tokens)["selected_layout"]
        if got != expect:
            fails.append(f"{name}: got {got}, want {expect}")

    LONG = ("Club placement concentrates presence in the West and Southeast, and the "
            "absence of a 2016 club programme left the Midwest and Texas uncovered "
            "rather than lost, which changes how the gap should be priced. ")
    SHORT = "Club placement concentrates presence in the West."

    chart = {"type": "chart", "title": "Gross sales by channel", "chartType": "bar",
             "labels": ["Club", "Retail", "Foodservice"],
             "series": [{"name": "2016", "values": [4.2, 3.1, 1.8]}]}

    want("one chart", [chart], "L01_SINGLE")
    want("chart + short commentary", [chart, {"type": "body", "text": SHORT}],
         "L13_CHART_COMMENTARY")
    want("chart + long commentary",
         [chart, {"type": "body", "text": LONG * 3}], "L10_VERTICAL_STACK")

    three_short = [{"type": "cards", "items": [
        {"title": "Retail", "body": "Largest branded whitespace."}]} for _ in range(3)]
    want("three short blocks", three_short, "L05_THREE_COLUMN")

    four_kpi = [{"type": "callouts", "items": [{"value": "46.7%", "label": "VAM share"}]}
                for _ in range(4)]
    want("four compact KPIs", four_kpi, "L06_FOUR_COLUMN")

    four_detail = [{"type": "cards", "items": [
        {"title": "Win traditional grocery first", "body": LONG}]} for _ in range(4)]
    want("four detailed insights", four_detail, "L07_GRID_2X2")

    six_short = [{"type": "cards", "items": [{"title": "Club", "body": "Major."}]}
                 for _ in range(6)]
    want("six short cards", six_short, "L08_GRID_2X3")

    table = {"type": "table", "headers": ["Region", "Presence", "Key markets"],
             "rows": [["Northwest", "Major", "Portland, Salem, Central Point"],
                      ["Los Angeles", "Major", "Inglewood, Marina del Rey"],
                      ["Southeast", "Major", "Atlanta, Charlotte, Myrtle Beach"]],
             "has_tags": True}
    want("one table", [table], "L01_SINGLE")
    want("table + concise takeaway",
         [table, {"type": "callouts", "items": [
             {"value": ">60%", "label": "Top 10 customer concentration"}]}],
         "L14_TABLE_INSIGHT")

    matrix = {"type": "matrix", "x_label": "Margin", "y_label": "Growth",
              "items": [{"label": "Club", "x": 0.7, "y": 0.8}]}
    want("matrix + annotation", [matrix, {"type": "bullets", "items": [
        {"text": "Club sits high-growth, high-margin."}]}], "L17_MATRIX")

    timeline = {"type": "timeline", "items": [
        {"label": "2014", "body": "Plant opened"},
        {"label": "2016", "body": "Club placement"},
        {"label": "2018", "body": "Foodservice entry"}]}
    want("timeline", [timeline], "L16_TIMELINE")

    kpis = {"type": "callouts", "items": [
        {"value": "46.7%", "label": "VAM share"}, {"value": ">60%", "label": "Top 10"}]}
    want("KPI strip + chart", [kpis, chart], "L15_KPI_CHART")

    # --- hard constraints ------------------------------------------------
    p = plan_slide(_slide(four_detail), tokens)
    rej = {r["layout"]: r["reason"] for r in p["diagnostics"]["rejected_layouts"]}
    if rej.get("L06_FOUR_COLUMN") not in ("minimum_width_violation", "column_text_too_long"):
        fails.append(f"four detailed cards must reject L06, got {rej.get('L06_FOUR_COLUMN')}")

    # two detailed tables side by side must never be chosen
    two_tables = [table, dict(table)]
    got = plan_slide(_slide(two_tables), tokens)["selected_layout"]
    if got == "L02_SPLIT_EQUAL":
        fails.append("two tables must not go side by side")

    # a sidebar may never hold a chart
    side = plan_slide(_slide([table, chart]), tokens)
    if side["selected_layout"] == "L11_MAIN_SIDEBAR":
        fails.append("chart in a sidebar must be rejected")

    # explicit role wins over inference
    forced = plan_slide(_slide([{"type": "body", "text": SHORT, "role": "primary"}, chart]),
                        tokens)
    roles = {r["block"]: r["role"] for r in forced["roles"]}
    if roles[0] != "primary":
        fails.append("explicit role=primary must not be overruled")

    # measurement agreement with the renderer's own estimator
    if estimate_lines("x" * 100, 3.0, 10, False) != math.ceil(100 / int(3.0 / (10 / 72 * 0.5))):
        fails.append("estimate_lines drifted from the renderer formula")

    # frame never escapes the content band
    for s in (_slide([chart]), _slide(six_short), _slide([table])):
        pl = plan_slide(s, tokens)
        for r in pl["regions"]:
            if r["y"] + r["h"] > tokens["grid"]["content_bottom_in"] + 0.02:
                fails.append(f"region escapes content band in {pl['selected_layout']}")
                break

    # overload must paginate rather than shrink
    huge = [{"type": "table", "headers": ["A", "B", "C"],
             "rows": [["Region " + str(i), LONG[:60], LONG[:60]] for i in range(26)]}]
    hp = plan_slide(_slide(huge), tokens)
    if hp["selected_layout"] != "L20_PAGINATED":
        fails.append(f"26-row table must paginate, got {hp['selected_layout']}")
    elif hp["pagination"]["action"] not in ("split", "split_component"):
        fails.append("paginated slide must carry a split instruction")

    if fails:
        print("SELFTEST FAILED")
        for f in fails:
            print("  -", f)
        return 1
    print("SELFTEST PASSED  (20 layout-selection and constraint assertions)")
    return 0


def main():
    ap = argparse.ArgumentParser(description="pe-deck-design composition engine")
    ap.add_argument("spec", nargs="?")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("-o", "--out")
    ap.add_argument("--tokens", default=TOKENS_PATH)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    if args.selftest:
        return selftest()
    if not args.spec:
        ap.error("spec is required unless --selftest")

    tokens = load_tokens(args.tokens)
    with open(args.spec, encoding="utf-8") as fh:
        spec = json.load(fh)
    plan = plan_deck(spec, tokens)
    text = json.dumps(plan, indent=2) if args.json else render_report(plan)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(text)
        print(f"wrote {args.out}  (verdict: {plan['verdict']})")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())

````

## FILE: `scripts/pe_components.js`

````javascript
/**
 * pe_components.js — the rendering half of the pe-deck-design skill.
 *
 * A pptxgenjs layer that makes the specification's component rules structural
 * rather than a thing you remember to do.
 *
 * ARCHITECTURE — two-phase layout
 * -------------------------------
 * Naive builders place each component the moment it is declared, at its natural
 * height, top-anchored. That produces the single most recognisable defect in
 * generated decks: a correct-looking top third and a dead bottom half.
 *
 * So rendering happens in two passes:
 *
 *   1. MEASURE   — every block reports { natural, min, growable } without drawing.
 *   2. DISTRIBUTE — leftover vertical space goes back to the growable blocks
 *      (capped), then to the gaps (capped); only then does anything draw.
 *
 * This makes the specification mechanical: "Content volume determines component
 * size, spacing and structure. Never preserve fixed dimensions at the cost of
 * whitespace or readability." Underfill and overflow both become numbers the
 * build reports, rather than defects a human has to spot.
 *
 * Component law, not configurable:
 *   card     1pt neutral border, no fill
 *   rail     1pt border, gradient of that border colour
 *   callout  no border, gradient of the primary colour
 *   citation same family, one step down, muted, never bold or boxed
 *
 * Gradient note: pptxgenjs cannot emit an OOXML gradient fill. Gradients ship as
 * alpha PNGs rendered at build time through sharp — the only route that survives
 * a round trip into PowerPoint.
 *
 * Usage:
 *     const { Deck } = require('./pe_components');
 *     const deck = new Deck({ palette: 'graphite_navy' });
 *     const s = deck.slide({ band: 'balanced', eyebrow: 'STRATEGY', title: '...' });
 *     await s.compose([
 *       { type: 'callouts', items: [...] },
 *       { type: 'cards',    items: [...] },
 *     ]);
 *     s.source().pageNumber(2);
 *     await deck.save('out.pptx');
 */

'use strict';

const fs = require('fs');
const path = require('path');
const PptxGenJS = require('pptxgenjs');
const sharp = require('sharp');

const TOKENS = JSON.parse(
  fs.readFileSync(path.join(__dirname, '..', 'assets', 'design-tokens.json'), 'utf8')
);

const GAP_MIN = 0.12;
const GAP_NATURAL = 0.20;
const GAP_MAX = 0.46;
// How far each component may stretch beyond its natural height. A card is a
// content container, so stretching it just moves dead space inside the border;
// a table genuinely reads better with taller rows. These caps encode that.
const GROW_CAP = { cards: 0.30, rail: 0.30, callouts: 0.55, table: 0.35, default: 0.50 };
const HEADER_SEAM = 0.10; // fixed gap between a header and the block it introduces

/* ------------------------------------------------------------------ */
/* colour                                                              */
/* ------------------------------------------------------------------ */

/** Mix a hex colour toward white. pct 100 = the colour, pct 0 = white. */
function tint(hex, pct) {
  const c = hex.replace('#', '');
  const f = Math.max(0, Math.min(100, pct)) / 100;
  const mix = (i) => {
    const v = parseInt(c.substr(i, 2), 16);
    return Math.round(255 + (v - 255) * f).toString(16).padStart(2, '0');
  };
  return (mix(0) + mix(2) + mix(4)).toUpperCase();
}

/* ------------------------------------------------------------------ */
/* text metrics                                                        */
/* ------------------------------------------------------------------ */

/**
 * Estimated wrapped line count.
 *
 * Deliberately pessimistic for headers: Manrope has no metric-compatible
 * substitute in the QA renderer and sets wider than Arial at the same point
 * size. Under-estimating header lines is exactly what makes a card title
 * collide with its own body, so the header advance is set wide on purpose.
 */
function estimateLines(text, widthIn, fontPt, { header = false } = {}) {
  if (!text) return 0;
  const em = fontPt / 72;
  const advance = em * (header ? 0.60 : 0.50);
  const perLine = Math.max(6, Math.floor(widthIn / advance));
  return String(text)
    .split('\n')
    .reduce((n, para) => n + Math.max(1, Math.ceil(para.length / perLine)), 0);
}

function textHeightIn(text, widthIn, fontPt, lineMult, opts) {
  return (estimateLines(text, widthIn, fontPt, opts) * fontPt * lineMult) / 72;
}

/** [3] · [3, 7] · [3-7] — mirrors layout_engine.format_citation exactly. */
function formatCitation(nums) {
  const s = [...new Set((nums || []).map(Number))].sort((a, b) => a - b);
  if (!s.length) return '';
  const parts = [];
  let start = s[0], prev = s[0];
  for (const n of s.slice(1).concat([null])) {
    if (n !== null && n === prev + 1) { prev = n; continue; }
    if (prev - start >= 2) parts.push(`${start}-${prev}`);
    else if (prev !== start) parts.push(String(start), String(prev));
    else parts.push(String(start));
    if (n !== null) { start = n; prev = n; }
  }
  return `[${parts.join(', ')}]`;
}

const CITE_RE = /\[\s*\d+(?:\s*[,\u2013-]\s*\d+)*\s*\]/g;

/**
 * The width prose actually sets to inside a region. Capped at the maximum
 * readable line length from the tokens: a full-bleed 12.33in paragraph at 10pt
 * runs ~177 characters a line, and past ~110 the eye loses the line return.
 * Mirrors compose_engine.Component.measure_width() exactly.
 */
function measureWidth(regionW, fontPt) {
  const cap = TOKENS.layout.readability.max_chars_per_line * (fontPt / 72) * 0.50;
  return Math.min(regionW, cap);
}

/** Visible characters, with inline [n] citations stripped — citations are metadata. */
function visibleChars(text) {
  return text ? String(text).replace(CITE_RE, '').trim().length : 0;
}

/** Character load of one compose() block, matching layout_engine.py exactly. */
function blockChars(b) {
  let n = visibleChars(b.title) + visibleChars(b.text) + visibleChars(b.body);
  for (const it of b.items || []) {
    if (typeof it === 'string') { n += visibleChars(it); continue; }
    for (const k of ['title', 'label', 'value', 'body', 'text']) n += visibleChars(it[k]);
  }
  for (const h of b.headers || []) n += visibleChars(h);
  for (const r of b.rows || []) for (const c of r) n += visibleChars(c);
  return n;
}

/* ------------------------------------------------------------------ */
/* gradient fills, as alpha PNGs                                       */
/* ------------------------------------------------------------------ */

const gradientCache = new Map();

async function gradientPng(fromHex, toHex, wIn, hIn, radiusIn) {
  const key = `${fromHex}-${toHex}-${wIn.toFixed(2)}-${hIn.toFixed(2)}-${radiusIn}`;
  if (gradientCache.has(key)) return gradientCache.get(key);

  const dpi = 384;                        // 4x, so PowerPoint scaling stays crisp
  const w = Math.max(8, Math.round(wIn * dpi));
  const h = Math.max(8, Math.round(hIn * dpi));
  const r = Math.round(radiusIn * dpi);

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
    <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#${fromHex}"/>
      <stop offset="100%" stop-color="#${toHex}"/>
    </linearGradient></defs>
    <rect x="0" y="0" width="${w}" height="${h}" rx="${r}" ry="${r}" fill="url(#g)"/>
  </svg>`;

  const buf = await sharp(Buffer.from(svg)).png().toBuffer();
  const data = 'image/png;base64,' + buf.toString('base64');
  gradientCache.set(key, data);
  return data;
}

/* ------------------------------------------------------------------ */
/* Slide                                                               */
/* ------------------------------------------------------------------ */

class Slide {
  constructor(deck, pptxSlide, { band = 'balanced', title, eyebrow, cite = [] } = {}) {
    this.deck = deck;
    this.s = pptxSlide;
    this.band = band;
    this.scale = TOKENS.type.scales[band] || TOKENS.type.scales.balanced;
    this.p = deck.palette;
    this.g = TOKENS.grid;
    this.t = TOKENS.type;
    this.y = this.g.content_top_in;
    this.sources = new Set(cite);
    this.chars = 0;        // visible characters, citations excluded
    this.overrun = 0;      // inches of content past the content area
    this.underfill = 0;    // fraction of the content area left empty

    this.chars += visibleChars(title) + visibleChars(eyebrow);
    if (eyebrow) this._eyebrow(eyebrow);
    if (title) this._title(title, cite);
    this.contentTop = this.y;
  }

  // Every component reads its box from the ACTIVE FRAME, never from the slide.
  // In the default vertical flow the frame is the full content band; under
  // composeResolved() it is the region the layout engine allocated. This is the
  // whole of what makes the renderer a painter rather than a layout author.
  get width() { return this._frame ? this._frame.w : this.g.content_width_in; }
  get left() { return this._frame ? this._frame.x : this.g.margin_left_in; }

  _note(nums) { (nums || []).forEach((n) => this.sources.add(Number(n))); }

  /**
   * Body text plus a muted citation run. Citations stay visually subordinate:
   * same family, one step down, muted colour, never bold, never boxed.
   */
  _runs(text, cite, fontPt) {
    if (!cite || !cite.length) return String(text);
    this._note(cite);
    return [
      { text: String(text) + ' ', options: {} },
      {
        text: formatCitation(cite),
        options: {
          fontSize: Math.max(TOKENS.type.footnote_floor_pt, fontPt - 1),
          color: this.p.muted,
          bold: false,
        },
      },
    ];
  }

  _citeTail(cite) {
    return cite && cite.length ? ' ' + formatCitation(cite) : '';
  }

  /* -- fixed bands --------------------------------------------------- */

  _eyebrow(text) {
    // The spec caps an ALL CAPS label at 18 characters. Silently clipping the
    // text loses content, which is worse than the violation: warn and keep it.
    if (String(text).length > TOKENS.type.case.allcaps_max_chars) {
      console.warn(
        `WARN eyebrow "${text}" is ${String(text).length} characters; the spec caps ` +
        `ALL CAPS labels at ${TOKENS.type.case.allcaps_max_chars}. Shorten it — ` +
        `audit_deck.py will flag it as case.allcaps.`);
    }
    const clean = String(text).toUpperCase();
    this.s.addText(clean, {
      x: this.left, y: 0.34, w: this.width, h: 0.18,
      isTextBox: true, margin: 0,
      fontFace: this.deck.fonts.header, fontSize: this.scale.footnote,
      bold: true, charSpacing: 1.2, color: this.p.muted, align: 'left', fit: 'none',
    });
    this.y = Math.max(this.y, 0.60);
  }

  _title(text, cite) {
    const size = this.scale.title;
    const h = textHeightIn(text, this.width, size, 1.08, { header: true }) + 0.08;
    this.s.addText(this._runs(text, cite, size), {
      x: this.left, y: this.y, w: this.width, h,
      isTextBox: true, margin: 0,
      fontFace: this.deck.fonts.header, fontSize: size, bold: true,
      color: this.p.ink, align: 'left', valign: 'top',
      lineSpacingMultiple: 1.08, fit: 'none',
    });
    // No accent rule under the title — whitespace carries the separation.
    this.y += h + 0.24;
  }

  /* ================================================================== */
  /* compose: measure -> distribute -> render                            */
  /* ================================================================== */

  async compose(blocks) {
    const measured = [];
    for (const b of blocks) {
      const m = await this._measure(b);
      m.kind = b.type;
      this.chars += blockChars(b);
      measured.push(m);
    }

    const available = this.g.content_bottom_in - this.y;
    const n = measured.length;
    const attachedSeams = measured.filter((m, i) => m.attachNext && i < n - 1).length;
    const gaps = Math.max(0, n - 1 - attachedSeams);
    const seamTotal = attachedSeams * HEADER_SEAM;

    const natural = measured.reduce((a, m) => a + m.natural, 0);
    const minimal = measured.reduce((a, m) => a + m.min, 0);

    let gap = GAP_NATURAL;
    let leftover = available - natural - gap * gaps - seamTotal;

    if (leftover < 0) {
      // Recover from the gaps first — never from typography.
      gap = Math.max(GAP_MIN, gaps ? (available - natural - seamTotal) / gaps : GAP_MIN);
      leftover = available - natural - gap * gaps - seamTotal;
      if (leftover < 0) {
        this.overrun = -leftover;
        if (available - minimal - gap * gaps - seamTotal < 0) {
          throw new Error(
            `compose(): needs ${(minimal + gap * gaps).toFixed(2)}in but only ` +
            `${available.toFixed(2)}in is available even at minimum sizes. Split the ` +
            `slide at a logical boundary — the spec forbids shrinking type to fit.`);
        }
      }
    }

    // Hand surplus back: growable blocks first, then the gaps.
    const heights = measured.map((m) => m.natural);
    if (leftover > 0) {
      const growIdx = measured.map((m, i) => (m.growable ? i : -1)).filter((i) => i >= 0);
      const growNat = growIdx.reduce((a, i) => a + measured[i].natural, 0);

      if (growNat > 0) {
        const want = leftover * 0.72;          // most of it to the components
        let given = 0;
        for (const i of growIdx) {
          const share = (measured[i].natural / growNat) * want;
          const cap = GROW_CAP[measured[i].kind] ?? GROW_CAP.default;
          const capped = Math.min(share, measured[i].natural * cap);
          heights[i] += capped;
          given += capped;
        }
        leftover -= given;
      }
      if (gaps > 0 && leftover > 0) {
        const extra = Math.max(0, Math.min(leftover / gaps, GAP_MAX - gap));
        gap += extra;
        leftover -= extra * gaps;
      }
    }

    let cursor = this.y;
    for (let i = 0; i < n; i++) {
      await measured[i].render(cursor, heights[i]);
      // A header belongs to the block beneath it: keep that seam tight so the
      // distributed slack falls between groups, not between a label and its content.
      const seam = measured[i].attachNext && i < n - 1 ? HEADER_SEAM : gap;
      cursor += heights[i] + seam;
    }

    const attached = measured.filter((m, i) => m.attachNext && i < n - 1).length;
    const used = cursor - (n ? gap : 0) - this.contentTop;
    const total = this.g.content_bottom_in - this.contentTop;
    this.underfill = Math.max(0, 1 - used / total);
    this.y = cursor;
    return this;
  }

  /**
   * Render a slide from a resolved plan produced by compose_engine.py.
   *
   * The engine has already decided the layout, the regions and their sizes. The
   * only thing left here is painting: measure the block at the region width the
   * engine allocated, hand back the capped growth the two-phase distributor
   * would have given it, and draw. No layout decision is taken in this method —
   * if the content does not fit its region, that is reported, never silently
   * fixed by shrinking type.
   *
   *   const plan = JSON.parse(fs.readFileSync('plan.json'))..slides[i];
   *   await s.composeResolved(plan, blocks);
   */
  async composeResolved(plan, blocks) {
    this.layout = plan.selected_layout;
    if (plan.selected_layout === 'L20_PAGINATED') {
      throw new Error(
        `composeResolved(): the engine resolved this slide to L20_PAGINATED — ` +
        `${plan.pagination && plan.pagination.reason}. Split the spec at block ` +
        `${plan.pagination && plan.pagination.at_block} and re-plan; do not render it.`);
    }
    let bottom = this.contentTop;
    for (const reg of plan.regions) {
      const b = blocks[reg.block];
      if (!b) throw new Error(`composeResolved(): plan references block ${reg.block}, ` +
                              `which the caller did not supply`);
      // Charts and matrices are letterboxed into an aspect-correct box the
      // engine computed; everything else fills its region width.
      const box = reg.draw || reg;
      this._frame = { x: box.x, w: box.w };
      const m = await this._measure(b);
      m.kind = b.type;
      this.chars += blockChars(b);

      const cap = GROW_CAP[m.kind] ?? GROW_CAP.default;
      const room = reg.draw ? reg.draw.h : reg.h;
      // Charts and matrices are elastic by construction: the engine already
      // sized their box to a legal aspect, so they take it whole. Everything
      // else grows only as far as its type's cap allows.
      const h = (m.kind === 'chart' || m.kind === 'matrix')
        ? room
        : Math.min(room, Math.max(m.natural, m.natural * (1 + cap)));
      if (m.natural > room + 0.02) {
        this.overrun = Math.max(this.overrun, m.natural - room);
        console.warn(
          `WARN ${plan.id || ''} region ${reg.slot} (${b.type}): measures ` +
          `${m.natural.toFixed(2)}in in a ${room.toFixed(2)}in region. The plan and the ` +
          `render disagree — re-run compose_engine.py rather than editing the geometry.`);
      }
      await m.render(box.y, h);
      bottom = Math.max(bottom, box.y + h);
      this._frame = null;
    }
    const total = this.g.content_bottom_in - this.contentTop;
    this.underfill = Math.max(0, 1 - (bottom - this.contentTop) / total);
    this.y = bottom;
    return this;
  }

  async _measure(b) {
    switch (b.type) {
      case 'header':   return this._measureHeader(b);
      case 'body':     return this._measureBody(b);
      case 'bullets':  return this._measureBullets(b);
      case 'cards':    return this._measureCards(b);
      case 'rail':     return this._measureRail(b);
      case 'callouts': return this._measureCallouts(b);
      case 'table':    return this._measureTable(b);
      case 'chart':    return this._measureChart(b);
      case 'matrix':   return this._measureMatrix(b);
      case 'timeline': return this._measureTimeline(b);
      case 'spacer':   return { natural: b.h || 0.2, min: 0, growable: true,
                                render: async () => {} };
      default:
        throw new Error(`compose(): unknown block type ${JSON.stringify(b.type)}`);
    }
  }

  /* -- text blocks ---------------------------------------------------- */

  _measureHeader(b) {
    const size = this.scale.header;
    const h = textHeightIn(b.text, this.width, size, 1.05, { header: true }) + 0.04;
    return {
      natural: h, min: h, growable: false, attachNext: true,
      render: async (y) => {
        this.s.addText(this._runs(b.text, b.cite, size), {
          x: this.left, y, w: this.width, h,
          isTextBox: true, margin: 0,
          fontFace: this.deck.fonts.header, fontSize: size, bold: false,
          color: this.p.primary, align: 'left', valign: 'top',
          lineSpacingMultiple: 1.05, fit: 'none',
        });
      },
    };
  }

  _measureBody(b) {
    const size = this.scale.body;
    const mult = 1.18;
    const w = b.width ? this.width * b.width : measureWidth(this.width, size);
    const h = textHeightIn(b.text + this._citeTail(b.cite), w, size, mult) + 0.06;
    return {
      natural: h, min: h, growable: false,
      render: async (y) => {
        this.s.addText(this._runs(b.text, b.cite, size), {
          x: this.left, y, w, h,
          isTextBox: true, margin: 0,
          fontFace: this.deck.fonts.body, fontSize: size, color: this.p.body,
          align: 'left', valign: 'top', lineSpacingMultiple: mult,
          paraSpaceAfter: this.t.paragraph_space_after_pt, fit: 'none',
        });
      },
    };
  }

  /**
   * Bullets.
   *
   * pptxgenjs gotcha, learned the hard way: a bulleted paragraph cannot hold two
   * differently-styled runs. Any run carrying paragraph properties starts a new
   * paragraph, and any run WITHOUT a bullet option emits its own <a:pPr> with
   * <a:buNone/>, which silently kills the bullet on the whole paragraph. So
   * "bulleted text + muted citation" is unreachable through addText bullets.
   *
   * The marker is therefore drawn as its own text box per item, with the claim
   * in a second box at a fixed hanging indent. That also buys exact control over
   * the indent, which the built-in bullet does not give.
   */
  _measureBullets(b) {
    const size = this.scale.body;
    const mult = 1.18;
    const indent = 0.20;
    const w = measureWidth(this.width, size) - indent;
    const spaceAfter = this.t.paragraph_space_after_pt / 72;

    const items = b.items.map((it) => {
      const text = typeof it === 'string' ? it : it.text;
      const cite = typeof it === 'string' ? null : it.cite;
      return { text, cite, h: textHeightIn(text + this._citeTail(cite), w, size, mult) };
    });
    const natural = items.reduce((a, it) => a + it.h + spaceAfter, 0.04);

    return {
      natural, min: natural, growable: false,
      render: async (y) => {
        let ty = y;
        for (const it of items) {
          this.s.addText('\u2022', {
            x: this.left, y: ty, w: indent - 0.06, h: (size * mult) / 72,
            isTextBox: true, margin: 0,
            fontFace: this.deck.fonts.body, fontSize: size, color: this.p.muted,
            align: 'left', valign: 'top', lineSpacingMultiple: mult, fit: 'none',
          });
          this.s.addText(this._runs(it.text, it.cite, size), {
            x: this.left + indent, y: ty, w, h: it.h,
            isTextBox: true, margin: 0,
            fontFace: this.deck.fonts.body, fontSize: size, color: this.p.body,
            align: 'left', valign: 'top', lineSpacingMultiple: mult, fit: 'none',
          });
          ty += it.h + spaceAfter;
        }
      },
    };
  }

  /* -- cards ----------------------------------------------------------- */

  _measureCards(b) {
    const items = b.items;
    const n = items.length;
    if (n > 6) {
      throw new Error(
        `cards: ${n} items. The spec forbids shrinking past 6 — switch to a rail or a ` +
        `grouped structure.`);
    }
    const spec = TOKENS.components.card;
    const cols = b.columns || Math.min(n, n <= 3 ? n : 3);
    const rows = Math.ceil(n / cols);
    const gap = spec.gap_in;
    const cw = (this.width - gap * (cols - 1)) / cols;
    const innerW = cw - spec.pad_x_in * 2;
    const titlePt = this.scale.header;
    const bodyPt = this.scale.body;
    const padY = spec.pad_y_in * (n <= 3 ? 1.3 : 1.0);

    const cardH = items.map((it) =>
      textHeightIn(it.title || '', innerW, titlePt, 1.08, { header: true }) +
      (it.title && it.body ? 0.10 : 0) +
      textHeightIn((it.body || '') + this._citeTail(it.cite), innerW, bodyPt, 1.18) +
      padY * 2);

    // Cards within a row share a common height, per the spec.
    const rowNat = [];
    for (let r = 0; r < rows; r++) {
      rowNat.push(Math.max(...cardH.slice(r * cols, (r + 1) * cols)));
    }
    const natural = rowNat.reduce((a, h) => a + h, 0) + gap * (rows - 1);

    return {
      natural, min: natural, growable: true,
      render: async (y, h) => {
        const extra = Math.max(0, h - natural);
        let cursor = y;
        for (let r = 0; r < rows; r++) {
          const slice = items.slice(r * cols, (r + 1) * cols);
          const rowH = rowNat[r] + (extra * rowNat[r]) / (natural || 1);
          const pad = padY + Math.min(0.24, Math.max(0, (rowH - rowNat[r]) / 2));

          slice.forEach((it, i) => {
            const x = this.left + i * (cw + gap);
            this.s.addShape(this.deck.pptx.ShapeType.roundRect, {
              x, y: cursor, w: cw, h: rowH,
              fill: { type: 'none' },                    // spec: no background fill
              line: { color: this.p.neutral_line, width: spec.border_pt },
              rectRadius: spec.radius_in,
            });

            let ty = cursor + pad;
            if (it.title) {
              const th = textHeightIn(it.title, innerW, titlePt, 1.08, { header: true });
              this.s.addText(it.title, {
                x: x + spec.pad_x_in, y: ty, w: innerW, h: th,
                isTextBox: true, margin: 0,
                fontFace: this.deck.fonts.header, fontSize: titlePt, bold: true,
                color: this.p.ink, lineSpacingMultiple: 1.08, valign: 'top', fit: 'none',
              });
              ty += th + 0.10;
            }
            if (it.body) {
              const bh = textHeightIn((it.body || '') + this._citeTail(it.cite),
                                      innerW, bodyPt, 1.18);
              this.s.addText(this._runs(it.body, it.cite, bodyPt), {
                x: x + spec.pad_x_in, y: ty, w: innerW, h: bh,
                isTextBox: true, margin: 0,
                fontFace: this.deck.fonts.body, fontSize: bodyPt, color: this.p.body,
                lineSpacingMultiple: 1.18, valign: 'top', fit: 'none',
              });
            }
          });
          cursor += rowH + gap;
        }
      },
    };
  }

  /* -- rail ------------------------------------------------------------ */

  _measureRail(b) {
    const items = b.items;
    const n = items.length;
    if (n > 6) {
      throw new Error(
        `rail: ${n} items. The spec forbids shrinking past 6 — split the rail or change ` +
        `the component.`);
    }
    const spec = TOKENS.components.rail;
    const line = b.accent || this.p.primary;
    const gap = spec.gap_in;

    // Item width follows content length, pulled toward the mean so nothing
    // collapses to a sliver and nothing hogs the rail.
    const loads = items.map((it) =>
      Math.max(18, (it.title || '').length + (it.body || '').length));
    const mean = loads.reduce((a, x) => a + x, 0) / n;
    const weights = loads.map((l) => 0.6 + 0.4 * (l / mean));
    const wsum = weights.reduce((a, x) => a + x, 0);
    const avail = this.width - gap * (n - 1);
    const widths = weights.map((w) => (w / wsum) * avail);

    const titlePt = this.scale.body;
    const bodyPt = this.scale.body;
    const heights = items.map((it, i) => {
      const inner = widths[i] - spec.pad_x_in * 2;
      return textHeightIn(it.title || '', inner, titlePt, 1.08, { header: true }) +
             (it.title && it.body ? 0.08 : 0) +
             textHeightIn((it.body || '') + this._citeTail(it.cite), inner, bodyPt, 1.18) +
             spec.pad_y_in * 2;
    });
    const natural = Math.max(...heights);

    return {
      natural, min: natural, growable: true,
      render: async (y, h) => {
        let x = this.left;
        for (let i = 0; i < n; i++) {
          const w = widths[i];
          const img = await gradientPng(
            tint(line, TOKENS.components.gradient.tint_start_pct),
            tint(line, TOKENS.components.gradient.tint_end_pct),
            w, h, spec.radius_in);
          this.s.addImage({ data: img, x, y, w, h });
          this.s.addShape(this.deck.pptx.ShapeType.roundRect, {
            x, y, w, h,
            fill: { type: 'none' },
            line: { color: line, width: spec.border_pt },
            rectRadius: spec.radius_in,
          });

          const inner = w - spec.pad_x_in * 2;
          const it = items[i];
          // Centre each item's own content: rail items share a height but not a
          // content length, so top-anchoring leaves short items looking clipped.
          const own = heights[i] - spec.pad_y_in * 2;
          let ty = y + Math.max(spec.pad_y_in, (h - own) / 2);
          if (it.title) {
            const th = textHeightIn(it.title, inner, titlePt, 1.08, { header: true });
            this.s.addText(it.title, {
              x: x + spec.pad_x_in, y: ty, w: inner, h: th,
              isTextBox: true, margin: 0,
              fontFace: this.deck.fonts.header, fontSize: titlePt, bold: true,
              color: this.p.ink, lineSpacingMultiple: 1.08, valign: 'top', fit: 'none',
            });
            ty += th + 0.08;
          }
          if (it.body) {
            const bh = textHeightIn((it.body || '') + this._citeTail(it.cite),
                                    inner, bodyPt, 1.18);
            this.s.addText(this._runs(it.body, it.cite, bodyPt), {
              x: x + spec.pad_x_in, y: ty, w: inner, h: bh,
              isTextBox: true, margin: 0,
              fontFace: this.deck.fonts.body, fontSize: bodyPt, color: this.p.body,
              lineSpacingMultiple: 1.18, valign: 'top', fit: 'none',
            });
          }
          x += w + gap;
        }
      },
    };
  }

  /* -- callouts --------------------------------------------------------- */

  _measureCallouts(b) {
    const items = b.items;
    const n = items.length;
    if (n > 4) {
      throw new Error(
        `callouts: ${n} items. Past three these stop being distinct insights — combine them.`);
    }
    const spec = TOKENS.components.callout;
    const base = b.accent || this.p.primary;
    const gap = spec.gap_in;
    const w = (this.width - gap * (n - 1)) / n;
    const inner = w - spec.pad_x_in * 2;

    const valuePt = n === 1 ? Math.min(TOKENS.type.max_pt, this.scale.title + 1)
                            : this.scale.title;
    const labelPt = this.scale.body;
    const padY = spec.pad_y_in * (n === 1 ? 1.5 : 1.0);

    const heights = items.map((it) =>
      textHeightIn(it.value || '', inner, valuePt, 1.04, { header: true }) + 0.06 +
      textHeightIn((it.label || '') + this._citeTail(it.cite), inner, labelPt, 1.15) +
      padY * 2);
    const natural = Math.max(...heights);

    return {
      natural, min: natural, growable: true,
      render: async (y, h) => {
        const img = await gradientPng(
          tint(base, TOKENS.components.gradient.tint_start_pct),
          tint(base, TOKENS.components.gradient.tint_end_pct),
          w, h, spec.radius_in);

        for (let i = 0; i < n; i++) {
          const x = this.left + i * (w + gap);
          const it = items[i];
          this.s.addImage({ data: img, x, y, w, h });     // no border, per spec

          const vh = textHeightIn(it.value || '', inner, valuePt, 1.04, { header: true });
          const lh = textHeightIn((it.label || '') + this._citeTail(it.cite),
                                  inner, labelPt, 1.15);
          // Centre the block vertically: a grown callout should read as generous
          // whitespace around the metric, not as a metric stuck to the ceiling.
          const top = y + Math.max(padY, (h - (vh + 0.06 + lh)) / 2);

          // The value stays a clean bold run; its citation rides on the label,
          // so the metric never carries bold bracket noise.
          this.s.addText(it.value || '', {
            x: x + spec.pad_x_in, y: top, w: inner, h: vh,
            isTextBox: true, margin: 0,
            fontFace: this.deck.fonts.header, fontSize: valuePt, bold: true,
            color: this.p.primary, lineSpacingMultiple: 1.04, valign: 'top', fit: 'none',
          });
          this.s.addText(this._runs(it.label || '', it.cite, labelPt), {
            x: x + spec.pad_x_in, y: top + vh + 0.06, w: inner, h: lh,
            isTextBox: true, margin: 0,
            fontFace: this.deck.fonts.body, fontSize: labelPt, color: this.p.body,
            lineSpacingMultiple: 1.15, valign: 'top', fit: 'none',
          });
        }
      },
    };
  }


  /* -- chart ------------------------------------------------------------ */

  /**
   * Native pptxgenjs chart — a real chart object, editable in PowerPoint, with
   * its data intact. Never an image of a chart.
   *
   * The chart keeps its own title (set at table_title size so it matches every
   * other exhibit label) and its source line rides INSIDE the allocated box, so
   * the citation never grows the component — DOC: citations must not change a
   * component's layout, and a chart's source is a small line at the bottom of
   * the visual.
   */
  _measureChart(b) {
    const P = this.p;
    const labels = b.labels || [];
    const series = b.series || [{ name: b.name || 'Series 1', values: b.values || [] }];
    const kind = (b.chartType || 'bar').toLowerCase();
    const min = TOKENS.layout.min_dims_in.chart;

    const titleH = b.title
      ? textHeightIn(b.title, this.width, this.scale.table_title, 1.06, { header: true }) + 0.08
      : 0;
    // One source line per slide by default — the footer carries it. A chart
    // only gets its own in-visual source line when the slide holds more than
    // one exhibit and they come from different sources (`sourceLine: true`).
    const showSourceLine = b.sourceLine === true;
    const noteH = (showSourceLine && b.cite && b.cite.length) || b.note
      ? (this.scale.footnote * 1.25) / 72 + 0.06 : 0;
    const natural = titleH + min.h + noteH;

    const palette = [P.primary, P.accent, P.muted, tint(P.primary, 55),
                     tint(P.accent, 55), tint(P.primary, 30)];

    return {
      natural, min: natural, growable: true,
      render: async (y, h) => {
        let ty = y;
        if (b.title) {
          this.s.addText(b.title, {
            x: this.left, y: ty, w: this.width, h: titleH,
            isTextBox: true, margin: 0,
            fontFace: this.deck.fonts.header, fontSize: this.scale.table_title,
            bold: true, color: P.ink, lineSpacingMultiple: 1.06, valign: 'top', fit: 'none',
          });
          ty += titleH;
        }
        const plotH = Math.max(min.h * 0.6, h - titleH - noteH);
        const T = this.deck.pptx.ChartType;
        const TYPE = { bar: T.bar, column: T.bar, barh: T.bar, line: T.line,
                       area: T.area, pie: T.pie, doughnut: T.doughnut,
                       scatter: T.scatter, radar: T.radar }[kind] || T.bar;

        const data = series.map((sr) => ({
          name: sr.name, labels, values: sr.values,
        }));

        // A single series is ONE colour. Cycling a palette across the bars of
        // one series encodes a difference that does not exist; the accent is
        // reserved for the one bar the title is about (`highlight: index`).
        let colours = b.colors || palette;
        if (series.length === 1 && !b.colors) {
          colours = labels.map((_, i) => (i === b.highlight ? P.accent : P.primary));
        }

        this._note(b.cite);
        this.s.addChart(TYPE, data, {
          x: this.left, y: ty, w: this.width, h: plotH,
          barDir: kind === 'barh' ? 'bar' : 'col',
          barGapWidthPct: 55,
          chartColors: colours,
          showLegend: series.length > 1,
          legendPos: 'b',
          legendFontFace: this.deck.fonts.body,
          legendFontSize: this.scale.chart_label,
          legendColor: P.body,
          showTitle: false,
          showValue: b.showValue !== false && series.length === 1 && kind !== 'line',
          dataLabelFontFace: this.deck.fonts.body,
          dataLabelFontSize: this.scale.chart_label,
          dataLabelColor: P.body,
          dataLabelFormatCode: b.format || '#,##0.0',
          catAxisLabelFontFace: this.deck.fonts.body,
          catAxisLabelFontSize: this.scale.chart_label,
          catAxisLabelColor: P.body,
          catAxisLineShow: true,
          catAxisLineColor: P.neutral_line,
          valAxisLabelFontFace: this.deck.fonts.body,
          valAxisLabelFontSize: this.scale.chart_label,
          valAxisLabelColor: P.muted,
          valAxisLineShow: false,
          valAxisLabelFormatCode: b.format || '#,##0',
          valGridLine: { color: P.neutral_line, size: 0.5, style: 'solid' },
          catGridLine: { style: 'none' },
          border: { pt: 0, color: P.surface },
          fill: P.surface,
          holeSize: kind === 'doughnut' ? 58 : undefined,
          lineDataSymbol: 'none',
          lineSize: 2,
        });
        if (noteH) {
          const parts = [];
          if (b.note) parts.push(b.note);
          if (showSourceLine && b.cite && b.cite.length) {
            parts.push(`Source ${formatCitation(b.cite)}`);
          }
          this.s.addText(parts.join(' · '), {
            x: this.left, y: ty + plotH + 0.02, w: this.width, h: noteH,
            isTextBox: true, margin: 0,
            fontFace: this.deck.fonts.body, fontSize: this.scale.footnote,
            color: P.muted, lineSpacingMultiple: 1.15, valign: 'top', fit: 'none',
          });
        }
      },
    };
  }

  /* -- matrix ------------------------------------------------------------ */

  /**
   * A positioning matrix: two axes, four quadrants, optional plotted items.
   * The matrix stays the primary visual — quadrants carry short labels, never
   * paragraphs. Long explanation belongs in a side annotation region, which is
   * exactly what L17_MATRIX allocates.
   */
  _measureMatrix(b) {
    const P = this.p;
    const items = b.items || [];
    const quads = b.quadrants || [];
    const ideal = TOKENS.layout.aspect.matrix.ideal;
    const axisPad = 0.34;                      // room for the two axis labels
    const room = this.g.content_bottom_in - Math.max(this.y, this.contentTop);
    const natural = Math.min(this.width / ideal, Math.max(
      TOKENS.layout.min_dims_in.matrix.h, room));

    return {
      natural, min: TOKENS.layout.min_dims_in.matrix.h, growable: true,
      render: async (y, h) => {
        const x0 = this.left + axisPad;
        const y0 = y;
        const w = this.width - axisPad;
        const hh = h - axisPad;
        const midX = x0 + w / 2;
        const midY = y0 + hh / 2;

        this.s.addShape(this.deck.pptx.ShapeType.rect, {
          x: x0, y: y0, w, h: hh, objectName: 'structure:matrix-frame',
          fill: { type: 'none' }, line: { color: P.neutral_line, width: 0.75 },
        });
        for (const ln of [
          { x: midX, y: y0, w: 0, h: hh }, { x: x0, y: midY, w, h: 0 }]) {
          this.s.addShape(this.deck.pptx.ShapeType.line, {
            ...ln, objectName: 'structure:matrix-axis',
            line: { color: P.neutral_line, width: 0.75, dashType: 'dash' },
          });
        }

        // Quadrant labels, clockwise from top-left.
        const corners = [
          { x: x0 + 0.10, y: y0 + 0.10, align: 'left' },
          { x: midX + 0.10, y: y0 + 0.10, align: 'left' },
          { x: midX + 0.10, y: midY - 0.30, align: 'left' },
          { x: x0 + 0.10, y: midY - 0.30, align: 'left' },
        ];
        quads.slice(0, 4).forEach((q, i) => {
          const c = corners[i];
          this.s.addText(typeof q === 'string' ? q : q.label, {
            x: c.x, y: i >= 2 ? y0 + hh - 0.30 : c.y, w: w / 2 - 0.20, h: 0.22,
            isTextBox: true, margin: 0,
            fontFace: this.deck.fonts.header, fontSize: this.scale.chart_label,
            bold: true, color: P.muted, charSpacing: 0.8,
            align: c.align, valign: 'top', fit: 'none',
          });
        });

        // Plotted items: x and y are 0..1 in axis space, origin bottom-left.
        for (const it of items) {
          const px = x0 + Math.min(1, Math.max(0, it.x)) * w;
          const py = y0 + hh - Math.min(1, Math.max(0, it.y)) * hh;
          const r = it.size ? Math.max(0.10, Math.min(0.34, it.size)) : 0.16;
          this.s.addShape(this.deck.pptx.ShapeType.ellipse, {
            x: px - r / 2, y: py - r / 2, w: r, h: r, objectName: 'structure:matrix-point',
            fill: { color: it.accent ? P.accent : P.primary },
            line: { color: P.surface, width: 1 },
          });
          if (it.label) {
            // A point label may never escape the matrix frame: past the
            // half-way line it flips to the left of its marker, and its width
            // is clamped to the room actually left inside the frame.
            const right = x0 + w;
            const room = right - (px + r / 2 + 0.06);
            const flip = room < 1.10;
            const lw = Math.max(0.8, Math.min(2.2, flip ? px - r / 2 - 0.06 - x0 : room));
            this.s.addText(this._runs(it.label, it.cite, this.scale.body), {
              x: flip ? px - r / 2 - 0.06 - lw : px + r / 2 + 0.06,
              y: py - 0.11, w: lw, h: 0.22,
              isTextBox: true, margin: 0,
              fontFace: this.deck.fonts.body, fontSize: this.scale.body,
              color: P.ink, align: flip ? 'right' : 'left', valign: 'top', fit: 'none',
            });
          }
        }

        if (b.x_label) {
          this.s.addText(b.x_label, {
            x: x0, y: y0 + hh + 0.06, w, h: 0.22,
            isTextBox: true, margin: 0,
            fontFace: this.deck.fonts.header, fontSize: this.scale.chart_label,
            color: P.body, align: 'center', valign: 'top', fit: 'none',
          });
        }
        if (b.y_label) {
          this.s.addText(b.y_label, {
            x: this.left - hh / 2 + 0.17, y: y0 + hh / 2 - 0.11, w: hh, h: 0.22,
            isTextBox: true, margin: 0, rotate: 270,
            fontFace: this.deck.fonts.header, fontSize: this.scale.chart_label,
            color: P.body, align: 'center', valign: 'top', fit: 'none',
          });
        }
      },
    };
  }

  /* -- timeline ---------------------------------------------------------- */

  /**
   * Chronology. Orientation is a CONSEQUENCE of the content, not a style
   * choice: few events with short labels run horizontally; prose entries run
   * vertically. Order is always preserved.
   */
  _measureTimeline(b) {
    const P = this.p;
    const items = b.items || [];
    const n = items.length;
    const longest = Math.max(...items.map((it) => (it.body || '').length + (it.label || '').length), 0);
    const horizontal = b.orientation
      ? b.orientation === 'horizontal'
      : (n <= 6 && longest <= 90 && this.width >= 5.0);
    const bodyPt = this.scale.body;

    if (horizontal) {
      const per = this.width / Math.max(1, n);
      const labelH = Math.max(...items.map((it) =>
        textHeightIn(it.label || '', per - 0.18, bodyPt, 1.10, { header: true })), 0.18);
      const bodyH = Math.max(...items.map((it) =>
        textHeightIn((it.body || '') + this._citeTail(it.cite), per - 0.18, bodyPt, 1.15)), 0);
      const natural = 0.34 + labelH + 0.04 + bodyH;
      return {
        natural, min: natural, growable: false,
        render: async (y) => {
          const axisY = y + 0.16;
          this.s.addShape(this.deck.pptx.ShapeType.line, {
            x: this.left + per / 2, y: axisY, w: this.width - per, h: 0,
            objectName: 'structure:timeline-rail',
            line: { color: this.p.neutral_line, width: 1 },
          });
          items.forEach((it, i) => {
            const cx = this.left + per * i + per / 2;
            this.s.addShape(this.deck.pptx.ShapeType.ellipse, {
              x: cx - 0.055, y: axisY - 0.055, w: 0.11, h: 0.11,
              objectName: 'structure:timeline-marker',
              fill: { color: it.accent ? P.accent : P.primary }, line: { type: 'none' },
            });
            this.s.addText(it.label || '', {
              x: this.left + per * i + 0.09, y: axisY + 0.16, w: per - 0.18, h: labelH,
              isTextBox: true, margin: 0,
              fontFace: this.deck.fonts.header, fontSize: bodyPt, bold: true,
              color: P.ink, align: 'left', valign: 'top', fit: 'none',
            });
            if (it.body) {
              this.s.addText(this._runs(it.body, it.cite, bodyPt), {
                x: this.left + per * i + 0.09, y: axisY + 0.16 + labelH + 0.04,
                w: per - 0.18, h: bodyH,
                isTextBox: true, margin: 0,
                fontFace: this.deck.fonts.body, fontSize: bodyPt, color: P.body,
                lineSpacingMultiple: 1.15, align: 'left', valign: 'top', fit: 'none',
              });
            }
          });
        },
      };
    }

    const labelW = Math.min(1.35, this.width * 0.22);
    const bodyW = this.width - labelW - 0.22;
    const heights = items.map((it) => Math.max(0.30,
      textHeightIn((it.body || '') + this._citeTail(it.cite), bodyW, bodyPt, 1.18) + 0.12));
    const natural = heights.reduce((a, x) => a + x, 0);
    return {
      natural, min: natural, growable: false,
      render: async (y) => {
        let ty = y;
        this.s.addShape(this.deck.pptx.ShapeType.line, {
          x: this.left + labelW + 0.06, y: y + 0.08, w: 0, h: natural - 0.16,
          objectName: 'structure:timeline-rail',
          line: { color: this.p.neutral_line, width: 1 },
        });
        items.forEach((it, i) => {
          this.s.addText(it.label || '', {
            x: this.left, y: ty, w: labelW, h: heights[i],
            isTextBox: true, margin: 0,
            fontFace: this.deck.fonts.header, fontSize: bodyPt, bold: true,
            color: P.ink, align: 'right', valign: 'top', fit: 'none',
          });
          this.s.addShape(this.deck.pptx.ShapeType.ellipse, {
            x: this.left + labelW + 0.005, y: ty + 0.055, w: 0.11, h: 0.11,
            objectName: 'structure:timeline-marker',
            fill: { color: it.accent ? P.accent : P.primary }, line: { type: 'none' },
          });
          this.s.addText(this._runs(it.body || '', it.cite, bodyPt), {
            x: this.left + labelW + 0.22, y: ty, w: bodyW, h: heights[i],
            isTextBox: true, margin: 0,
            fontFace: this.deck.fonts.body, fontSize: bodyPt, color: P.body,
            lineSpacingMultiple: 1.18, valign: 'top', fit: 'none',
          });
          ty += heights[i];
        });
      },
    };
  }

  /* -- table ------------------------------------------------------------ */

  _measureTable(b) {
    const { title, headers, rows, zebra = false, hasTags = false,
            highlightRows = [], cite = [] } = b;

    if (zebra && hasTags) {
      throw new Error(
        'table: zebra striping with tags/pills is forbidden. Keep the background uniform ' +
        'and let the tags carry the differentiation.');
    }
    if (zebra && highlightRows.length) {
      throw new Error('table: zebra striping plus highlighted rows is visual noise. Pick one.');
    }
    if (headers && rows.some((r) => r.length !== headers.length)) {
      throw new Error('table: ragged rows — every row must match the header column count.');
    }

    const t = TOKENS.table;
    const headPt = this.scale.table_header;
    const bodyPt = this.scale.table_body;
    const widths = b.colW || this._autoColumnWidths(headers, rows);

    const titleH = title
      ? textHeightIn(title, this.width, this.scale.table_title, 1.06, { header: true }) + 0.10
      : 0;

    const padPt = t.cell_pad_y_pt[0];
    const cellH = (pt, lines) => (lines * pt * 1.2 + padPt * 2) / 72;
    const headH = cellH(headPt, 1);
    const rowH = rows.map((r) => {
      const lines = Math.max(...r.map((cell, c) =>
        estimateLines(String(cell ?? ''), widths[c] - 0.18, bodyPt)));
      return cellH(bodyPt, Math.max(1, lines));
    });
    const natural = titleH + headH + rowH.reduce((a, h) => a + h, 0);

    return {
      natural, min: natural, growable: true,
      render: async (y, h) => {
        let ty = y;
        if (title) {
          this.s.addText(title, {
            x: this.left, y: ty, w: this.width, h: titleH,
            isTextBox: true, margin: 0,
            fontFace: this.deck.fonts.header, fontSize: this.scale.table_title,
            bold: true, color: this.p.ink, lineSpacingMultiple: 1.06,
            valign: 'top', fit: 'none',
          });
          ty += titleH;
        }

        const isNum = headers.map((_, c) =>
          rows.every((r) => /^[\s$€£]*-?[\d,.]+\s*[%x×bnmk]*$/i.test(String(r[c] ?? '').trim())));

        const none = { type: 'none' };
        const divider = { pt: 0.75, color: this.p.neutral_line };
        const pad = [padPt, t.cell_pad_x_pt[0], padPt, t.cell_pad_x_pt[0]];

        const headerRow = headers.map((hd, c) => ({
          text: String(hd),
          options: {
            bold: true, fontSize: headPt, fontFace: this.deck.fonts.header,
            color: this.p.ink, fill: { color: this.p.neutral_fill },
            align: isNum[c] ? 'right' : 'left', valign: 'bottom', margin: pad,
            border: [none, none, { pt: 1, color: this.p.primary }, none],
          },
        }));

        const bodyRows = rows.map((r, ri) => {
          const stripe = zebra && ri % 2 === 1;
          const highlight = highlightRows.includes(ri);
          return r.map((cell, c) => ({
            text: String(cell ?? ''),
            options: {
              fontSize: bodyPt, fontFace: this.deck.fonts.body,
              // The primary column carries the hierarchy: the only bold body cell.
              bold: c === 0 || highlight,
              color: c === 0 ? this.p.ink : this.p.body,
              align: isNum[c] ? 'right' : 'left', valign: 'top', margin: pad,
              fill: highlight ? { color: tint(this.p.primary, 8) }
                  : stripe ? { color: this.p.neutral_fill }
                  : { color: this.p.surface },
              border: [none, none, divider, none],
            },
          }));
        });

        // Spread surplus across body rows rather than stretching any one row.
        const bodyNat = rowH.reduce((a, x) => a + x, 0);
        const surplus = Math.max(0, h - natural);
        const grown = rowH.map((hh) => hh + (bodyNat ? (surplus * hh) / bodyNat : 0));

        this._note(cite);
        this.s.addTable([headerRow, ...bodyRows], {
          x: this.left, y: ty, w: this.width, colW: widths,
          rowH: [headH, ...grown], autoPage: false, border: { type: 'none' },
        });
      },
    };
  }

  _autoColumnWidths(headers, rows) {
    // Descriptive columns get width proportional to content; numeric and short
    // label columns are floored narrow. No unnecessarily wide empty columns.
    const loads = headers.map((h, c) => {
      const cells = rows.map((r) => String(r[c] ?? '').length);
      const avg = cells.length ? cells.reduce((a, b) => a + b, 0) / cells.length : 0;
      return Math.max(String(h).length * 0.9, avg);
    });
    const total = loads.reduce((a, b) => a + b, 0) || 1;
    const min = 0.85;
    const widths = loads.map((l) => Math.max(min, (l / total) * this.width));
    const scale = this.width / widths.reduce((a, b) => a + b, 0);
    return widths.map((w) => w * scale);
  }

  /* -- footer ----------------------------------------------------------- */

  /**
   * "Note:" line, pinned immediately above the source line. Report convention,
   * and the correct home for scope qualifiers, definitions and exclusions —
   * material that would otherwise bloat a component body or a table cell.
   */
  note(text) {
    if (!text) return this;
    this._noteLine = String(text);
    this.s.addText(`Note: ${this._noteLine}`, {
      x: this.left, y: this.deck.canvas.height_in - 0.58,
      w: this.width - 0.8, h: 0.18,
      isTextBox: true, margin: 0,
      fontFace: this.deck.fonts.body, fontSize: this.scale.footnote,
      color: this.p.muted, lineSpacingMultiple: 1.15, valign: 'top',
      align: 'left', fit: 'none',
    });
    return this;
  }

  /**
   * Exhibit tag, right-aligned in the eyebrow band. Numbered exhibits are how a
   * report deck is cross-referenced from its own text and from a data book;
   * once a deck uses them, every exhibit gets one, numbered deck-wide.
   */
  exhibit(label) {
    this.s.addText(String(label).toUpperCase(), {
      x: this.g.margin_left_in, y: 0.34, w: this.g.content_width_in, h: 0.18,
      isTextBox: true, margin: 0,
      fontFace: this.deck.fonts.header, fontSize: this.scale.footnote,
      bold: true, charSpacing: 1.2, color: this.p.muted, align: 'right', fit: 'none',
    });
    return this;
  }

  /** Source line pinned to the footer band. Never part of the content flow. */
  source(nums, note) {
    this._note(nums);
    if (!this.sources.size && !note) return this;
    const marker = formatCitation([...this.sources]);
    const text = note ? `Source ${marker} · ${note}` : `Source ${marker}`;
    this.s.addText(text, {
      x: this.left, y: this.deck.canvas.height_in - 0.40,
      w: this.width - 0.8, h: 0.20,
      isTextBox: true, margin: 0,
      fontFace: this.deck.fonts.body, fontSize: this.scale.footnote,
      color: this.p.muted, lineSpacingMultiple: 1.15,
      valign: 'top', align: 'left', fit: 'none',
    });
    return this;
  }

  pageNumber(n) {
    this.s.addText(String(n), {
      x: this.deck.canvas.width_in - 0.85, y: this.deck.canvas.height_in - 0.40,
      w: 0.35, h: 0.20, isTextBox: true, margin: 0,
      fontFace: this.deck.fonts.body, fontSize: this.scale.footnote,
      color: this.p.muted, align: 'right', fit: 'none',
    });
    return this;
  }
}

/* ------------------------------------------------------------------ */
/* Deck                                                                */
/* ------------------------------------------------------------------ */

class Deck {
  constructor({ palette = TOKENS.palettes.default, headerFont, bodyFont } = {}) {
    this.pptx = new PptxGenJS();              // one instance per output file
    this.canvas = TOKENS.canvas;
    this.pptx.defineLayout({
      name: 'PE_WIDE', width: this.canvas.width_in, height: this.canvas.height_in,
    });
    this.pptx.layout = 'PE_WIDE';             // set before any slide exists
    this.palette = TOKENS.palettes[palette] || TOKENS.palettes[TOKENS.palettes.default];
    this.fonts = {
      header: headerFont || TOKENS.type.fonts.header,
      body: bodyFont || TOKENS.type.fonts.body,
    };
    this.slides = [];
  }

  slide(opts = {}) {
    const raw = this.pptx.addSlide();
    raw.background = { color: this.palette.surface };
    const s = new Slide(this, raw, opts);
    this.slides.push(s);
    return s;
  }

  /**
   * Cover page. Report register: no imagery, no gradient wash, no centred
   * setting. Client, engagement, date and the confidentiality line, which for
   * a diligence pack is not decoration — it is the distribution control.
   */
  cover({ title, subtitle, client, date, confidential = 'Strictly private and confidential',
          eyebrow } = {}) {
    const raw = this.pptx.addSlide();
    raw.background = { color: this.palette.surface };
    const g = TOKENS.grid;
    const sc = TOKENS.type.scales.sparse;
    const x = g.margin_left_in;
    const w = g.content_width_in;
    if (eyebrow) {
      raw.addText(String(eyebrow).toUpperCase(), {
        x, y: 2.30, w, h: 0.20, isTextBox: true, margin: 0,
        fontFace: this.fonts.header, fontSize: sc.footnote, bold: true,
        charSpacing: 1.4, color: this.palette.muted, fit: 'none',
      });
    }
    const titleW = w * 0.78;
    const titleH = textHeightIn(title || '', titleW, sc.title, 1.10, { header: true }) + 0.06;
    raw.addText(title || '', {
      x, y: 2.60, w: titleW, h: titleH, isTextBox: true, margin: 0,
      fontFace: this.fonts.header, fontSize: sc.title, bold: true,
      color: this.palette.ink, lineSpacingMultiple: 1.10, valign: 'top', fit: 'none',
    });
    // The rule and the subtitle follow the measured title, so a two-line title
    // does not open a hole under a one-line rule.
    const ruleY = 2.60 + titleH + 0.18;
    raw.addShape(this.pptx.ShapeType.line, {
      x, y: ruleY, w: 1.30, h: 0, objectName: 'structure:cover-rule',
      line: { color: this.palette.accent, width: 2 },
    });
    if (subtitle) {
      raw.addText(subtitle, {
        x, y: ruleY + 0.16, w: w * 0.70, h: 0.40, isTextBox: true, margin: 0,
        fontFace: this.fonts.body, fontSize: sc.body, color: this.palette.body,
        lineSpacingMultiple: 1.20, valign: 'top', fit: 'none',
      });
    }
    const meta = [client, date].filter(Boolean).join('  ·  ');
    if (meta) {
      raw.addText(meta, {
        x, y: ruleY + (subtitle ? 0.72 : 0.30), w, h: 0.24, isTextBox: true, margin: 0,
        fontFace: this.fonts.body, fontSize: sc.footnote, color: this.palette.muted,
        fit: 'none',
      });
    }
    if (confidential) {
      raw.addText(confidential, {
        x, y: this.canvas.height_in - 0.46, w, h: 0.20, isTextBox: true, margin: 0,
        fontFace: this.fonts.body, fontSize: sc.footnote, color: this.palette.muted,
        fit: 'none',
      });
    }
    return raw;
  }

  /** Section divider. One per section, numbered, carrying the section assertion. */
  divider({ number, title, subtitle } = {}) {
    const raw = this.pptx.addSlide();
    raw.background = { color: this.palette.primary };
    const g = TOKENS.grid;
    const sc = TOKENS.type.scales.sparse;
    const x = g.margin_left_in;
    if (number !== undefined) {
      raw.addText(String(number).padStart(2, '0'), {
        x, y: 2.72, w: 1.10, h: 0.60, isTextBox: true, margin: 0,
        fontFace: this.fonts.header, fontSize: sc.title, bold: true,
        color: tint(this.palette.accent, 90), valign: 'top', fit: 'none',
      });
    }
    raw.addText(title || '', {
      x: number !== undefined ? x + 1.05 : x, y: 2.72, w: g.content_width_in * 0.72, h: 0.70,
      isTextBox: true, margin: 0, objectName: 'structure:divider-title',
      fontFace: this.fonts.header, fontSize: sc.title, bold: true,
      color: 'FFFFFF', lineSpacingMultiple: 1.10, valign: 'top', fit: 'none',
    });
    if (subtitle) {
      raw.addText(subtitle, {
        x: number !== undefined ? x + 1.05 : x, y: 3.52,
        w: g.content_width_in * 0.60, h: 0.40, isTextBox: true, margin: 0,
        fontFace: this.fonts.body, fontSize: sc.body, color: tint(this.palette.primary, 12),
        lineSpacingMultiple: 1.20, valign: 'top', fit: 'none',
      });
    }
    return raw;
  }

  /**
   * Agenda / tracker page. The active section reads in ink, the rest recede to
   * muted — the reader always knows where they are in the argument.
   */
  tracker(sections, active = -1, { title = 'Contents' } = {}) {
    const s = this.slide({ band: 'sparse', title });
    const rowH = Math.min(0.46, (s.g.content_bottom_in - s.y) / Math.max(1, sections.length));
    sections.forEach((sec, i) => {
      const on = i === active;
      const y = s.y + i * rowH;
      s.s.addText(String(i + 1).padStart(2, '0'), {
        x: s.left, y, w: 0.50, h: rowH, isTextBox: true, margin: 0,
        fontFace: this.fonts.header, fontSize: s.scale.body, bold: on,
        color: on ? this.palette.accent : this.palette.muted, valign: 'top', fit: 'none',
      });
      s.s.addText(typeof sec === 'string' ? sec : sec.title, {
        x: s.left + 0.60, y, w: s.width - 0.60, h: rowH, isTextBox: true, margin: 0,
        fontFace: this.fonts.header, fontSize: on ? s.scale.header : s.scale.body,
        bold: on, color: on ? this.palette.ink : this.palette.muted,
        valign: 'top', fit: 'none',
      });
      s.s.addShape(this.pptx.ShapeType.line, {
        x: s.left, y: y + rowH - 0.06, w: s.width, h: 0,
        objectName: 'structure:tracker-rule',
        line: { color: this.palette.neutral_line, width: 0.5 },
      });
    });
    return s;
  }

  /** References appendix — the single global source index. */
  references(sourceMap, { band = 'dense', title = 'References' } = {}) {
    const s = this.slide({ band, title });
    const entries = Object.keys(sourceMap)
      .map(Number).sort((a, b) => a - b)
      .map((n) => `[${n}] ${sourceMap[n]}`);
    const cols = entries.length > 14 ? 2 : 1;
    const w = (s.width - 0.35) / cols;
    const per = Math.ceil(entries.length / cols);
    for (let c = 0; c < cols; c++) {
      const slice = entries.slice(c * per, (c + 1) * per);
      if (!slice.length) continue;
      s.s.addText(slice.map((t, i, a) => ({
        text: t, options: { breakLine: i < a.length - 1 },
      })), {
        x: s.left + c * (w + 0.35), y: s.y, w, h: s.g.content_bottom_in - s.y,
        isTextBox: true, margin: 0,
        fontFace: this.fonts.body, fontSize: s.scale.footnote, color: this.palette.muted,
        lineSpacingMultiple: 1.2, paraSpaceAfter: 2, valign: 'top', fit: 'none',
      });
    }
    return s;
  }

  /**
   * Layout health per slide. Overrun is a failure; heavy underfill is the
   * signal that the merging rule should have pulled the next section forward.
   */
  audit() {
    return this.slides.map((s, i) => ({
      slide: i + 1,
      chars: s.chars,
      overrun_in: Number(s.overrun.toFixed(2)),
      underfill_pct: Math.round(s.underfill * 100),
      sources: [...s.sources].sort((a, b) => a - b),
    }));
  }

  async save(file) {
    for (const r of this.audit()) {
      if (r.overrun_in > 0.01) {
        console.warn(
          `WARN slide ${r.slide}: content runs ${r.overrun_in}in past the content area. ` +
          `Split it — do not reduce type to fit.`);
      } else if (r.underfill_pct > 28 && r.chars < TOKENS.density.target_min) {
        // Vertical emptiness only means "under-filled" when the character load is
        // also below target. A horizontally composed slide at 800 characters is
        // dense in the sense the spec measures; it just doesn't stack tall.
        console.warn(
          `WARN slide ${r.slide}: ${r.chars} characters and ${r.underfill_pct}% of the ` +
          `content area empty. Apply the merging rule — pull related content forward, ` +
          `or scale the slide up to the sparse band.`);
      }
    }
    await this.pptx.writeFile({ fileName: file });
    return file;
  }
}

/**
 * Build a whole deck from a compose_engine.py plan plus the original spec.
 *
 * This is the seam between the two halves of the skill: the plan says what goes
 * where, the spec carries the content, and this function does nothing but walk
 * them together. Any slide the engine resolved to L20_PAGINATED stops the build
 * — that slide has to be split in the spec and re-planned, because rendering it
 * would mean overflowing or shrinking, and both are forbidden.
 */
async function buildFromPlan(plan, spec, { palette } = {}) {
  const deck = new Deck({ palette: palette || spec.palette || plan.palette });
  const split = plan.slides.filter((p) => p.selected_layout === 'L20_PAGINATED');
  if (split.length) {
    throw new Error(
      `buildFromPlan(): ${split.length} slide(s) resolved to L20_PAGINATED ` +
      `(${split.map((p) => p.id).join(', ')}). Split them at the block index the plan ` +
      `gives and re-run compose_engine.py before building.`);
  }
  for (let i = 0; i < plan.slides.length; i++) {
    const p = plan.slides[i];
    const src = spec.slides[i];
    const s = deck.slide({ band: p.band, eyebrow: src.eyebrow, title: src.title });
    if (src.exhibit) s.exhibit(src.exhibit);
    const blocks = (src.blocks || []).filter(
      (b) => !['footnote', 'source', 'citation', 'pagenum'].includes(b.type));
    await s.composeResolved(p, blocks.map(normaliseBlock));
    if (src.note) s.note(src.note);
    s.source().pageNumber(i + 1);
  }
  return deck;
}

/** Spec block (snake_case, engine-facing) -> component block (renderer-facing). */
function normaliseBlock(b) {
  const out = { ...b };
  if (b.type === 'callout' || b.type === 'kpi') out.type = 'callouts';
  if (b.type === 'card') out.type = 'cards';
  if (b.type === 'text') out.type = 'body';
  if (b.type === 'bullet') out.type = 'bullets';
  if (out.type === 'body' && !out.text) out.text = b.body || '';
  if (out.type === 'header' && !out.text) out.text = b.text || b.body || b.title || '';
  if (out.type === 'bullets' && !out.items) out.items = b.bullets || [];
  if (b.has_tags !== undefined) out.hasTags = b.has_tags;
  if (b.highlight_rows !== undefined) out.highlightRows = b.highlight_rows;
  if (b.col_w !== undefined) out.colW = b.col_w;
  return out;
}

module.exports = {
  Deck, Slide, TOKENS, buildFromPlan, normaliseBlock,
  tint, estimateLines, textHeightIn, formatCitation, gradientPng,
  visibleChars, blockChars,
};

````

## FILE: `scripts/build_from_plan.js`

````javascript
#!/usr/bin/env node
/**
 * build_from_plan.js — stage 3 of the pipeline, as a CLI.
 *
 *     python3 scripts/compose_engine.py spec.json --json -o plan.json
 *     node    scripts/build_from_plan.js spec.json plan.json deck.pptx
 *
 * The renderer is a deterministic painter. It draws the geometry the plan
 * resolved and nothing else: it does not choose layouts, does not reflow, does
 * not paginate, and does not shrink type. If a slide cannot be drawn as
 * planned, this exits non-zero and says which slide and why — the fix belongs
 * in the spec or the plan, never in the paint.
 *
 * Deck furniture (cover, section dividers, tracker, references) comes from the
 * spec's own `cover`, `sections` and `sources` keys, so the report structure is
 * data too, not something a builder has to remember to add.
 */

'use strict';

const fs = require('fs');
const { Deck, normaliseBlock } = require('./pe_components');

async function main() {
  const [specPath, planPath, outPath = 'deck.pptx'] = process.argv.slice(2);
  if (!specPath || !planPath) {
    console.error('usage: node build_from_plan.js <spec.json> <plan.json> [out.pptx]');
    process.exit(2);
  }
  const spec = JSON.parse(fs.readFileSync(specPath, 'utf8'));
  const plan = JSON.parse(fs.readFileSync(planPath, 'utf8'));

  const blocked = plan.slides.filter((p) => p.selected_layout === 'L20_PAGINATED');
  if (blocked.length) {
    for (const p of blocked) {
      console.error(
        `FAIL ${p.id}: the engine resolved this slide to L20_PAGINATED — ` +
        `${(p.pagination || {}).reason || 'no layout fits at minimum readable geometry'}. ` +
        `Split the spec at block ${(p.pagination || {}).at_block} and re-plan.`);
    }
    process.exit(1);
  }

  const deck = new Deck({ palette: spec.palette || plan.palette });
  if (spec.cover) deck.cover(spec.cover);

  // Sections may be given as ["Title", ...] (matched in order of first
  // appearance) or as [{key, title}, ...] (matched to slide.section by key).
  // The keyed form is the safe one: an ordered list silently mislabels a
  // divider the moment a section is added or reordered in the spec.
  const sections = (spec.sections || []).map(
    (x) => (typeof x === 'string' ? { key: null, title: x } : x));
  const keyed = sections.some((x) => x.key);
  let lastSection = null;
  let sectionIndex = -1;
  let page = 0;

  for (let i = 0; i < plan.slides.length; i++) {
    const p = plan.slides[i];
    const src = spec.slides[i];

    // Section dividers are emitted on change of section, numbered deck-wide.
    if (sections.length && src.section !== lastSection) {
      lastSection = src.section;
      sectionIndex += 1;
      const sec = keyed
        ? sections.find((x) => x.key === src.section)
        : sections[sectionIndex];
      if (sec) {
        const number = keyed ? sections.indexOf(sec) + 1 : sectionIndex + 1;
        deck.divider({ number, title: sec.title, subtitle: sec.subtitle });
      } else if (keyed) {
        console.warn(`WARN slide ${src.id}: section "${src.section}" has no entry in ` +
                     `spec.sections — no divider emitted.`);
      }
    }

    const s = deck.slide({ band: p.band, eyebrow: src.eyebrow, title: src.title });
    if (src.exhibit) s.exhibit(src.exhibit);
    const blocks = (src.blocks || [])
      .filter((b) => !['footnote', 'source', 'citation', 'pagenum'].includes(b.type))
      .map(normaliseBlock);
    await s.composeResolved(p, blocks);
    if (src.note) s.note(src.note);
    s.source().pageNumber((page += 1));
    console.log(`  ${p.id}  ${p.selected_layout.padEnd(24)} ` +
                `${p.regions.length} region(s)  ${p.chars} chars  ${p.band}`);
  }

  if (spec.sources) deck.references(spec.sources);
  await deck.save(outPath);
  console.log(`wrote ${outPath}`);
}

main().catch((err) => { console.error(err.message); process.exit(1); });

````

## FILE: `scripts/audit_deck.py`

````python
#!/usr/bin/env python3
"""
audit_deck.py — post-build compliance audit for pe-deck-design.

layout_engine.py checks the plan. This checks the artefact. They are different
questions: a plan can be clean and the emitted XML still carry an autofit
shrink, a stray 6pt run, a title in Title Case, or a decorative stripe.

Read-only. Opens the .pptx as a zip and parses slide XML with ElementTree —
it never writes OOXML back, so it cannot corrupt namespace prefixes.

Run it after every build, and again after every fix:

    python3 scripts/audit_deck.py deck.pptx
    python3 scripts/audit_deck.py deck.pptx --json
    python3 scripts/audit_deck.py deck.pptx --max-chars 1200

Exit code 1 on any FAIL, so it drops straight into a build pipeline.
"""

import argparse
import json
import os
import re
import sys
import zipfile
from collections import defaultdict
from xml.etree import ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
TOKENS_PATH = os.path.join(HERE, "..", "assets", "design-tokens.json")

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
EMU = 914400.0

CITE_RE = re.compile(r"\[\s*\d+(?:\s*[,\u2013-]\s*\d+)*\s*\]")
URL_RE = re.compile(r"(https?://|www\.)", re.I)
# Source strings that belong in the appendix, not inside a component.
SOURCE_LEAK_RE = re.compile(
    r"\b(19|20)\d{2}\b\s*$|"
    r"\b(Gartner|McKinsey|Bain|BCG|Nielsen|IBISWorld|Euromonitor|Statista|PitchBook|"
    r"Capital IQ|Bloomberg|Reuters)\b", re.I)


def load_tokens(path=TOKENS_PATH):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


class Finding:
    __slots__ = ("level", "slide", "rule", "message")

    def __init__(self, level, slide, rule, message):
        self.level, self.slide, self.rule, self.message = level, slide, rule, message

    def as_dict(self):
        return {"level": self.level, "slide": self.slide,
                "rule": self.rule, "message": self.message}


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

def slide_parts(zf):
    names = [n for n in zf.namelist()
             if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)]
    return sorted(names, key=lambda n: int(re.search(r"(\d+)", os.path.basename(n)).group(1)))


def runs(root):
    """Yield (run_element, rPr_element_or_None, text) for every text run."""
    for r in root.iter(A + "r"):
        rpr = r.find(A + "rPr")
        t = r.find(A + "t")
        yield r, rpr, (t.text or "" if t is not None else "")


def all_text(root):
    return "".join((t.text or "") for t in root.iter(A + "t"))


def emu_in(value):
    try:
        return int(value) / EMU
    except (TypeError, ValueError):
        return None


def shape_name(sp):
    """<p:cNvPr name=...> — how the renderer labels a shape's PURPOSE."""
    cnv = sp.find(f".//{P}cNvPr")
    return (cnv.get("name") or "") if cnv is not None else ""


def is_structural(sp):
    """
    Structure is not decoration. A matrix axis, a timeline rail and a tracker
    divider are load-bearing parts of a component; an accent stripe under a
    title is the AI-slide tell the spec bans. The renderer marks the first kind
    `structure:*`, and only that mark exempts a textless bar from the stripe
    rule. Nothing infers the exemption from geometry.
    """
    return shape_name(sp).startswith("structure:")


def visual_bounds(xfrm):
    """
    Bounds as DRAWN, not as stored. A text box rotated 90 or 270 degrees keeps
    its unrotated x/y/cx/cy in the XML while PowerPoint draws it swapped about
    its centre — a vertical axis label reads as off-slide unless the rotation is
    applied here first.
    """
    off, ext = xfrm.find(A + "off"), xfrm.find(A + "ext")
    if off is None or ext is None:
        return None
    x, y = emu_in(off.get("x")), emu_in(off.get("y"))
    w, h = emu_in(ext.get("cx")), emu_in(ext.get("cy"))
    if None in (x, y, w, h):
        return None
    try:
        rot = (int(xfrm.get("rot") or 0) / 60000.0) % 360
    except (TypeError, ValueError):
        rot = 0
    if 45 <= rot < 135 or 225 <= rot < 315:
        cx, cy = x + w / 2, y + h / 2
        w, h = h, w
        x, y = cx - w / 2, cy - h / 2
    return x, y, w, h


def is_divider_slide(root):
    """A section divider: marked by the renderer, exempt from density checks."""
    return any(shape_name(sp).startswith("structure:divider")
               for sp in root.iter(P + "sp"))


def is_references_slide(root):
    """
    The References/Appendix slide is the one place where full source strings and
    7pt metadata type are correct. Exempt it from the checks that exist purely to
    push that content here.
    """
    head = all_text(root)[:160].lower()
    return any(k in head for k in ("references", "source list", "appendix", "bibliography"))


def is_title_case(text):
    """Heuristic: most words capitalised in a multi-word string."""
    words = [w for w in re.findall(r"[A-Za-z][A-Za-z'\-]*", text) if len(w) > 3]
    if len(words) < 4:
        return False
    caps = sum(1 for w in words if w[0].isupper())
    return caps / len(words) > 0.7


# --------------------------------------------------------------------------
# checks
# --------------------------------------------------------------------------

def check_typography(root, sn, tokens, out, exempt=False):
    tt = tokens["type"]
    floor, ceiling = tt["footnote_floor_pt"], tt["max_pt"]
    content_floor = tt["min_pt"]
    allowed_fonts = {tt["fonts"]["header"], tt["fonts"]["body"],
                     tt["fonts"]["header_fallback"]}
    seen_fonts = set()
    sizes = []

    for _, rpr, text in runs(root):
        if rpr is None:
            continue
        sz = rpr.get("sz")
        if sz:
            pt = int(sz) / 100.0
            sizes.append(pt)
            if pt < floor:
                out.append(Finding("FAIL", sn, "type.min",
                                   f"{pt:g}pt run below the {floor}pt absolute floor: "
                                   f"{text[:44]!r}"))
            elif pt < content_floor and len(text.strip()) > 60 and not exempt:
                out.append(Finding("WARN", sn, "type.min",
                                   f"{pt:g}pt used for {len(text.strip())} characters of copy. "
                                   f"{floor}pt is reserved for source/footnote metadata; "
                                   f"content floor is {content_floor}pt."))
            if pt > ceiling:
                out.append(Finding("FAIL", sn, "type.max",
                                   f"{pt:g}pt run exceeds the {ceiling}pt maximum: "
                                   f"{text[:44]!r}"))
        for latin in rpr.iter(A + "latin"):
            face = latin.get("typeface")
            if face:
                seen_fonts.add(face)

    stray = {f for f in seen_fonts if f not in allowed_fonts and not f.startswith("+")}
    if stray:
        out.append(Finding("WARN", sn, "type.family",
                           f"Fonts outside the {tt['fonts']['header']}/{tt['fonts']['body']} "
                           f"pair: {sorted(stray)}"))

    # Distortion: PowerPoint's autofit shrink IS horizontal/vertical font scaling.
    for af in root.iter(A + "normAutofit"):
        fs, ls = af.get("fontScale"), af.get("lnSpcReduction")
        if fs or ls:
            out.append(Finding(
                "FAIL", sn, "type.distortion",
                f"normAutofit is shrinking text (fontScale={fs}, lnSpcReduction={ls}). "
                f"The spec forbids scaling the font to force a fit — resize the box, "
                f"cut copy, or move content to another slide."))

    # Line spacing bands.
    for lnspc in root.iter(A + "lnSpc"):
        pct = lnspc.find(A + "spcPct")
        if pct is None:
            continue
        val = int(pct.get("val", 0)) / 1000.0
        lo = tt["line_spacing_multiple"]["header_min"] * 100
        hi = tt["line_spacing_multiple"]["body_max"] * 100
        if not (lo - 0.5 <= val <= hi + 0.5):
            out.append(Finding("WARN", sn, "type.leading",
                               f"Line spacing {val:g}% sits outside the permitted "
                               f"{lo:g}-{hi:g}% window."))
    return sizes


def check_case(root, sn, tokens, out, exempt=False):
    maxcaps = tokens["type"]["case"]["allcaps_max_chars"]
    for _, rpr, text in runs(root):
        stripped = text.strip()
        if not stripped:
            continue
        letters = [c for c in stripped if c.isalpha()]
        if letters and all(c.isupper() for c in letters) and len(stripped) > maxcaps:
            out.append(Finding("FAIL", sn, "case.allcaps",
                               f"ALL CAPS run of {len(stripped)} chars. Caps are permitted "
                               f"only for labels/tags up to {maxcaps} chars: {stripped[:44]!r}"))
        elif is_title_case(stripped) and len(stripped) > 24:
            if exempt:
                continue
            out.append(Finding("WARN", sn, "case.titlecase",
                               f"Looks like Title Case; the spec requires sentence case: "
                               f"{stripped[:52]!r}"))


def check_geometry(root, sn, tokens, out):
    g, c = tokens["grid"], tokens["canvas"]
    left, right = g["margin_left_in"], c["width_in"] - g["margin_right_in"]
    top, bottom = 0.25, c["height_in"] - 0.18

    for sp in list(root.iter(P + "sp")) + list(root.iter(P + "pic")) + \
              list(root.iter(P + "graphicFrame")):
        xfrm = sp.find(f".//{A}xfrm")
        if xfrm is None:
            continue
        bounds = visual_bounds(xfrm)
        if bounds is None:
            continue
        x, y, w, h = bounds

        if x < left - 0.02 or x + w > right + 0.02:
            out.append(Finding("FAIL", sn, "grid.margin",
                               f"Shape spans {x:.2f}in-{x+w:.2f}in, outside the "
                               f"{left:.2f}-{right:.2f}in content band."))
        if y < top or y + h > bottom + 0.02:
            out.append(Finding("FAIL", sn, "grid.vertical",
                               f"Shape spans {y:.2f}in-{y+h:.2f}in vertically, outside the "
                               f"{top:.2f}-{bottom:.2f}in band — content is running off-slide."))

        # Decorative stripes / accent bars: banned as an AI-slide tell.
        has_text = sp.find(f".//{A}t") is not None
        if is_structural(sp):
            continue
        if not has_text and h < 0.09 and w > 2.5:
            out.append(Finding("WARN", sn, "decoration.stripe",
                               f"Thin horizontal bar ({w:.1f}in x {h:.2f}in) with no text. "
                               f"Accent rules and colour stripes are banned — use whitespace."))
        if not has_text and w < 0.09 and h > 1.5:
            out.append(Finding("WARN", sn, "decoration.stripe",
                               f"Vertical stripe ({w:.2f}in x {h:.1f}in) with no text. "
                               f"Edge stripes are banned."))


def check_citations(root, sn, tokens, out, exempt=False):
    text = all_text(root)
    if URL_RE.search(text):
        out.append(Finding("FAIL", sn, "cite.url",
                           "Raw URL on the slide. Citations are numbered [n]; full sources "
                           "belong in the References appendix."))

    nums = set()
    for m in CITE_RE.finditer(text):
        nums.update(int(n) for n in re.findall(r"\d+", m.group()))
    if len(nums) > tokens["citation"]["appendix_threshold"] and not exempt:
        out.append(Finding("WARN", sn, "cite.density",
                           f"{len(nums)} distinct sources cited. Keep [n] markers on the slide "
                           f"and move the full list to the References appendix."))

    # Citation runs must be muted and unemphasised.
    for _, rpr, rtext in runs(root):
        if not CITE_RE.fullmatch(rtext.strip() or "x"):
            continue
        if rpr is not None and rpr.get("b") == "1":
            out.append(Finding("FAIL", sn, "cite.weight",
                               f"Bold citation {rtext.strip()!r}. Citations stay visually "
                               f"subordinate: regular weight, muted colour."))

    for _, _, rtext in runs(root):
        s = rtext.strip()
        if len(s) > 20 and SOURCE_LEAK_RE.search(s) and not CITE_RE.search(s):
            out.append(Finding("INFO", sn, "cite.leak",
                               f"Possible full source name inside a component: {s[:52]!r}. "
                               f"Use [n] here and the full entry in References."))
            break
    return nums


def check_density(root, sn, tokens, out):
    text = all_text(root)
    chars = len(CITE_RE.sub("", text).strip())
    d = tokens["density"]
    if chars > d["hard_max"]:
        out.append(Finding("FAIL", sn, "density.hard",
                           f"{chars} characters exceeds the {d['hard_max']} hard maximum. "
                           f"Recompose or split at a logical content boundary."))
    elif chars > d["soft_max"]:
        out.append(Finding("WARN", sn, "density.soft",
                           f"{chars} characters is past the {d['soft_max']} soft maximum. "
                           f"Reflow, consolidate, shorten, deprioritise — in that order."))
    elif chars < 200 and chars > 0:
        out.append(Finding("INFO", sn, "density.sparse",
                           f"Only {chars} characters. Scale typography up, or pull related "
                           f"content forward so the slide reads as complete."))
    return chars


def check_tables(root, sn, tokens, out):
    for tbl in root.iter(A + "tbl"):
        rows = list(tbl.iter(A + "tr"))
        if not rows:
            continue

        # Zebra detection: alternating body-row fills.
        fills = []
        for tr in rows[1:]:
            colors = set()
            for tc in tr.iter(A + "tc"):
                tcpr = tc.find(A + "tcPr")
                if tcpr is not None:
                    for sf in tcpr.iter(A + "srgbClr"):
                        colors.add(sf.get("val"))
            fills.append(tuple(sorted(colors)))
        zebra = (len(fills) >= 4 and
                 len({f for f in fills[0::2]}) == 1 and
                 len({f for f in fills[1::2]}) == 1 and
                 set(fills[0::2]) != set(fills[1::2]))

        # Tag/pill detection: short, emphasised, repeated first-column-ish labels.
        tagish = 0
        for tr in rows[1:]:
            cells = list(tr.iter(A + "tc"))
            for tc in cells[1:2]:
                txt = "".join((t.text or "") for t in tc.iter(A + "t")).strip()
                if 0 < len(txt) <= 12 and " " not in txt:
                    tagish += 1
        has_tags = tagish >= max(2, len(rows) // 2)

        if zebra and has_tags:
            out.append(Finding(
                "FAIL", sn, "table.zebra",
                f"Zebra striping on a table whose rows carry short labels/tags "
                f"({tagish} detected). The spec bans this pairing — keep the background "
                f"uniform and let the tags create the differentiation."))

        # Wrap pressure.
        for ri, tr in enumerate(rows[1:], start=1):
            for tc in tr.iter(A + "tc"):
                txt = "".join((t.text or "") for t in tc.iter(A + "t"))
                if len(txt) > 260:
                    out.append(Finding(
                        "WARN", sn, "table.wrap",
                        f"Row {ri} holds a {len(txt)}-character cell — it will exceed the "
                        f"2-line ceiling. Restructure the table rather than shrinking type."))
                    break

        # Heavy gridlines.
        heavy = 0
        for ln in tbl.iter(A + "lnL"):
            if ln.find(A + "noFill") is None:
                heavy += 1
        for ln in tbl.iter(A + "lnR"):
            if ln.find(A + "noFill") is None:
                heavy += 1
        if heavy > len(rows):
            out.append(Finding("WARN", sn, "table.borders",
                               f"{heavy} vertical cell borders. Prefer subtle horizontal "
                               f"dividers; avoid boxing every cell."))


# --------------------------------------------------------------------------
# driver
# --------------------------------------------------------------------------

def audit(pptx_path, tokens):
    out = []
    stats = {}
    with zipfile.ZipFile(pptx_path) as zf:
        parts = slide_parts(zf)
        if not parts:
            out.append(Finding("FAIL", 0, "package", "No slides found in the package."))
            return out, stats
        for part in parts:
            sn = int(re.search(r"(\d+)", os.path.basename(part)).group(1))
            root = ET.fromstring(zf.read(part))
            exempt = is_references_slide(root)
            divider = is_divider_slide(root)
            sizes = check_typography(root, sn, tokens, out, exempt)
            check_case(root, sn, tokens, out, exempt)
            check_geometry(root, sn, tokens, out)
            nums = check_citations(root, sn, tokens, out, exempt)
            # Covers, dividers and trackers are navigation, not content: the
            # character budget does not apply to them and never did.
            chars = check_density(root, sn, tokens, out) if not (divider or exempt) \
                else len(all_text(root))
            check_tables(root, sn, tokens, out)
            stats[sn] = {
                "references_slide": exempt,
                "divider_slide": divider,
                "chars": chars,
                "sources": sorted(nums),
                "min_pt": min(sizes) if sizes else None,
                "max_pt": max(sizes) if sizes else None,
            }
    return out, stats


def render(findings, stats, pptx_path):
    by_slide = defaultdict(list)
    for f in findings:
        by_slide[f.slide].append(f)

    counts = defaultdict(int)
    for f in findings:
        counts[f.level] += 1

    lines = [f"audit: {os.path.basename(pptx_path)}", "=" * 72]
    for sn in sorted(stats):
        st = stats[sn]
        rng = (f"{st['min_pt']:g}-{st['max_pt']:g}pt"
               if st["min_pt"] is not None else "no text")
        lines.append(f"\nslide {sn}  |  {st['chars']} chars  |  {rng}  |  "
                     f"{len(st['sources'])} sources")
        for f in sorted(by_slide.get(sn, []), key=lambda x: x.level):
            lines.append(f"  [{f.level}] {f.rule}: {f.message}")
        if not by_slide.get(sn):
            lines.append("  clean")

    lines.append("\n" + "-" * 72)
    lines.append(f"FAIL {counts['FAIL']}   WARN {counts['WARN']}   INFO {counts['INFO']}")
    lines.append("verdict: " + ("FAIL" if counts["FAIL"] else
                                "PASS (with warnings)" if counts["WARN"] else "PASS"))
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="pe-deck-design compliance audit")
    ap.add_argument("pptx")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--tokens", default=TOKENS_PATH)
    ap.add_argument("--strict", action="store_true", help="treat WARN as failure")
    args = ap.parse_args()

    tokens = load_tokens(args.tokens)
    findings, stats = audit(args.pptx, tokens)

    if args.json:
        print(json.dumps({"file": args.pptx,
                          "findings": [f.as_dict() for f in findings],
                          "stats": stats}, indent=2))
    else:
        print(render(findings, stats, args.pptx))

    levels = {f.level for f in findings}
    if "FAIL" in levels or (args.strict and "WARN" in levels):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

````

## FILE: `scripts/example_build.js`

````javascript
/**
 * example_build.js — reference implementation and end-to-end test.
 *
 * Builds a four-slide deck using the content from the source specification,
 * exercising every component: callouts, cards, a tagged table, a zebra table,
 * a rail, and the References appendix.
 *
 *     node scripts/example_build.js [out.pptx]
 *
 * Read this before writing a new deck. The shape of the calls is the skill.
 */

'use strict';

const { Deck } = require('./pe_components');

const SOURCES = {
  1: 'Del Real Foods, Company overview and product disclosure, 2016',
  51: 'Management analysis, branded retail whitespace, 2016',
  52: 'Management analysis, institutional bid positioning, 2016',
  53: 'Management analysis, ultra-low-cost channel coverage, 2016',
  55: 'Tucson Foods, company profile, 2016',
  60: 'Tucson Foods, product and shelf-life disclosure, 2016',
  66: 'Padrino Foods, company profile, 2016',
  69: 'Padrino Foods, product range disclosure, 2016',
  70: 'Texas Tamale Company, company profile, 2016',
  74: 'Texas Tamale Company, distribution disclosure, 2016',
  91: 'Foodservice operator pull-through analysis, 2016',
  93: 'Buyer labour-savings ROI analysis, 2016',
  123: 'Mira Loma labour and line scheduling review, 2016',
  124: 'Cold-chain throughput assessment, 2016',
  184: 'Plant utilisation and ACV analysis, 2016',
  193: 'Broadline distributor coverage review, 2016',
  194: 'Gross sales by channel, 2016E',
  199: 'Foodservice pack format analysis, 2016',
  202: 'Field sales coverage review, 2016',
};

async function main() {
  const out = process.argv[2] || 'pe-example.pptx';
  const deck = new Deck({ palette: 'graphite_navy' });

  /* ---- slide 1: sparse scale — callouts carry the weight ---------- */
  const s1 = deck.slide({
    band: 'sparse',
    eyebrow: 'COMPANY',
    title: 'Del Real Foods is a refrigerated Hispanic heat-and-eat manufacturer '
         + 'with concentrated customer exposure',
  });
  await s1.compose([
    { type: 'body',
      text: 'The company sells branded meal components and full meal solutions through '
          + 'retail, club, grocery, foodservice, institutional and online channels, with '
          + 'revenue recognised when products ship or are delivered.', cite: [1] },
    { type: 'callouts', items: [
      { value: '46.74%', label: 'Value-added meats revenue share', cite: [194] },
      { value: '>60%',   label: 'Top 10 customer concentration',   cite: [1] },
      { value: '500+',   label: 'Mira Loma plant workers',         cite: [184] },
    ] },
    { type: 'header', text: 'Why this matters to the investment case' },
    { type: 'bullets', items: [
      { text: 'Concentration above 60% in the top ten accounts makes customer retention '
            + 'the single largest downside driver in the base case.', cite: [1] },
      { text: 'Value-added meats at 46.74% of revenue anchors mix, so margin defence '
            + 'depends on protein input hedging.', cite: [194] },
      { text: 'A 500-person plant carries the fixed-cost base that the expansion '
            + 'sequencing below is designed to absorb.', cite: [184] },
    ] },
  ]);
  s1.source().pageNumber(1);

  /* ---- slide 2: balanced scale — cards ---------------------------- */
  const s2 = deck.slide({
    band: 'balanced',
    eyebrow: 'STRATEGY',
    title: 'Three priority moves sequence expansion ahead of fixed-cost commitment',
  });
  await s2.compose([
    { type: 'cards', items: [
    { title: 'Win traditional grocery first',
      body: 'Make traditional grocery the lead expansion channel: it is only 20.2% of '
          + '2016E gross sales, sits at about 9% national ACV, and holds the largest '
          + 'branded retail whitespace.',
      cite: [194, 184, 51] },
    { title: 'Scale foodservice on repeatable economics',
      body: 'Grow through broadline distributor reach, foodservice pack formats and field '
          + 'sales into chains and institutions — but only after proving operator '
          + 'pull-through and buyer labour-savings ROI.',
      cite: [193, 199, 202, 91, 93] },
    { title: 'Use plant headroom before adding fixed cost',
      body: 'Push volume through Mira Loma, about 62% utilised across 13 lines in a '
          + '114,000 sq ft plant, before underwriting major capacity spend.',
      cite: [184, 123, 124] },
    ] },
    { type: 'header', text: 'Sequencing test before capital is committed' },
    { type: 'callouts', items: [
      { value: '20.2%', label: 'Traditional grocery share of 2016E gross sales — the gap '
                             + 'the lead channel is meant to close', cite: [194] },
      { value: '62%',   label: 'Mira Loma utilisation, the headroom that must be consumed '
                             + 'before new fixed cost is underwritten', cite: [184] },
    ] },
  ]);
  s2.source().pageNumber(2);

  /* ---- slide 3: tagged table — zebra must stay OFF ---------------- */
  const s3 = deck.slide({
    band: 'dense',
    eyebrow: 'FOOTPRINT',
    title: 'Club-store placement concentrates presence in the West and Southeast',
  });
  await s3.compose([
    { type: 'table',
    headers: ['Region', 'Presence', 'Key markets and strategic role'],
    rows: [
      ['Northwest', 'Major',
       'Portland, Salem, Central Point — club placement extended reach for ready-in-minutes meals.'],
      ['Los Angeles', 'Major',
       'Inglewood, Marina del Rey, Norwalk — club placement opened a prepared-foods outlet.'],
      ['Southeast', 'Major',
       'Atlanta, Charlotte, Myrtle Beach — club placement gave Southeast distribution.'],
      ['N. California', 'Major',
       'San Francisco — club placement reached the regional buying network.'],
      ['San Diego', 'Major',
       'Mission Valley, San Marcos — club placement opened the San Diego regional network.'],
      ['Midwest', 'Moderate',
       'Chicago, Plainfield, Middleton — no 2016 club placement left the region uncovered.'],
      ['Texas', 'Moderate',
       'Frisco, Fort Worth — no 2016 club placement left the region uncovered.'],
    ],
    zebra: false,        // rows carry Major/Moderate tags, so striping is banned
    hasTags: true,
    cite: [1, 184] },
    { type: 'header', text: 'Read-through' },
    { type: 'body',
      text: 'Club placement, not brand pull, explains the Major/Moderate split. The three '
          + 'Moderate regions are uncovered rather than lost, so they price as expansion '
          + 'optionality rather than as competitive displacement risk.', cite: [1] },
  ]);
  s3.source().pageNumber(3);

  /* ---- slide 4: rail ---------------------------------------------- */
  const s4 = deck.slide({
    band: 'balanced',
    eyebrow: 'M&A',
    title: 'Acquiring a frozen adjacency broadens format mix and hedges bid exposure',
  });
  await s4.compose([
    { type: 'body',
      text: 'A frozen-adjacent asset improves the weaker position in price-sensitive '
          + 'institutional bids and ultra-low-cost channels.', cite: [52, 53] },
    { type: 'header', text: 'Screened targets' },
    { type: 'rail', items: [
      { title: 'Padrino Foods',
        body: 'Adjacent frozen and authentic Mexican depth.', cite: [66, 67, 68, 69] },
      { title: 'Texas Tamale Company',
        body: 'Frozen tamale platform with regional appeal.', cite: [70, 71, 72, 73, 74] },
      { title: 'Tucson Foods',
        body: 'Frozen shelf-life and tamale adjacency.', cite: [55, 56, 57, 58, 59, 60] },
    ] },
    { type: 'header', text: 'Diligence gates common to all three' },
    { type: 'bullets', items: [
      { text: 'Confirm frozen capacity is incremental rather than a substitute for '
            + 'refrigerated throughput already running at Mira Loma.', cite: [184] },
      { text: 'Test whether institutional bid losses trace to format or to price, since '
            + 'only the former is fixed by a frozen asset.', cite: [52, 53] },
      { text: 'Size the cold-chain and scheduling burden of running two temperature '
            + 'states before underwriting synergy.', cite: [123, 124] },
    ] },
    { type: 'callouts', items: [
      { value: '3 of 3', label: 'Targets require a frozen-capacity confirmation before '
                              + 'any indicative offer', cite: [184] },
      { value: '2 states', label: 'Temperature states to operate post-close, the main '
                                + 'source of integration risk', cite: [123, 124] },
    ] },
  ]);
  s4.source().pageNumber(4);

  /* ---- references: one global source index ------------------------ */
  deck.references(SOURCES).pageNumber(5);

  await deck.save(out);
  console.log(`built ${out}`);
}

main().catch((e) => { console.error(e); process.exit(1); });

````

## FILE: `references/layout-intelligence.md`

````markdown
# Layout intelligence and composition engine

`DERIVED` throughout. The source specification says *"use any layout/component combination.
No fixed card count, column count, or template structure"* and *"content volume determines
component size, spacing and structure"* — but it numbers no geometry and names no layouts.
This document is that grammar. It contradicts nothing in `references/source-spec.md`; it
makes the spec's implied composition rules operational.

Everything here is implemented in `scripts/compose_engine.py` and its token catalog at
`assets/design-tokens.json → layout`. When this document and the code disagree, the code is
the bug.

---

## 1. Why this layer exists

Component styling answers *how does a card look*. It cannot answer *should these four things
be a row, a grid, or two slides*. Without that layer, a generator defaults to one of two
failure modes:

- **Everything full width, stacked.** Correct-looking top third, dead bottom half, prose
  running 190 characters a line.
- **Everything in a card grid.** Four columns of word ladders because the item count was 4.

Both come from deciding placement per component instead of per slide. The engine exists to
make the slide-level decision first, explicitly, and with reasons.

```
Content understanding
  → semantic hierarchy
    → layout composition selection
      → geometry allocation
        → constraint validation
          → adaptive fallback
            → editable rendering
```

---

## 2. Semantic roles

Every block is classified before any geometry is considered. Role drives dominance,
ordering within a layout, and which layouts are even eligible.

| Role | Meaning |
|---|---|
| `primary` | The slide's content or visual anchor. Exactly one per slide. |
| `secondary` | The main support layer |
| `supporting` | Detail that serves the primary but does not compete |
| `comparison` | A peer of the primary, invited to be read against it |
| `evidence` | Proof for a claim made elsewhere on the slide |
| `annotation` | Short marginal reading of an exhibit |
| `summary` | A stated takeaway or metric set |
| `context` | Scene-setting, lead-in |
| `metadata` | Sources, notes, page furniture. Never occupies a content region. |

**Inference.** Default by type: chart / matrix / table / timeline → `primary`;
callouts → `summary`; cards / rail → `secondary`; body → `context`; bullets → `supporting`;
header → `annotation`; footnote → `metadata`.

**Resolution.** If several blocks infer `primary`, the largest wins the anchor (characters
plus item count), ties break on spec order, and the losers are demoted to `comparison` (same
type — they invite comparison) or `evidence` (different type). An explicit `"role"` in the
spec is never overruled: a stated intent is source fidelity.

**The slide contract.**

```
one dominant message        (the title — always)
one primary anchor          (exactly one)
one secondary support layer (at most)
optional annotation/metadata layer
```

Unrelated components must not receive equal visual weight. The primary holds at least
40% of allocated content area and at least 1.25× the area of the largest non-peer.
Deliberate asymmetry is supported and expected — `dominance` is checked only against
non-peer roles, so a genuine 50/50 comparison of two peers is not a hierarchy failure.

---

## 3. Layout taxonomy

Twenty canonical layouts. Each is a **semantic composition strategy**, not a visual template:
the ID says what relationship between components the geometry expresses.

| ID | Components | Expresses | Default proportions |
|---|---|---|---|
| `L01_SINGLE` | 1 | One dominant exhibit owns the slide | 1.0 |
| `L02_SPLIT_EQUAL` | 2 | Two peers of equal weight | 0.50 / 0.50 |
| `L03_SPLIT_LEFT_DOMINANT` | 2 | Argument first, support second | 0.62 / 0.38 |
| `L04_SPLIT_RIGHT_DOMINANT` | 2 | Setup first, evidence second | 0.38 / 0.62 |
| `L05_THREE_COLUMN` | 3 | Three compact peers | 1/3 each |
| `L06_FOUR_COLUMN` | 4 | Four compact KPIs | 1/4 each |
| `L07_GRID_2X2` | 4 | Four detailed peers needing reading width | 2 rows × 2 cols |
| `L08_GRID_2X3` | 6 | Six short cards | 2 rows × 3 cols |
| `L09_GRID_3X2` | 6 | Six detailed cards | 3 rows × 2 cols |
| `L10_VERTICAL_STACK` | 1–6 | Sequential full-width flow | 1.0 |
| `L11_MAIN_SIDEBAR` | 2 | Exhibit with a persistent so-what rail | 0.70 / 0.30 |
| `L12_MAIN_TWO_SUPPORT` | 3 | One main visual, two short supports | 0.62 / 0.38 split |
| `L13_CHART_COMMENTARY` | 2 | A chart and its reading | 0.60 / 0.40 |
| `L14_TABLE_INSIGHT` | 2 | A table and its takeaway | bands 0.72 / 0.28 |
| `L15_KPI_CHART` | 2 | Metrics and the chart that explains them | bands 0.26 / 0.74 |
| `L16_TIMELINE` | 1–2 | Chronology | full band |
| `L17_MATRIX` | 1–2 | Positioning with annotation | 0.66 / 0.34 |
| `L18_COMPARISON` | 2–4 | N-way comparison on shared dimensions | equal columns |
| `L19_HIERARCHICAL` | 2–5 | Thesis above its evidence | bands 0.30 / 0.70 |
| `L20_PAGINATED` | any | Terminal: split at a sub-topic boundary | — |

Grid IDs are **rows × cols**, always. `L08_GRID_2X3` is 2 rows of 3; `L09_GRID_3X2` is 3
rows of 2. That is the whole difference between six short cards and six detailed ones: 3×2
buys reading width by spending vertical room.

Every catalog entry in `design-tokens.json` carries `use`, `components` (min/max), `accepts`
(component types), `proportions`, `density` suitability, `avoid_when`, `fallbacks` and
`validation`. Read the token file for the authoritative per-layout rules.

---

## 4. Content-to-layout selection

Component count narrows the candidate list. It never selects. Text volume and minimum
readable geometry decide between the candidates that remain.

```
one large chart                  → L01_SINGLE
two equal charts (≤2 series ea.) → L02_SPLIT_EQUAL
chart + commentary ≤420 chars    → L13_CHART_COMMENTARY
chart + commentary >420 chars    → stack (L10) — a side panel cannot hold it
chart + KPI strip (≤4)           → L15_KPI_CHART
three short peers (≤220 ea.)     → L05_THREE_COLUMN
three blocks, two detailed       → L10_VERTICAL_STACK
four compact KPIs (≤120 ea.)     → L06_FOUR_COLUMN
four detailed insights           → L07_GRID_2X2
six short cards (≤110 ea.)       → L08_GRID_2X3
six detailed cards               → L09_GRID_3X2
wide table alone                 → L01_SINGLE
table + takeaway ≤260 chars      → L14_TABLE_INSIGHT
table + longer commentary        → L10_VERTICAL_STACK
main visual + two short supports → L12_MAIN_TWO_SUPPORT
matrix + short annotation        → L17_MATRIX
timeline (+ reading beneath)     → L16_TIMELINE
thesis + supporting evidence     → L19_HIERARCHICAL
nothing valid                    → L20_PAGINATED
```

The thresholds above are the layout-specific hard constraints in §7, not preferences. The
preference ordering between *valid* candidates is the scoring function in §8.

A timeline owns its band: its reading goes underneath, never beside it, or the chronology
loses the width that makes it read as a sequence.

---

## 5. Component compatibility

Can two components share a horizontal band? Scored 0–10; **below 5 is a hard rejection**,
not a preference. This is about reading scale and visual competition, not whether the
geometry happens to fit.

| Pair | Score | Rule |
|---|---|---|
| Chart + short commentary | 10 | The canonical exhibit page |
| Matrix + short annotation | 9 | The intended pairing |
| Table + concise takeaway (≤260) | 9 | Compatible |
| Two simple charts (≤2 series each) | 8 | Compare well side by side |
| Compatible containers (cards, rail, callouts) | 8 | Fine |
| Timeline + short reading | 8 | Fine, but see §4 — beneath, not beside |
| Two detailed container sets | 6 | Allowed; a grid reads better |
| Short text + short text | 6 | Allowed |
| Table + chart, combined >700 chars | 3 | **Rejected** — competing for the same attention |
| Chart + commentary >420 chars | 3 | **Rejected** — stack it |
| Table + takeaway >260 chars | 3 | **Rejected** — that is a body block, not an insight |
| Two multi-series charts | 3 | **Rejected** — stack them |
| Matrix + detailed table | 2 | **Rejected** — two separate exhibits |
| Two long prose blocks (>240 each) | 2 | **Rejected** — stack them |
| Two tables | 1 | **Rejected** — paginate, never split the band |

The test the matrix encodes: are the two components *semantically related*, *similar in
reading scale*, *suited to the space available*, and *not competing for visual dominance*.

---

## 6. Shared geometry

Every coordinate derives from one frame. No component invents its own `x`/`y`.

```
canvas            13.333 × 7.5in
outer margins     0.50 left/right · 0.42 top · 0.40 bottom
eyebrow band      y 0.34, height 0.18
title band        y 1.05, height measured from the title text itself
content frame     x 0.50, w 12.333, y = title bottom + 0.24, bottom 6.95
footer band       note at height − 0.58, source at height − 0.40
region gutter     0.24 (min 0.16, max 0.34)
component gaps    0.20 natural (min 0.12, max 0.46) — inside a region
```

Region gutters are wider than the gaps between stacked components inside a region, because
a vertical seam must read as a structural division, not a paragraph break.

**The frame is computed from measured text**, not assumed: a two-line title pushes the
content frame down, and both the plan and the renderer derive that boundary the same way.

**Parent–child bounds.** Regions are children of the frame; components are children of their
region; card cells and rail items are children of their component. Every child stays inside
its parent — `child_exceeds_parent` is a hard rejection. Internal spacing is inherited from
the parent, never re-invented per child, and a child's alignment derives from its parent's
edges.

**Vertical packing.** After regions are resolved, row bands are packed from the top at the
height their content actually measures, and surplus is handed back to the growable bands
(capped per component type: cards 30%, rail 30%, callouts 55%, table 35%, exhibits take the
room they are given). Whatever remains stays as honest whitespace at the foot and is
reported by the balance audit — never absorbed by inflating a component past what its
content justifies. Without this pass, a proportional band split leaves a hole between a short
table and the insight strip pinned beneath it: the horizontal version of the dead-bottom-half
defect.

**Letterboxing.** Charts and matrices are fitted to a legal aspect inside their region and
centred horizontally. A letterboxed exhibit pinned left reads as a mistake; centred it reads
as a decision.

---

## 7. Minimum viable dimensions and invalidity

### Minimums are derived

```
min_w = min_chars_per_line × (fontPt / 72) × 0.50  +  2 × padding
```

At 10pt body, one character advances 0.0694in, so 32 characters need 2.22in of text plus
padding. The token floor per component type and this computed floor are both applied; the
larger wins.

| Component | Floor w × h (in) | Chars/line floor |
|---|---|---|
| Body | 2.40 × 0.42 | 32 |
| Bullets | 2.60 × 0.46 | 30 |
| Card (short) | 2.20 × 0.78 | 24 |
| Card (detailed) | 2.90 × 1.05 | 24 |
| Callout / KPI | 1.90 × 0.78 | 16 |
| Rail item | 1.60 × 0.70 | 20 |
| Table | 4.20 × 0.90 (column 0.62) | 14 |
| Chart | 3.60 × 2.30 | — |
| Matrix | 4.20 × 3.30 | — |
| Timeline | 5.00 × 1.10 | — |
| Annotation | 1.80 × 0.42 | 20 |

There is also a **ceiling**: ~110 characters a line. Past it the eye loses the line return,
so prose is capped at its measure inside a wide region — the region stays as allocated, the
text column inside it does not exceed its measure. This ceiling is what stops every layout
collapsing to full width under scoring.

### Hard constraints — a layout is rejected, never patched

| Code | Meaning |
|---|---|
| `minimum_width_violation` | A region is narrower than its component's floor |
| `minimum_height_violation` | A region is shorter than its component's floor |
| `measured_overflow` | Real text at the real width exceeds the region |
| `aspect_violation` | A chart or matrix letterboxed to a legal aspect falls below its floor |
| `table_column_unreadable` | Narrowest column below 0.62in |
| `component_incompatible` | Two components sharing a band score below 5 (§5) |
| `child_exceeds_parent` | A region or child escapes its parent bounds |
| `inconsistent_gutters` | Adjacent gutters in a row vary by more than 0.03in |
| `primary_dominance_lost` | The anchor no longer dominates its non-peers |
| `sidebar_component_banned` | A table, chart or matrix in a sidebar |
| `sidebar_overloaded` | Sidebar past 320 characters |
| `column_text_too_long` | 3-column past 220, 4-column past 120 chars |
| `cell_text_too_long` | 2×3 grid cell past 110 chars |
| `commentary_too_long` | Side commentary past 420 chars |
| `insight_too_long` | Table insight strip past 260 chars |
| `kpi_count_violation` | KPI strip past 4 — the DOC callout rule |
| `thesis_too_long` | Hierarchical thesis past 260 chars |
| `shape_mismatch` | The layout needs a component type the slide does not have |

Additionally, and inherited from the base spec rather than re-stated here: text may not
overflow, titles may not overlap body, footers may not overlap content, chart labels may not
become illegible, required data may never be dropped, fonts may never fall below the floor,
and a continuation slide may never carry a single orphaned component.

**The engine must never solve a layout problem by shrinking text.** Font size is not an
input to layout selection at all — it is fixed by the density band before this engine runs.

---

## 8. Candidate generation and scoring

Never select the first layout that fits. Generate all shape-eligible candidates, reject the
invalid, score the survivors, take the best.

```
layout_score =
    1.30 × hierarchy_fit      # does the primary hold its area share
  + 1.50 × readability        # plateau: full marks between the floor and the ceiling
  + 1.30 × semantic_fit       # the canonical pairing for this content
  + 1.00 × compatibility      # worst pair sharing a band
  + 0.80 × balance            # fill ratio inside the target band
  + 0.50 × alignment          # fewer distinct edges is cleaner
  + 1.00 × source_fidelity    # an explicitly requested layout
  − 30.0 × overflow_penalty
  −  1.00 × density_penalty         # from the complexity band, §9
  − 18.0 × tiny_component_penalty   # regions within 12% of their floor
  −  9.00 × competition_penalty     # visual anchors beyond the first
  −  0.90 × whitespace_penalty
  −  5.00 × nesting_penalty
```

Each criterion is 0–10. Scores are comparable **only within one slide** — they rank
candidates, they do not measure absolute quality.

Two subtleties that took a rebuild to get right:

- **Readability is a plateau, not a ramp.** It rises from 6 at exactly the minimum width to
  10 at 1.5× the minimum, then stays flat, and falls once the line exceeds the maximum
  measure. A ramp rewards width without limit, and every layout collapses into a full-width
  stack.
- **On a sparse slide, balance and whitespace are neutralised.** A sparse slide is a density
  problem with a density answer (scale up, or pull the next section forward). Letting
  emptiness drive layout choice makes thin slides pick wide, tall regions for the wrong
  reason.
- **Competition means anchors, not peers.** A second chart, table or matrix competes to be
  *the* exhibit. A row of four peer KPIs is a set, not a set of rivals.

---

## 9. Multidimensional density

The character budget from `references/density-and-pagination.md` is retained unchanged and
is still authoritative for typography. It is **not** sufficient for composition: 700
characters as one chart is a light slide; 700 characters as six cards, a nine-row table and
two charts is an overloaded one.

Complexity points, evaluated alongside the character budget:

```
3.0 per component            1.0 per table row        1.5 per chart series
4.0 per text-heavy component 1.5 per table column     0.5 per chart category
2.0 per region column        4.0 per nesting level    0.4 per distinct source
```

| Points | Band |
|---|---|
| ≤ 22 | light |
| ≤ 40 | workable |
| ≤ 56 | heavy |
| > 56 | overload |

**Vertical occupancy and content complexity are different axes and both are evaluated.**
A component is *text-heavy* when its longest single readable unit reaches 140 characters —
the longest unit, not the total, because that is what actually needs line width.

---

## 10. Adaptive fallback

Every layout declares a fallback chain in the token catalog. Examples:

```
L06_FOUR_COLUMN     → L07_GRID_2X2 → L05_THREE_COLUMN → L10_VERTICAL_STACK
L05_THREE_COLUMN    → L12_MAIN_TWO_SUPPORT → L07_GRID_2X2 → L10_VERTICAL_STACK
L08_GRID_2X3        → L09_GRID_3X2 → L10_VERTICAL_STACK → L20_PAGINATED
L13_CHART_COMMENTARY → L11_MAIN_SIDEBAR → L10_VERTICAL_STACK → L20_PAGINATED
L02_SPLIT_EQUAL     → L03_SPLIT_LEFT_DOMINANT → L10_VERTICAL_STACK → L20_PAGINATED
```

Escalation order, applied in sequence and never skipped:

```
1. reflow within the layout (re-wrap, redistribute, tighten gutters to the minimum)
2. CHANGE LAYOUT — walk the fallback chain
3. consolidate related components into one region
4. reduce non-essential spacing
5. shorten redundant copy
6. deprioritise optional content (move annotation/context off the slide)
7. split semantically at a sub-topic boundary
```

Shrinking type appears at no position in this list.

**Pagination is terminal.** When it is reached, the engine returns a split point: the first
`header` block (a header starts a sub-topic), else the block boundary nearest the midpoint
of the character load. A single component that cannot fit is split within itself — table
rows, rail items — never by reducing type. The continuation slide carries a complete
sub-topic and its own assertion title.

---

## 11. Text measurement feedback loop

Layout is not decided from character counts. The loop is:

```
estimate content dimensions
  → allocate geometry
    → measure text wrapping at the allocated width
      → recalculate actual height
        → validate fit
          → reflow, or change layout
```

Measurement accounts for font family, size, weight, line-spacing multiple, paragraph
spacing, internal padding, bullet hanging indent, citation suffixes, table cell padding and
the maximum measure.

`compose_engine.estimate_lines()` and `pe_components.estimateLines()` are **deliberate
mirrors** — same advance constants (0.50em body, 0.60em header), same floor of 6 characters
a line, same per-paragraph ceiling. If they drift, the plan and the paint disagree and the
renderer wins silently. The selftest asserts the formula.

Header advance is over-estimated on purpose: Manrope has no metric-compatible substitute in
the QA renderer and sets wider than Arial at the same size. Under-estimating header lines is
exactly what makes a card title collide with its own body.

---

## 12. Balance validation

After geometry, before rendering:

| Check | Target |
|---|---|
| Fill (occupied ÷ frame area) | 0.62 – 0.94 |
| Peer left/right imbalance | ≤ 0.28 |
| Deadzone (empty lower band) | ≤ 0.22 |
| Peer area variance | ≤ 0.35 |

Fill credits the growth the renderer will actually hand back, so a table is not judged as if
it stays at natural height.

Side imbalance is only a defect between **peer** regions. An intentional 70/30 main-sidebar
is not imbalance, and the check ignores it. **Do not force symmetry when semantic importance
is unequal** — the goal is balanced composition, not mathematically equal regions.

---

## 13. Renderer responsibilities

| Layout engine decides | Renderer decides |
|---|---|
| Layout type | Which native PPTX object to use |
| Region positions and sizes | Text box, table, chart, shape rendering |
| Reflow, packing, fallback | Applying design tokens |
| Pagination | Gradient generation |
| Hierarchy and constraints | Nothing else |

The renderer is a deterministic painter. Under `composeResolved()` it measures each block at
the width the engine allocated, grants the capped growth the two-phase distributor would
have given it, and draws. If content does not fit its region it **warns and reports** — it
never silently re-lays-out, and it refuses outright to draw a slide the engine resolved to
`L20_PAGINATED`.

---

## 14. Diagnostics

Every plan carries its reasoning. This is the debugging surface for backend layout issues:

```json
{
  "selected_layout": "L07_GRID_2X2",
  "score": 53.83,
  "criteria": {"readability": 10.0, "hierarchy_fit": 6.25, "semantic_fit": 10,
               "compatibility": 8.0, "balance": 8.0, "alignment": 8.8,
               "source_fidelity": 6.0},
  "penalties": {"overflow": 0.0, "density": 1.5, "tiny_component": 0.0,
                "competition": 2.25, "whitespace": 1.8, "nesting": 0.0},
  "reason": ["4 component(s) detected: cards(primary)... — detailed content",
             "Four detailed peers that each need reading width",
             "weakest criterion hierarchy_fit at 6.25/10; fill 45%",
             "L06_FOUR_COLUMN rejected: column_text_too_long",
             "All components satisfy minimum dimensions."],
  "rejected_layouts": [{"layout": "L06_FOUR_COLUMN", "reason": "column_text_too_long",
                        "detail": "longest item carries 180 chars (max 120)"}],
  "runners_up": [{"layout": "L10_VERTICAL_STACK", "score": 41.20}],
  "fallback_chain": []
}
```

`python3 scripts/compose_engine.py spec.json` prints the same content as a human report,
including per-region geometry and the balance findings.

---

## 15. Specialised composition rules

**Charts.** Hold the aspect band (0.9–2.6, ideal 1.55) and letterbox rather than stretch.
Preserve visual dominance — a chart that shares a band with a detailed table has lost it.
Never two complex charts side by side. A single series is one colour; the accent marks the
one point the title is about. Avoid narrow charts with large legends: below 0.9 aspect the
legend becomes the subject.

**Tables.** Prefer full width. Never in a sidebar. Never beside another table. Split
logically — at a grouping boundary, carrying the header row forward — and preserve every
required column. Use `L14_TABLE_INSIGHT` when there is a genuine takeaway, `L01_SINGLE`
when the table speaks for itself.

**Cards.** Do not force equal widths when content lengths differ materially; equal heights
within a row only. Columns are for compact cards; detailed cards take a 2×2 or a stack. Past
six, the component is wrong, not the layout.

**Timelines.** Horizontal for ≤6 events with labels ≤90 characters; vertical once entries
carry prose; paginate past 8. Chronological order is preserved absolutely.

**Matrices.** Axis readability first; keep the matrix primary; annotations to the side, never
dense paragraphs inside quadrants. Point labels flip side rather than escape the frame.

**Comparisons.** Identical dimension set across every option, in identical order. Columns
only while cells stay short; three-way comparison with long cells becomes a table.

---

## 16. Worked selection examples

```
chart + 3 short bullets (157 chars)
  → candidates: L01(no), L02, L03, L04, L10, L11, L13
  → L02 rejected: minimum_width_violation (chart floor 3.60in)
  → L13 selected: semantic_fit 10, readability 10, fill 62%

table(5 rows) + 1 callout (552 chars)
  → L14 selected; table band packed to measured height, insight strip beneath
  → L02 rejected: component_incompatible (table beside callout at this width)

4 cards, 180 chars each (555 chars)
  → L06 rejected: column_text_too_long (180 > 120)
  → L07 selected: cells 6.05in wide, both rows packed from the top

table(26 rows), 2,400 chars
  → every layout rejected: measured_overflow
  → L20_PAGINATED, split_component: "split the component itself (table rows),
     never the type size"
```

---

## 17. Integration with the existing rules

| Existing rule | How composition interacts |
|---|---|
| Character budget and bands | Unchanged, and still sets the type scale before this engine runs |
| Component count rules (7+ cards etc.) | Unchanged; the engine never proposes a layout that would need more |
| Zebra vs tags | Unchanged; enforced at render and at audit |
| Citations as metadata | Unchanged; excluded from every density calculation, and never allowed to change a region |
| Escalation order | Extended by exactly one step: *change layout*, inserted after reflow |
| Merge rule (`Fit + Related + Readable`) | Unchanged, in `layout_engine.py`; composition runs per slide after it |
| Two-phase measure/distribute | Retained and generalised to two axes |
| Source fidelity | An explicit `layout` or `role` in the spec scores 10 on source fidelity and is never overruled |

````

## FILE: `references/report-deck-patterns.md`

````markdown
# Report-deck patterns

`DERIVED`. The source specification defines a design system but not a document structure. A
diligence pack, market study or IC memo is read, not presented — often printed, often
circulated without its author — and that changes what the deck has to carry. This file
records the conventions of the consulting report register and maps them onto the components
this skill provides.

These are conventions of a genre, not any firm's proprietary assets. Where firms differ, the
difference is noted rather than averaged away.

---

## 1. The two registers

Both are "consulting decks". They are not the same document.

| | Strategy-house register (MBB: McKinsey, BCG, Bain) | Audit-house register (Big Four: KPMG, Deloitte, EY, PwC) |
|---|---|---|
| Unit of argument | One slide, one assertion, one exhibit | One slide, one topic, often several exhibits |
| Density | Lower; whitespace carries emphasis | Higher; tables carry the work |
| Title | Full-sentence action title stating the finding | Often descriptive, with findings in a takeaway box |
| Furniture | Light: page number, source line | Heavier: header rule with engagement name, section tabs, basis-of-preparation and limitations pages |
| Exhibits | Numbered, one per page, "Exhibit 3 \| ..." | Numbered, several per page, cross-referenced to a data book |
| Appendix | Sources and supporting analysis | Sources, limitations, scope, and the full data book |
| Typical layout | `L13`, `L15`, `L17`, `L19` | `L14`, `L10`, `L18`, `L09` |

This skill defaults to the strategy-house register — assertion titles, one exhibit, restrained
furniture — because it is the harder discipline and degrades gracefully into the other. Move
toward the audit register by raising density (more `L14` and `L18`), adding the note line
routinely, and adding a limitations page.

What both share, and what this skill enforces: sentence case, small type, numbered citations
with a single global index, no decorative imagery, one accent colour, and every number
sourced.

---

## 2. Deck structure

```
Cover                       deck.cover({...})
Contents / tracker          deck.tracker(sections, active)
Executive summary           L19_HIERARCHICAL — thesis above its evidence
[ Section divider           deck.divider({number, title})
  Content slides            one assertion each
  ...                     ] × sections
Appendix divider
Supporting exhibits
References                  deck.references(SOURCE_MAP)
```

Rules that matter more than they look:

- **The tracker repeats at each divider in a long pack** (past ~25 pages), with the active
  section in ink and the rest muted. The reader should never have to count backwards to
  work out where they are in the argument.
- **The executive summary is written last and states conclusions, not contents.** "Club
  concentration is the largest downside driver", not "This section covers customers".
- **Every section divider carries the section's assertion**, not just its name, when the
  section has one.
- **The appendix is not a dumping ground.** Anything a reader needs to accept the argument
  belongs in the body; the appendix holds what they need to *verify* it.

---

## 3. The action title

The single highest-leverage convention in the genre, and the one this skill enforces
editorially rather than mechanically.

```
Label title   "Regional footprint"                              ← wrong register
Action title  "Club-store placement concentrates presence in
               the West and Southeast"                          ← right
```

Tests a title must pass:

- It is a **complete sentence** with a verb, in sentence case, 14–16pt.
- It states the **finding**, not the subject. If it could sit above any chart of the same
  data, it is a label.
- It is **falsifiable**. "Growth was strong" is not; "Volume growth outpaced price in every
  format since 2014" is.
- Read end to end, the titles alone are the **storyline**. A reader flipping only the titles
  should get the argument. This is the standard test before a pack goes out.
- It does not repeat the exhibit's own title. The exhibit says *what is plotted*; the slide
  title says *what it means*.

The exhibit should point at its own assertion: if the title is about club placement, the
club bar is the accent-coloured one (`highlight`). An exhibit that does not mark what its
title claims is decoration.

---

## 4. Exhibit furniture

Order, bottom of every exhibit page:

```
Note:   scope qualifiers, definitions, exclusions, basis of estimate
Source: [n] markers only — never full source names on the page
                                                    page number, outer corner
```

- **Numbering is deck-wide and permanent.** Once a pack numbers exhibits, every exhibit gets
  a number, and a cross-reference in the text ("see Exhibit 7") must resolve. Do not
  renumber between drafts without re-checking the references.
- **The note line is where scope lives.** "Gross sales before trade spend", "excludes
  intercompany", "management estimates" — this material bloats a component body or a table
  cell and belongs on the note line instead.
- **One source line per page** by default. A second in-visual source line is justified only
  when a page carries two exhibits drawing on different sources.
- **"Not to scale" and axis breaks must be declared.** A broken axis without a note is
  misleading, and in a diligence pack that is a liability, not a style choice.
- **Units belong in the exhibit title**, not repeated in every label: "Net revenue by year
  ($m)".

---

## 5. The takeaway

Two forms, both supported:

- **Title-as-takeaway** (strategy register): the assertion is the title, and the page carries
  no separate summary box. This is the default here.
- **Takeaway box** (audit register): a descriptive title, with the finding in a callout —
  `L14_TABLE_INSIGHT` puts it beneath a table, `L11_MAIN_SIDEBAR` puts it beside an exhibit.

Do not use both. A page with an assertion title *and* a takeaway box says the same thing
twice and dilutes both.

---

## 6. Print discipline

Report decks get printed, and print is unforgiving:

- **Type below 8pt disappears on paper.** This is the real reason for the 8pt content floor
  and the 7pt metadata-only rule.
- **Colour is not load-bearing.** Anything distinguished by colour must also be
  distinguished by label, position or order — greyscale printing is common, and so is
  colour-blindness. The positive/negative palette entries are for emphasis, never for the
  sole encoding of a distinction.
- **Gradients must stay subordinate.** The 10%→2% tint range exists so text over a rail or
  callout keeps its contrast in print.
- **Margins are consistent across every page** so a stapled or bound pack does not shift.
- **Landscape 13.333 × 7.5in** prints cleanly to A4/Letter landscape with margin to spare.

---

## 7. Confidentiality and limitations

Not decoration on a diligence pack — distribution control:

- **Cover carries the confidentiality line.** "Strictly private and confidential" is the
  default in `deck.cover()`; replace it with the engagement's actual wording.
- **A limitations / basis-of-preparation page** belongs in the audit register: scope of
  work, information relied upon, procedures not performed, and reliance restrictions. If the
  engagement letter specifies wording, that wording is used verbatim — this is one of the
  few places where the text is not the author's to edit.
- **Draft status is marked on every page**, not only the cover, while a pack is in draft.
- **Management estimates are labelled as such** wherever they appear, on the note line.

---

## 8. What this register does not do

Recognisable tells of the wrong register, all of which `audit_deck.py` or the component law
will catch:

- Accent stripes under titles, edge bars, decorative rules
- Stock photography, icon sets, illustrative imagery on analysis pages
- Title Case headings
- Drop shadows, bevels, 3-D charts, gradient-filled chart series
- A palette of six colours where one series exists
- Full URLs or publication names inside a card, table or chart
- Autofit shrink to force content onto a page
- Six weak components where two strong ones would carry the argument

````

## FILE: `references/typography.md`

````markdown
# Typography

Source: the specification. `DOC` = stated verbatim, `DERIVED` = computed from a DOC rule.

## Families `DOC`

| Role | Font |
|---|---|
| Headers (slide title, section header, card/rail/table titles, callout values, eyebrow) | **Manrope** |
| Body (paragraphs, bullets, table cells, labels, footnotes, citations) | **Arial** |

**QA caveat.** Manrope has no metric-compatible substitute in the local LibreOffice
renderer. Header fit in the PDF/image preview is **approximate**: size header containers
with roughly 10% slack and do not trust a borderline header overflow read from the preview.
Arial renders true-to-width, so body overflow reads are trustworthy.

`estimateLines()` in `pe_components.js` uses a 0.60em average advance for headers versus
0.50em for body. That over-estimate is deliberate — under-estimating header lines is
exactly what makes a card title collide with its own body.

If Manrope is unavailable in the target environment, `Calibri` is the declared fallback.
Never fall back to Aptos: it has no reliable substitute here and is missing from older
Office installs.

## Role ranges `DOC`

| Element | Size | Weight | Use |
|---|---|---|---|
| Slide title | 14–16 pt | Bold | The main message of the slide |
| Section / sub-header | 12–14 pt | Medium | Major content blocks |
| Body text & key insight | 9–10 pt | Regular | Explanatory content |
| Table title | 12–14 pt | Semibold | Clear title above the table |
| Table column header | 9–10 pt | Semibold | Subtle background or divider |
| Table body / cell | 8–9 pt | Regular | Dense tables |
| Table key metric / total | 9–10 pt | Semibold | Subtle emphasis |
| Chart labels | 8–9 pt | Regular | Axes, legends, data labels |
| Source / footnote | 7–8 pt | Regular | Sources, methodology, notes |
| Citation | 8–9 pt | Regular | Inline `[n]` markers |

## Scale resolution `DERIVED from DOC`

The spec states both a per-element range and a slide-level density rule:

> Sparse slide → 14–16 pt · Balanced slide → 10–14 pt · Dense slide → 8–10 pt
> Minimum 8 pt, maximum 16 pt.
> The relative hierarchy between title, header, body, chart labels and footnotes should
> remain consistent; only the overall scale changes.

Resolution: the per-element table defines each role's range; the density rule decides where
within every range the slide sits. Roles move together and never cross.

| Role | dense | balanced | sparse |
|---|---|---|---|
| title | 14 | 15 | 16 |
| header | 12 | 13 | 14 |
| body / key insight | 9 | 10 | 10 |
| table title | 12 | 13 | 14 |
| table header / metric | 9 | 10 | 10 |
| table body | 8 | 9 | 9 |
| chart label | 8 | 9 | 9 |
| citation | 8 | 9 | 9 |
| footnote | 7 | 8 | 8 |

**Core principle `DOC`:** choose the largest overall typography scale that fits the slide
comfortably without creating overflow or excessive whitespace.

### The 8pt / 7pt reconciliation

The spec sets a global 8 pt minimum *and* separately sets source/footnote at 7–8 pt.
Resolution, recorded in `design-tokens.json` as `footnote_floor_note`:

- **8 pt is the floor for content.**
- **7 pt is permitted only for source, footnote and citation metadata.**

`audit_deck.py` enforces exactly this: 7 pt runs are allowed, but a 7 pt run carrying more
than 60 characters of copy is flagged as content masquerading as metadata. The References
slide is exempt.

## Formatting rules `DOC`

**Sentence case.** Slide titles and headers use sentence case. ALL CAPS is permitted only
for short labels, tags or metadata (≤18 characters — `DERIVED` bound). Title Case for every
word is banned. `audit_deck.py` flags long caps runs as FAIL and probable Title Case as WARN.

**Keep lines readable.** Avoid long, stretched lines. If a line runs too long, adjust the
text area or the layout — not the font size.

**Never distort the font.** No horizontal or vertical stretching, compressing or scaling.
To make text fit, change font size (within range), text box size, spacing, or layout.

PowerPoint's autofit shrink is this distortion applied automatically, so
`<a:normAutofit fontScale="…">` is a build failure. Every `addText` in the component
library passes `fit: 'none'` to prevent it being written in the first place.

**Line spacing.**

| Role | Multiple |
|---|---|
| Body | 1.10–1.25× |
| Headers | 0.95–1.10× |
| Citations | 1.10–1.20× |

**Paragraph spacing:** 3 pt after. **Section spacing:** 8 pt after. Keep both minimal and
consistent.

## One-line summary `DOC`

> Keep typography readable, proportional and consistent. Use sentence case, control line
> length, never distort fonts, and maintain consistent line spacing across the slide.

````

## FILE: `references/components.md`

````markdown
# Components: cards, rails, callouts

Source: the specification. `DOC` = stated verbatim, `DERIVED` = computed or a geometry
constant the spec implies but does not number.

## The defining difference `DOC`

These three containers are distinguished by border and fill alone. That is the whole
visual system — if a rail looks like a card, the system has failed.

| Component | Border | Fill |
|---|---|---|
| **Card** | 1 pt, neutral | **none** |
| **Rail** | 1 pt | gradient **of the border colour** |
| **Callout** | **none** | gradient **of the primary colour** |

`pe_components.js` hardcodes these. They are not parameters, and no caller can override them.

### Gradients in practice `DERIVED`

pptxgenjs cannot emit an OOXML gradient fill. The component library renders each gradient
as a rounded-rect alpha PNG through `sharp` at 4× placement resolution and places it behind
the shape. This is the only route that survives a round trip into PowerPoint.

Tint stops: 10% → 2% of the base colour, mixed toward white, on a 135° axis. Deliberately
faint — the fill is a container signal, not a highlight. Do not substitute a solid fill:
the gradient is the only thing separating a rail from a card.

Geometry `DERIVED`: corner radius 0.06", card padding 0.16" × 0.12", rail padding
0.16" × 0.12", callout padding 0.18" × 0.14", gaps 0.18" / 0.14" / 0.18".

## Cards `DOC`

| Count | Treatment |
|---|---|
| 1–3 | Larger cards, stronger typography, more internal whitespace |
| 4–6 | Reduce card width and spacing while keeping content readable |
| 7+ | **Do not keep shrinking.** Switch to a more scalable layout — a rail or a grouped structure |

- Card height follows content, but **cards within the same row must share a common height**.
- Short content → increase whitespace. Long content → reduce padding and spacing **before**
  reducing font size.
- **Don't force equal card widths** when content lengths differ significantly.
- Each card contains **one primary data point or message**.

`compose()` throws at 7+. Growth cap for cards is 0.30 `DERIVED`: a card is a content
container, so stretching it past that just moves dead space inside the border. Surplus
beyond the cap flows to the gaps instead.

## Horizontal rail `DOC`

| Count | Treatment |
|---|---|
| 2–4 | Larger item widths, generous spacing |
| 5–6 | Compact spacing, smaller item widths |
| 7+ | **Do not reduce typography below the minimum.** Split the rail or change the component |

- **Item width responds to content length** rather than being rigidly equal. Short items
  should not create excessive empty space just to match a long item.
- Maintain consistent alignment across all items.
- **Preserve order** when the data represents a sequence.
- Keep each item concise — rail items are not paragraphs.
- If the rail becomes too tall or compressed, **restructure before reducing typography**.

Width algorithm `DERIVED`: each item is weighted by character load, then pulled toward the
mean (`0.6 + 0.4 × load/mean`) so nothing collapses to a sliver and nothing hogs the rail.
Items share a height but each item's own content is centred vertically within it, so short
items don't read as clipped.

## Callouts `DOC`

| Count | Treatment |
|---|---|
| 1 | Stronger visual emphasis and more whitespace |
| 2 | Balance by content length; they **don't need identical heights** |
| 3+ | Only when each represents a **distinct insight**; otherwise combine them |

- Short insight → larger type and more whitespace. Long insight → increase available space
  and reduce internal spacing **before** reducing font size.
- Keep the primary message visually dominant.
- **Don't force every callout to the same height** when content differs significantly.
- Avoid callouts becoming containers for large amounts of body text.
- If content exceeds readable capacity, **restructure or move the overflow** rather than
  shrinking below the minimum font size.

Implementation `DERIVED`: a single callout gets value type at `title + 1` (capped at 16pt)
and 1.5× vertical padding. The metric itself is a clean bold run — its citation rides on
the label beneath, so the number never carries bold bracket noise. Content is centred
vertically inside a grown callout.

`compose()` throws at 5+. At 3–4 the layout engine emits a WARN asking you to justify that
each is genuinely distinct.

## The common rule `DOC`

> Content volume determines component size, spacing and structure. Never preserve fixed
> dimensions at the cost of whitespace or readability. When content exceeds the component's
> capacity, restructure or move to the next slide rather than continuously shrinking the
> component.

This rule is what the two-phase layout in `pe_components.js` exists to make mechanical.

````

## FILE: `references/tables.md`

````markdown
# Tables

Source: the specification. `DOC` = stated verbatim, `DERIVED` = computed.

## Element specification `DOC`

| Element | Size | Weight | Alignment / spacing | Style rule |
|---|---|---|---|---|
| Table title | 12–14 pt | Semibold | Left | Clear title above the table |
| Column header | 9–10 pt | Semibold | Match column | Subtle background or divider |
| Body / cell text | 8–9 pt | Regular | Text left; numbers right | Compact and readable |
| Key metric / total | 9–10 pt | Semibold | Match column | Subtle emphasis |
| Source / footnote | 7–8 pt | Regular | Left | Keep below the table |
| Cell padding | — | — | 6–8 pt horizontal, 4–6 pt vertical | Consistent throughout |
| Borders | — | — | — | Prefer subtle horizontal dividers; avoid heavy gridlines |
| Row height | — | — | — | Minimum required for content; avoid excess whitespace |
| Number format | — | — | Right aligned | Keep decimals and units consistent |
| Text wrapping | — | — | — | Prefer 1–2 lines; avoid overly tall cells |

## Zebra striping — the sharpest rule `DOC`

> Avoid zebra striping when rows contain labels, tags, pills or other visual indicators.
> Keep the table background uniform and use the tags/pills to create visual differentiation.
>
> For dense data-only tables without tags, subtle zebra striping can be used if it improves
> row scanning.
>
> Avoid combining zebra stripes + coloured tags + highlighted rows — it creates unnecessary
> visual noise.

Enforced in two places, because a table can be built by hand as well as through the library:

- `pe_components.js` **throws** on `zebra: true` with `hasTags: true`, and on `zebra: true`
  with `highlightRows`.
- `audit_deck.py` detects alternating body-row fills in the emitted XML, detects short
  single-word second-column values as probable tags, and FAILs the combination.

The layout engine also emits an INFO the other way: a data-only table of 8+ rows with no
tags is a case where striping is **permitted** and will aid scanning.

## Column hierarchy and width `DOC`

- Make the **primary / most important column visually dominant**. Avoid giving every column
  equal visual weight.
- **Wider columns for descriptive text.** Narrower for numbers, percentages, dates and short
  labels. Avoid unnecessarily wide empty columns.

`_autoColumnWidths()` `DERIVED` weights each column by the greater of its header length and
its mean cell length, floors every column at 0.85", then normalises to the content width.
The first column is the only bold body column — that is how hierarchy is expressed without
adding colour.

## Wrapping `DOC`

- **Prefer 1 line. Allow a maximum of 2 lines** for normal cells.
- If content consistently exceeds 2 lines, **restructure the table rather than making the
  font smaller**.

`layout_engine.py` FAILs any cell past ~124 characters (≈2 lines at table sizes);
`audit_deck.py` WARNs past 260 characters in the emitted XML.

## Numbers `DOC`

- Right-align numeric values.
- Align decimal places within a column.
- Use consistent units and decimal precision — `12.4%, 8.7%, 5.2%`, not mixed formats.

Detection `DERIVED`: a column is treated as numeric when **every** cell matches a
currency/number/unit pattern. One stray text cell makes the whole column left-aligned,
which is the correct conservative behaviour.

## Emphasis and colour `DOC`

- **Bold only** important values, totals or key rows. Never bold an entire table.
- Use **one** visual treatment for highlighted cells, consistently.
- Keep the table primarily neutral. **One accent colour** for emphasis. Don't colour every
  row or column differently.

## Structure and position `DOC`

- Separate logical groups with spacing or subtle dividers. **Avoid borders around every
  individual cell.**
- Align tables to the slide's main content grid. Maintain consistent left/right margins
  across slides. Avoid tables floating with arbitrary positioning.

The library draws bottom dividers only — left and right cell borders are explicitly
`{ type: 'none' }`, and the header carries a single 1 pt primary-colour rule beneath it.
`audit_deck.py` WARNs if it finds more vertical cell borders than rows.

## Overflow order `DOC`

Fixed escalation, and typography is **last**:

1. Column widths
2. Cell padding
3. Wrapping
4. Overall table size
5. Only then, typography within the allowed range

> Never allow unreadable text just to preserve the table structure.

````

## FILE: `references/citations.md`

````markdown
# Citations

Source: the specification. `DOC` = stated verbatim, `DERIVED` = computed.

> Citations should function as **traceability metadata, not a visual content element**.

That sentence governs everything below.

## Style and placement `DOC`

- Numbered citations `[n]` are the default style across the **entire** presentation.
- Place the citation **immediately after** the claim, metric, statement, chart or data
  point it supports.
- `[3]` for a single source · `[3, 7]` for multiple non-consecutive · `[3-7]` for
  consecutive runs.

Both `layout_engine.format_citation()` and `pe_components.formatCitation()` implement the
same collapse: a run of three or more consecutive numbers becomes a range, two consecutive
numbers stay listed. The two implementations are deliberately mirrored so the plan and the
build never disagree.

## Typography `DOC`

| Property | Value |
|---|---|
| Font | Same family as the presentation |
| Size | 8–9 pt |
| Weight | Regular |
| Colour | Secondary / muted |
| Line height | 1.1–1.2× |
| Case | Sentence case |

**Never** use bold, uppercase styling, coloured badges, filled pills, borders, or separate
citation cards. `audit_deck.py` FAILs a bold citation run.

In the component library, `_runs()` splits any cited text into two runs: the claim at body
size and colour, then the citation one step down in the muted colour. A citation never
inherits the emphasis of the text it follows — which is why a callout's metric carries no
bracket: the citation rides on the label beneath instead.

## What must never appear inside a component `DOC`

Do **not** display full source names, publication titles, URLs or long source text within
cards, callouts, charts, tables or any other content component.

`audit_deck.py` FAILs on any raw URL found on a slide, and emits an INFO when it spots what
looks like a publication name or a bare year inside a component.

## Form by context `DOC`

| Context | Form |
|---|---|
| Key metric | `12.4% CAGR [3]` · `$42B market size [3, 7]` |
| Chart or visualisation | Small source line at the bottom of the visual: `Source [3, 5]` |
| Table | **One table-level citation** when the same sources support the table. Cell-level citations only when individual values come from different sources. |

## Grouping and the appendix `DOC`

- If a component has **more than 3 sources**, use grouped references rather than listing
  source names.
- If a slide contains **more than 6–8 sources**, do not expand the slide footer with full
  source information. Keep numbered citations on the slide and provide the complete list in
  the References / Appendix.

Both thresholds are wired: the layout engine emits INFO past 3 sources on a component and
WARN past 8 on a slide; the auditor repeats the slide-level check against the emitted XML.

## The global index `DOC`

> Maintain a single source index across the entire deck. `[3]` must always refer to the
> same source wherever it appears.

Full source details follow one consistent format:

```
[3] Gartner, Semiconductor Forecast, 2025
[7] McKinsey, Global Semiconductor Outlook, 2025
```

`Deck.references(sourceMap)` renders this as a single appendix slide, sorted numerically,
splitting to two columns past 14 entries. The auditor auto-detects the References slide and
exempts it from the citation-density and 7 pt-metadata checks — it is the one place full
source strings belong.

## Layout independence `DOC`

> Citation space must never change the primary component layout. Do not shrink the main
> content or increase component height just to accommodate longer source text.

Two consequences, both enforced:

1. **Citations are excluded from the character budget.** `visible_chars()` in Python and
   `visibleChars()` in JS strip `[n]` markers before counting. A slide is never pushed into
   a denser band by its own sourcing.
2. **Citations never drive component sizing.** They are measured as part of the text they
   follow, never as a reason to grow a container.

## A pptxgenjs constraint worth knowing `DERIVED`

A bulleted paragraph **cannot** hold two differently-styled runs. Any run without a bullet
option emits its own `<a:pPr>` containing `<a:buNone/>`, which silently kills the bullet for
the entire paragraph; giving every run the bullet option instead splits them into separate
bulleted paragraphs, so the citation lands on its own bulleted line.

Both failure modes were verified against rendered output. Because "bulleted claim + muted
citation" is therefore unreachable through `addText` bullets, `pe_components.js` draws the
bullet marker as its own text box at a fixed 0.20" hanging indent and puts the claim in a
second box with mixed runs. That also gives exact indent control the built-in bullet does
not expose.

````

## FILE: `references/density-and-pagination.md`

````markdown
# Slide density and pagination

Source: the specification. `DOC` = stated verbatim, `DERIVED` = computed.

## The character budget `DOC`

Each slide has a total character budget: the sum of all visible content elements — titles,
paragraphs, bullets, card text, callouts, table text, labels and other readable copy.

**Citations are excluded, because they are metadata.**

| Band | Characters | Action |
|---|---|---|
| Target | 600–900 | Preferred |
| Soft maximum | 1,000 | Optimise if possible |
| Hard maximum | 1,200 | Strong overflow check |
| Beyond | > 1,200 | Recompose / condense / consider next slide |

### The engineering formula `DOC`

```
slide characters =
    title
  + subtitles / context
  + paragraphs
  + bullets
  + card titles
  + card bodies
  + callouts
  + table text
  + chart labels
  + other visible copy

then:
  ≤ 900        → Preferred
  901–1,000    → Optimise if possible
  1,001–1,200  → Strong overflow check
  > 1,200      → Recompose / condense / consider next slide
```

Implemented identically twice: `slide_chars()` in `layout_engine.py` (pre-build, from the
content spec) and `blockChars()` in `pe_components.js` (during build, accumulated on the
slide). `audit_deck.py` recomputes it a third time from the emitted XML, which catches
anything added outside `compose()`.

### Guardrail, not a page-break trigger `DOC`

- Character limits are a **density guardrail**, not an automatic page break.
- When the total exceeds target, **first restructure, condense or prioritise**.
- Create a next slide only when important content still cannot fit clearly.
- **Never shrink typography below the defined minimum** just to stay within the limit.

## Density drives typography `DOC`

The band selects the scale. See `typography.md` for the full table.

| Band | Characters | Scale |
|---|---|---|
| sparse | ≤ 550 `DERIVED` | title 16 / header 14 / body 10 |
| balanced | 551–900 | title 15 / header 13 / body 10 |
| dense | 901–1,200 | title 14 / header 12 / body 9 |
| overflow | > 1,200 | not a scale — a recomposition order |

The 550 boundary is `DERIVED`: the spec names the three bands and sets the 600–900 target,
so the sparse ceiling is placed just below the target floor.

## Dynamic slide merging `DOC`

> Before creating a new slide, check whether the next content can fit on the current slide.
>
> - If related content fits without making the slide crowded → **merge** it into the
>   current slide.
> - If there is not enough space → **create a new slide**.
> - Never reduce text below the minimum font size just to make content fit.
> - Never merge unrelated content only to fill empty space.
> - Reflow and resize components before creating a new slide.

**Decision rule:**

```
Fit + Related + Readable          → Merge
Doesn't fit / Unrelated / Not readable → New slide
```

**Worked example `DOC`:** Slide 1 has 3 cards but space below them. If Slide 2 contains
2 related callouts + pointers that fit comfortably, move them onto Slide 1 instead of
creating Slide 2.

This prevents unnecessary slides, excessive whitespace and under-filled layouts while
keeping the slide readable.

`pagination_plan()` emits this per slide as `keep` / `merge_next` / `split`, with the
reasoning attached. Merging requires a matching `section` field and a combined total within
the 900-character target; a sparse slide whose neighbour belongs to a different section is
explicitly told **not** to merge, and to scale up instead.

## Two different axes `DERIVED`

Vertical emptiness and character load are **not** the same measurement. A slide at 800
characters composed horizontally — three callouts across, a wide table — is dense in the
sense the spec measures, even though it doesn't stack tall.

So `Deck.save()` only warns about underfill when **both** conditions hold: more than 28% of
the content area is empty **and** the character load is below the 600 target. That prevents
the build from nagging about correctly composed horizontal slides while still catching
genuinely thin ones.

## Additional slide rules `DOC`

- **One section = one slide by default.** Do not split unless content genuinely requires it.
- **Use any layout / component combination.** No fixed card count, column count or template
  structure.
- **Optimise before splitting:** reflow → consolidate → shorten → deprioritise → split.
- **Set a minimum readable font size.** Never solve overflow by continuously shrinking
  typography.
- **Control component density.** Avoid too many small components competing for attention.
- **Avoid excessive whitespace.** If meaningful content can naturally fit, don't push it to
  the next slide.
- **Don't force symmetry.** Unequal card sizes or layouts are acceptable when driven by
  content importance.
- **Split at logical boundaries.** If a second slide is needed, move a meaningful
  sub-topic — not leftover content.
- **Keep citations out of the content budget.** Use `[n]` citations as lightweight metadata.
- **Prioritise information, not component count.** A slide with 2 important components can
  be better than one with 6 weak ones.
- **Every slide must feel complete.** Avoid continuation slides containing only one small
  card, bullet or callout.

## The engine rule in one line `DOC`

> Fit one complete section within a shared slide content budget, using an adaptive layout;
> optimise composition before pagination, and move to the next slide only when important
> content cannot remain readable and meaningful on the current slide.

````

## FILE: `references/source-spec.md`

````markdown
# Source specification — preserved in full

This file preserves the original specification as supplied, in its own order, including the
worked examples and sample tables. It exists so that nothing is lost in the translation into
tokens and code, and so any rule in this skill can be traced back to its origin.

**If this file and the rest of the skill ever disagree, this file is correct** and the
skill has a bug. Every `DOC` value in `assets/design-tokens.json` comes from here.

Editorial note: the only changes are formatting (markdown structure, tables reconstructed
from the flattened export) and the removal of duplicated fragments from the export process.
No rule, number, threshold or example has been altered, dropped or added.

---

## 1. Font style and rules

**Header — Manrope. Body — Arial.**

### Font rules

| Element | Font size | Weight | Recommended use |
|---|---|---|---|
| Slide title | 14–16 pt | Bold | Main message of the slide |
| Section / sub-header | 12–14 pt | Medium | Major content blocks |
| Body text & key insight | 9–10 pt | Regular | Explanatory content |
| Table text | 8–9 pt | Regular | Dense tables |
| Chart labels | 8–9 pt | Regular | Axes, legends, data labels |
| Source / footnote | 7–8 pt | Regular | Sources, methodology, notes |

### Font formatting rules

**Use sentence case**
- Use sentence case for slide titles and headers.
- Use ALL CAPS only for short labels, tags, or metadata.
- Avoid Title Case for every word.

**Keep text lines readable**
- Avoid long, stretched lines of text.
- If a line becomes too long, adjust the text area or layout rather than shrinking the font.

**Never distort the font**
- Do not stretch, compress, or scale the font horizontally or vertically.
- To make text fit, adjust font size, text box size, spacing, or layout.

**Maintain consistent line spacing**
- Body: 1.1–1.25× the font size
- Headers: 0.95–1.1× the font size
- Keep paragraph spacing minimal and consistent. Paragraph spacing: 3 pt after.
  Section spacing: 8 pt after.

**Even simpler backend rule**

> Keep typography readable, proportional, and consistent. Use sentence case, control line
> length, never distort fonts, and maintain consistent line spacing across the slide.

### Backend logic for font sizing

> Determine font size at the overall slide level based on content density and available
> whitespace. Use a single proportional typography scale across the slide: increase the
> scale for sparse slides, keep it moderate for balanced slides, and reduce it for dense
> slides. Maintain 8 pt as the minimum and 16 pt as the maximum.

**Simple rule**

```
Sparse slide   → 14–16 pt
Balanced slide → 10–14 pt
Dense slide    → 8–10 pt
```

The relative hierarchy between title, header, body, chart labels, and footnotes should
remain consistent; only the overall scale changes.

**Core principle**

> Choose the largest overall typography scale that fits the slide comfortably without
> creating overflow or excessive whitespace.

---

## 2. Table rules and representation

### Table representation 1 — no zebra

> no zebra > has label with any one of column or row

| Region / Presence | | Key Markets & Strategic Role |
|---|---|---|
| Northwest | Major | Portland, Salem, Central Point — Costco placement made this region part of Del Real's club-store reach for ready-in-minutes Hispanic meals and sides. |
| Los Angeles | Major | Inglewood, Marina del Rey, Norwalk — Costco placement made Los Angeles a club-store outlet for Del Real's prepared Hispanic foods, extending access through Costco's Los Angeles region. |
| Southeast | Major | Atlanta, Charlotte, Myrtle Beach — Costco placement gave Del Real club-store distribution in Costco's Southeast region for its ready-in-minutes Hispanic meals and sides. |

(Presence values shown in the source as HIGH / HIGH / HIGH labels.)

### Table representation 2 — in zebra

| Region / Presence | | Key Markets & Strategic Role |
|---|---|---|
| Northwest | Major | Portland, Salem, Central Point — Costco placement made this region part of Del Real's club-store reach for ready-in-minutes Hispanic meals and sides. |
| Los Angeles | Major | Inglewood, Marina del Rey, Norwalk — Costco placement made Los Angeles a club-store outlet for Del Real's prepared Hispanic foods, extending access through Costco's Los Angeles region. |
| Southeast | Major | Atlanta, Charlotte, Myrtle Beach — Costco placement gave Del Real club-store distribution in Costco's Southeast region for its ready-in-minutes Hispanic meals and sides. |
| Northern California | Major | San Francisco — Costco placement made Northern California a club-store outlet for Del Real's prepared Hispanic foods through Costco's regional buying network. |
| San Diego | Major | Mission Valley, San Marcos — Costco placement made San Diego a club-store outlet for Del Real's prepared Hispanic foods through Costco's San Diego regional network |
| Midwest | Moderate | Chicago, Plainfield, Middleton — No Costco placement in 2016 left Del Real outside the Midwest club-store footprint at that time |
| Northeast | Moderate | Not disclosed — No Costco placement in 2016 left Del Real outside the Northeast club-store footprint at that time. |
| Texas | Moderate | Frisco, Fort Worth — No Costco placement in 2016 left Del Real outside the Texas club-store footprint at that time. |

### Table element specification

| Element | Font size | Weight | Alignment / spacing | Style rule |
|---|---|---|---|---|
| Table title | 12–14 pt | Semibold | Left | Clear title above table |
| Column header | 9–10 pt | Semibold | Match column | Subtle background or divider |
| Body / cell text | 8–9 pt | Regular | Text: left; numbers: right | Compact and readable |
| Key metric / total | 9–10 pt | Semibold | Match column | Subtle emphasis |
| Source / footnote | 7–8 pt | Regular | Left | Keep below table |
| Cell padding | — | — | 6–8 pt horizontal, 4–6 pt vertical | Consistent throughout |
| Borders | — | — | — | Prefer subtle horizontal dividers; avoid heavy gridlines |
| Row height | — | — | — | Minimum required for content; avoid excess whitespace |
| Number format | — | — | Right aligned | Keep decimals and units consistent |
| Text wrapping | — | — | — | Prefer 1–2 lines; avoid overly tall cells |

### Table layout rules

**Keep column hierarchy clear**
- Make the primary/most important column visually dominant.
- Avoid giving every column equal visual weight.

**Use consistent column widths**
- Give wider columns to descriptive text.
- Give narrower columns to numbers, percentages, dates, and short labels.
- Avoid unnecessarily wide empty columns.

**Limit cell wrapping**
- Prefer 1 line where possible.
- Allow maximum 2 lines for normal cells.
- If content consistently exceeds 2 lines, restructure the table rather than making the
  font smaller.

**Keep numbers visually scannable**
- Right-align numeric values.
- Align decimal places within a column.
- Use consistent units and decimal precision.
- Example: 12.4%, 8.7%, 5.2% rather than mixed formats.

**Use emphasis selectively**
- Bold only important values, totals, or key rows.
- Avoid bolding entire tables.
- Use one visual treatment for highlighted cells consistently.

**Avoid excessive colors**
- Keep the table primarily neutral.
- Use one accent color for emphasis.
- Don't color every row or column differently.

**Use zebra striping only when needed**
- Avoid zebra striping when rows contain labels, tags, pills, or other visual indicators.
- Keep the table background uniform and use the tags/pills to create visual differentiation.
- For dense data-only tables without tags, subtle zebra striping can be used if it improves
  row scanning.
- Avoid combining zebra stripes + colored tags + highlighted rows, as it creates
  unnecessary visual noise.

**Separate groups visually**
- Use spacing or subtle dividers between logical groups.
- Avoid adding borders around every individual cell.

**Maintain consistent table position**
- Align tables to the slide's main content grid.
- Maintain consistent left/right margins across slides.
- Avoid tables floating with arbitrary positioning.

**Handle overflow at table level**
- First adjust column widths → cell padding → wrapping → overall table size.
- Only then reduce typography within the allowed range.
- Never allow unreadable text just to preserve the table structure.

---

## 3. Other components

### Card representation

> 1 pt for line
> no background fill, only border line > in neutral

**Priority Strategies — What to do**

- **Win Traditional Grocery first:** Make Traditional Grocery the lead expansion channel,
  since it is only 20.2% of 2016E gross sales [194], sits at about 9% national ACV [184],
  and has the biggest branded retail whitespace [51].
- **Scale Foodservice with repeatable economics:** Grow Foodservice through broadline
  distributor reach, foodservice pack formats, and field sales into chains, convenience,
  and institutions, but only after proving operator pull-through and buyer labor-savings
  ROI [193][199][200][201][202][91][92][93].
- **Use plant headroom before adding fixed cost:** Push volume through Mira Loma, which is
  about 62% utilized with 13 lines in a 114,000 sq ft plant [184], before underwriting
  major capacity spend; execution depends on labor, line scheduling, and cold-chain
  throughput [123][124].

### Horizontal rail representation

> 1 pt for line
> background fill with gradient of line color

**4. Acquire frozen adjacency to broaden format mix**

Format hedge · Shelf-life coverage · Strategic Logic

Buy a frozen-adjacent asset to improve Del Real's weaker position in price-sensitive
institutional bids and ultra-low-cost channels. [52][53][62][76][77]

**Screen Targets**
- Padrino Foods: adjacent frozen and authentic Mexican depth [66][67][68][69]
- Texas Tamale Company: frozen tamale platform with regional appeal [70][71][72][73][74]
- Tucson Foods: frozen shelf-life and tamale adjacency [55][56][57][58][59][60]

### Call-out representation

> no line
> background fill with gradient of primary color

Del Real Foods is a U.S.-based refrigerated Hispanic and heat-and-eat foods manufacturer
headquartered in Mira Loma, California [1]. It sells branded meal components and full meal
solutions through retail, club, grocery, foodservice, institutional, and online channels,
with revenue recognized when products ship or are delivered [1].

| Value | Label |
|---|---|
| 46.74% | Value-Added Meats Rev Share |
| >60% | Top 10 Customer Concentration |
| 500+ | Mira Loma Plant Workers |

### Component sizing rules

**Cards**
- 1–3 cards: allow larger cards, stronger typography, and more internal whitespace.
- 4–6 cards: reduce card width and spacing while keeping content readable.
- 7+ items: do not keep shrinking cards; switch to a more scalable layout such as a rail or
  grouped structure.
- Card height should follow content, but cards within the same row should maintain a common
  height.
- Short content → increase whitespace.
- Long content → reduce padding and spacing before reducing font size.
- Don't force equal card widths when content lengths are significantly different.
- Each card should contain one primary data point or message.

**Horizontal rail**
- 2–4 items: use larger item widths and generous spacing.
- 5–6 items: use compact spacing and smaller item widths.
- 7+ items: do not reduce typography below the minimum; split the rail or change the
  component.
- Item width should respond to content length, rather than being rigidly equal.
- Short items should not create excessive empty space just to match a long item.
- Maintain consistent alignment across all items.
- Preserve the order when the data represents a sequence.
- Keep each item concise; avoid turning rail items into paragraphs.
- If the rail becomes too tall or compressed, restructure before reducing typography.

**Callouts**
- 1 callout: allow stronger visual emphasis and more whitespace.
- 2 callouts: balance them based on content length; they don't need identical heights.
- 3+ callouts: use only when each represents a distinct insight; otherwise combine them.
- Short insight → larger type and more whitespace.
- Long insight → increase available space and reduce internal spacing before reducing font
  size.
- Keep the primary message visually dominant.
- Don't force every callout to the same height when content differs significantly.
- Avoid callouts becoming containers for large amounts of body text.
- If content exceeds the readable capacity, restructure or move the overflow, rather than
  shrinking below the minimum font size.

**Common rule for all three**

> Content volume determines component size, spacing, and structure. Never preserve fixed
> dimensions at the cost of whitespace or readability. When content exceeds the component's
> capacity, restructure or move to the next slide rather than continuously shrinking the
> component.

---

## 4. Edge case — dynamic slide merging rule

- Before creating a new slide, check whether the next content can fit on the current slide.
- If related content fits without making the slide crowded → merge it into the current slide.
- If there is not enough space → create a new slide.
- Never reduce text below the minimum font size just to make content fit.
- Never merge unrelated content only to fill empty space.
- Reflow and resize components before creating a new slide.

**Simple decision rule**

```
Fit + Related + Readable                → Merge
Doesn't fit / Unrelated / Not readable  → New slide
```

**Example**

> Slide 1 has 3 cards, but there is space below them. If Slide 2 contains 2 related
> callouts + pointers that fit comfortably, move them onto Slide 1 instead of creating
> Slide 2.

This prevents unnecessary slides, excessive whitespace, and under-filled layouts while
keeping the slide readable.

---

## 5. Citation rules and representation

**Citation representation example**

> Scale Foodservice with repeatable economics: Grow Foodservice through broadline
> distributor reach, foodservice pack formats, and field sales into chains, convenience,
> and institutions, but only after proving operator pull-through and buyer labor-savings
> ROI [199 200 201 202 91 92 93].

### Citation styling and usage

- Use numbered citations `[n]` as the default citation style across the entire presentation.
- Place the citation immediately after the claim, metric, statement, chart, or data point it
  supports.
- Use `[3]` for a single source, `[3, 7]` for multiple non-consecutive sources, and `[3–7]`
  for consecutive sources.
- Do not display full source names, publication titles, URLs, or long source text within
  cards, callouts, charts, tables, or other content components.

**Keep citation typography visually subordinate to the content:**

| Property | Value |
|---|---|
| Font | Same font family as the presentation |
| Size | 8–9 pt |
| Weight | Regular |
| Color | Secondary / muted text color |
| Line height | 1.1–1.2× |
| Case | Sentence case |

- Do not use bold, uppercase styling, colored badges, filled pills, borders, or separate
  citation cards.
- For key metrics, place the citation directly after the value or supporting statement:
  `12.4% CAGR [3]` · `$42B market size [3, 7]`
- For charts and visualizations, place the citation in a small source line at the bottom of
  the visual: `Source [3, 5]`
- For tables, use one citation at the table level when the same sources support the table.
  Use cell-level citations only when individual values come from different sources.
- If a component has more than 3 sources, use grouped references rather than listing source
  names.
- If a slide contains more than 6–8 sources, do not expand the slide footer with full source
  information. Use numbered citations on the slide and provide the complete source list in
  the References / Appendix.
- Maintain a single source index across the entire deck. `[3]` must always refer to the same
  source wherever it appears.

**Full source details should follow one consistent format:**

```
[3] Gartner, Semiconductor Forecast, 2025
[7] McKinsey, Global Semiconductor Outlook, 2025
```

- Citation space must never change the primary component layout. Do not shrink the main
  content or increase component height just to accommodate longer source text.
- Citations should function as traceability metadata, not as a visual content element.

---

## 6. Slide rules

### Slide content-density rule

Each slide has a total character budget calculated as the sum of all visible content
elements on that slide. This includes titles, paragraphs, bullets, card text, callouts,
table text, labels, and other readable copy. Citations are excluded from the primary
content budget because they are metadata.

**Recommended rule**
- Target: 600–900 characters per slide
- Soft maximum: 1,000 characters
- Hard maximum: 1,200 characters

- Character limits are a density guardrail, not an automatic page-break trigger.
- When the total exceeds the target, first restructure, condense, or prioritize the content.
- Create a next slide only when important content still cannot fit clearly.
- Never shrink typography below the defined minimum just to stay within the character limit.
- One section should remain on one slide by default.
- If a section genuinely requires more space, split it at a logical content boundary, not at
  an arbitrary character count.

**Engineering formula**

```
Slide characters =
    Title
  + subtitles/context
  + paragraphs
  + bullets
  + card titles
  + card bodies
  + callouts
  + table text
  + chart labels
  + other visible copy

Then:
  ≤ 900       → Preferred
  901–1,000   → Optimize if possible
  1,001–1,200 → Strong overflow check
  > 1,200     → Recompose / condense / consider next slide
```

### Additional slide rules

- One section = one slide by default. Do not split unless content genuinely requires it.
- Use any layout/component combination. No fixed card count, column count, or template
  structure.
- Optimize before splitting: reflow → consolidate → shorten → deprioritize → split.
- Set a minimum readable font size. Never solve overflow by continuously shrinking
  typography.
- Control component density. Avoid too many small components competing for attention.
- Avoid excessive whitespace. If meaningful content can naturally fit, don't push it to the
  next slide.
- Don't force symmetry. Unequal card sizes or layouts are acceptable when driven by content
  importance.
- Split at logical boundaries. If a second slide is needed, move a meaningful sub-topic —
  not leftover content.
- Keep citations out of the content budget. Use `[n]` citations as lightweight metadata.
- Prioritize information, not component count. A slide with 2 important components can be
  better than one with 6 weak components.
- Every slide must feel complete. Avoid continuation slides containing only one small card,
  bullet, or callout.

### The complete engine rule in one line

> Fit one complete section within a shared slide content budget, using an adaptive layout;
> optimize composition before pagination, and move to the next slide only when important
> content cannot remain readable and meaningful on the current slide.

````

## Checksum manifest

Verifies every block above is complete and unaltered.

| File | Bytes | SHA-256 |
|---|---|---|
| `SKILL.md` | 28028 | `c724c40ae7eaf5ff143ccc75c4acd6b61bb781445cdee6673fa0e684bc17af5f` |
| `assets/design-tokens.json` | 30499 | `9e20864e82fb839930d4fc976b76478b96828d1ebd2e8f80382c2ed4b7c60c97` |
| `assets/example_spec.json` | 3027 | `fee519be5003a840abbbe16f863ab644b04ac08f73365ac2d80be0ca07d10032` |
| `assets/example_spec_v2.json` | 10905 | `70c5852bde7d57012db262efc1ddc6e50dfc5b01035749013ab41e6b38570fc4` |
| `scripts/layout_engine.py` | 22515 | `6676d49013dbdfe2346a5be8ed9d39afa9f7dc12c851e097034f340fa8b230cd` |
| `scripts/compose_engine.py` | 75512 | `4bea789aa30a25e17a14ca336c3ef136e5b119d239f9365f05a3ee16ec4eedef` |
| `scripts/pe_components.js` | 63468 | `c9652a5b2ee9073731d9fd43aadd37aba468612b21a9ca0425c834f0bc1cc094` |
| `scripts/build_from_plan.js` | 3888 | `5f7943dbb663deafcefbba9ee7a375cbee70e3af447887a6b56079bd56ca0568` |
| `scripts/audit_deck.py` | 19835 | `661d36775c2999fb96ee0e6f9958e3af1821902449caa67dc73f4b761b7fee8a` |
| `scripts/example_build.js` | 8746 | `1fb4e361da841e63f6d9df00c33af2f7208d8d29601f1f87574b64709cc7a869` |
| `references/layout-intelligence.md` | 25046 | `95c8370de0aa714b1f04319ae79ad0b2f84d104baa115352f22af386f53634a8` |
| `references/report-deck-patterns.md` | 8277 | `9418cf667249dd67d6f9a00d23d03410be163d5d9147453c4db87556700232dd` |
| `references/typography.md` | 4685 | `4d2ed6dc6d52b0308c5cda493266bc4467397c2eec8b9284cfd5c96296d9082b` |
| `references/components.md` | 4780 | `6414078395a65194043900f73a9a362a901dceb1281c527cef463571166008d4` |
| `references/tables.md` | 4464 | `9562c47b35077ef422541e4e5be4daf7a4ad8bf250f4a3e6caa19a154886e24d` |
| `references/citations.md` | 4777 | `48ba94a3c1e8eb02a251e3f972cbbb4f2bca3078bb81c67217ce1101f0db7d5d` |
| `references/density-and-pagination.md` | 5553 | `30765785e579c4703a1e743a3c5abb0e02cb7f7643ab017f3835e267c18c1e9d` |
| `references/source-spec.md` | 19430 | `aaa86ad80da9728a86e8aac977a035db5b9ec359553695e1f76649855c376a65` |

## Extraction script

Run this against this bundle file to reconstruct the skill folder losslessly.

```python
#!/usr/bin/env python3
"""extract_bundle.py — reconstruct pe-deck-design/ from this bundle file.
Usage: python3 extract_bundle.py pe-deck-design-v2-BUNDLE.md [output_dir]
"""
import re, sys, os

def main():
    bundle_path = sys.argv[1] if len(sys.argv) > 1 else "pe-deck-design-v2-BUNDLE.md"
    out_dir = sys.argv[2] if len(sys.argv) > 2 else "pe-deck-design"
    text = open(bundle_path, "r", encoding="utf-8").read()

    pattern = re.compile(
        r"## FILE: `([^`]+)`\n\n(`{4,})[a-zA-Z]*\n(.*?)\n\2\n",
        re.DOTALL)

    count = 0
    for m in pattern.finditer(text):
        rel_path, _, content = m.groups()
        full = os.path.join(out_dir, rel_path)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(content)
        print(f"wrote {full}  ({len(content)} bytes)")
        count += 1
    print(f"\n{count} files restored to {out_dir}/")

if __name__ == "__main__":
    main()
```